# NAC3 v2.3 benchmark -- reproducibility bundle

This bundle contains the complete test harness for the NAC3 v2.3 benchmark
published at <https://yujin.app/nac-spec/benchmark/> and
<https://github.com/yujinapp/nac-spec/tree/main/benchmark/>.

It lets anyone with API keys for the five providers re-run the same 600
runs (5 models x 3 protocols x 4 tasks x 10 iterations) and verify the
published numbers.

**Cost to re-run the full sweep:** roughly **US$15** in API credits.
**Wall-clock:** ~1h 23min serial on commodity hardware.
**Traceability:** every JSONL row carries `runtime_version`,
`bench_version`, and `manifest_checksum=67db3eef3658` for provenance.

---

## Quick start

```bash
# 1. Install
npm install
npx playwright install chromium

# 2. Configure -- COPY the example and REPLACE the fictional values with your real keys
cp .env.example .env
# Open .env in your editor and replace every placeholder
# (e.g. sk-ant-api03-FAKE_az302_..._xxxx) with the actual API key
# from your account dashboard. The fictional values are clearly
# marked "FAKE" and "replace_with_real" so you cannot accidentally
# run the benchmark with placeholder credentials.

# 3. Start the fixture server (in another shell)
cd fixtures/invoice-app
npx tsx server.ts
# serves http://127.0.0.1:8080

# 4. Run the full 600-cell sweep
bash scripts/run_final_600.sh

# 5. Generate the unified report
RESULTS_DIR=results/N10_final \
  node scripts/unified_report.mjs --since=2026-05-19T23 \
  > docs/MY_REPORT.md
```

---

## Where to get the keys

The benchmark uses five providers. Get each key from the corresponding
dashboard, then paste into `.env` replacing the `FAKE_...` placeholder:

| Provider | Where to get the key | Env variable in .env |
|---|---|---|
| Anthropic (Claude) | https://console.anthropic.com/settings/keys | `ANTHROPIC_API_KEY` |
| OpenAI (GPT) | https://platform.openai.com/api-keys | `OPENAI_API_KEY` |
| DeepSeek | https://platform.deepseek.com/api_keys | `DEEPSEEK_API_KEY` |
| Google (Gemini) | https://aistudio.google.com/app/apikey | `GEMINI_API_KEY` |
| Groq (optional) | https://console.groq.com/keys | `GROQ_API_KEY` |

**The four required ones for the published roster are Anthropic, OpenAI,
DeepSeek, Gemini.** Groq is only needed if you extend the roster to
test Llama-via-Groq.

---

## Subset runs (cheaper / faster)

The harness reads four env vars to subset cells:

| Var | What | Example |
|---|---|---|
| `MODEL` | which provider/model to call | `MODEL=gemini-3.1-flash-lite` |
| `PILOT_CONDITIONS` | protocols (csv) | `PILOT_CONDITIONS=nac3` |
| `PILOT_TASK_IDS` | tasks (csv) | `PILOT_TASK_IDS=T1_add_monitor` |
| `PILOT_ITER` | iterations per cell | `PILOT_ITER=3` |
| `PILOT_OUT_DIR` | where to write jsonl | `PILOT_OUT_DIR=results/quick` |

Smoke test (1 model, 1 protocol, 1 task, 3 iter, ~US$0.01, ~20s):

```bash
MODEL=gemini-3.1-flash-lite \
PILOT_CONDITIONS=nac3 \
PILOT_TASK_IDS=T1_add_monitor \
PILOT_ITER=3 \
PILOT_OUT_DIR=results/quick \
npx tsx src/harness_3way.ts
```

---

## Per-iteration cross-model order (anti-bias)

The published benchmark used per-iteration cross-model ordering to
distribute temporal effects (provider load, model drift) across all
five models. To replicate exactly:

```bash
NUM_ITER=10 bash scripts/run_final_600.sh
```

The script loops `iter=0..9` outer, `model=A..E` inner. Each invocation
calls the harness with `PILOT_ITER=1 PILOT_ITER_OFFSET=$iter` so the
run_id and iteration label reflect the absolute global iteration.

---

## What's in this bundle

```
.
+-- README.md                      this file
+-- .env.example                   key template with FICTIONAL values (replace before running)
+-- package.json                   npm deps
+-- tsconfig.json
+-- src/
|   +-- harness_3way.ts            orchestrator
|   +-- conditions/
|   |   +-- llm.ts                 multi-provider client (Anthropic, OpenAI, Google, DeepSeek, Groq)
|   |   +-- nac3.ts                NAC3 condition (snapshot + dispatch + validator)
|   |   +-- raw_dom.ts             Raw DOM condition (HTML + selectors)
|   |   +-- mcp.ts                 MCP condition (tool calls)
|   |   +-- parse_json.ts          shared JSON parser
|   +-- tasks_invoice.ts           4 task definitions + postconditions
|   +-- pricing.ts                 per-model cost table (2026-05-19)
|   +-- ...
+-- fixtures/
|   +-- invoice-app/               the test app (invoice management UI)
|       +-- server.ts              Express server
|       +-- pages/                 raw HTML + JS app
|       +-- ...
+-- page-nac3/                     NAC3-decorated mirror of the fixture
+-- page-raw/                      Raw-DOM mirror (no decoration)
+-- scripts/
|   +-- run_final_600.sh           full 600-cell sweep
|   +-- run_paso9_v2.sh            96-cell baseline (8 models, 1 iter)
|   +-- rerun_targeted.sh          rerun specific failed cells
|   +-- unified_report.mjs         aggregate jsonl -> markdown report
|   +-- post_fix_smoke.mjs         smoke validation of all fixes
+-- docs/
    +-- N10_FINAL_REPORT.md        full unified report from the published run
    +-- N10_FINAL_QA.md            verification of 6 publication criteria
    +-- REPORT_PROTOCOL.md         protocol comparison narrative
    +-- REPORT_COST_LATENCY.md     cost-latency trade-off narrative
    +-- REPORT_MODEL_FIT.md        per-model fit narrative
    +-- benchmark_design.md        design doc (assumptions + 4 initial fixes)
    +-- benchmark_design_addendum.md  equality controls + cap bumps
    +-- INVESTIGATION_DEEPSEEK_SILENT_DAMAGE.md  Fix D2 root cause
```

The `results/` directory ships empty -- your runs populate it.

---

## Reproducibility checks

After running, verify the JSONL provenance:

```bash
node -e "
const fs=require('fs'), path=require('path');
const dir='results/N10_final';
for (const f of fs.readdirSync(dir).filter(x=>x.endsWith('.jsonl'))) {
  for (const l of fs.readFileSync(path.join(dir,f),'utf8').split('\n').filter(Boolean)) {
    const r=JSON.parse(l);
    if (r.manifest_checksum !== '67db3eef3658') {
      console.log('DIVERGED:', r.run_id, r.manifest_checksum);
    }
  }
}
"
```

A non-empty output means your fixture diverged from the published baseline.
That's not necessarily wrong -- it means you customized the test app -- but
your numbers won't be directly comparable to the published 600 unless the
checksum matches.

---

## License

Apache 2.0 + MIT. Free for any use including commercial. Attribution
appreciated but not required.

Spec home:      <https://github.com/yujinapp/nac-spec>
Benchmark home: <https://yujin.app/nac-spec/benchmark/>
