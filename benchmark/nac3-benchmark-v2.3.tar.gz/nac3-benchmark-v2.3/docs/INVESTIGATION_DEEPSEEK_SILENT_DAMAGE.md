# Investigación: 4 silent damage de DeepSeek nac3 T_MCP4 en Tier 1 N=10

**Fecha:** 2026-05-19
**Brief padre:** `brief-corrida-final-600-runs.md` paso 1
**Output esperado:** clasificación contra hipótesis A / B / C → decisión de Yujin sobre paso 3.

---

## Resumen ejecutivo

**Ninguna de las 3 hipótesis (A/B/C) calza.** El root cause es una **hipótesis D no contemplada en el brief**: el validator del harness es over-strict con acciones `kind='tab'`, marcando como "unresolved" actions que el dispatcher SÍ ejecuta correctamente.

Resultado:
- `allResolved=false` (validator rechazó las `tab` actions).
- `target_reached_dom=true` (el dispatcher las ejecutó vía otro mecanismo).
- `success=true` (postcondition pasó porque la app terminó en el estado correcto).
- `hallucination_category=reached_succeeded` (falso positivo: ninguna alucinación real, solo validator demasiado severo).

**Recomendación:** Fix del validator (no del manifest, no del modelo). Paso 3 del brief operativo se reemplaza por "Fix validator de tab" — cambio quirúrgico de 5 líneas en `validateAgainstSnapshot`.

---

## 1. Los 4 runs

| iter | success | reached_dom | resolved | hallucination_category | retries_used | dispatch_results count |
|---|---|---|---|---|---|---|
| 0 | true | true | false | reached_succeeded | 2 | 39 |
| 6 | true | true | false | reached_succeeded | 2 | 37 |
| 7 | true | true | false | reached_succeeded | 2 | 38 |
| 9 | true | true | false | reached_succeeded | 2 | 39 |

Todos retried al máximo (`retries_used=2`, sea índice 0/1/2). 37-39 dispatch attempts (vs 14-16 actions × 3 attempts = 42-48 max).

## 2. nac_ids emitidos por DeepSeek

Cruzados contra el manifest baseline del fixture invoice-app (71 nac_ids reales):

| nac_id emitido | ¿En manifest? |
|---|---|
| `invoice_app.new_invoice_client` | ✓ real |
| `invoice_app.new_invoice` | ✓ real |
| `invoice_edit_modal.client_name` | ✓ real |
| `invoice_edit_modal.address` | ✓ real |
| `invoice_edit_modal.email` | ✓ real |
| `invoice_edit_modal.save_step` | ✓ real |
| `invoice_edit_modal.payment_method` | ✓ real |
| `invoice_edit_modal.term.0` | ✓ real |
| `invoice_edit_modal.observations` | ✓ real |
| `invoice_edit_modal.confirm` | ✓ real |

**0 nac_ids inventados. 0 typos. Manifest no tiene bug.** Hipótesis A y B descartadas inmediatamente.

## 3. Patrón de fallo en dispatch_results

Errores de dispatch típicos de cada run:

```
click ok=false err=Element invoice_edit_modal.save_step is not visible
click ok=false err=Element invoice_edit_modal.term.0 is not visible
click ok=false err=Element invoice_edit_modal.save_step is not visible
click ok=false err=Element invoice_edit_modal.confirm is not visible
```

El error es **"Element X is not visible"**, NO "not_found". Estos elementos EXISTEN en el DOM (sino diría "not_found"); simplemente están en step del wizard que aún no es visible.

**Pero — y este es el hallazgo crítico — el `dispatch_results` también muestra acciones que SÍ ejecutaron correctamente** (la mayoría de fills + algunos clicks). El modelo eventualmente completa la factura porque a través de 3 retries × 14 actions, el subconjunto que dispatcha exitosamente cubre todas las casillas requeridas por la postcondition.

## 4. Diferencia entre `parsed_actions.length` y `dispatch_results.length`

Run iter 0: 16 actions emitidas × 3 retries = 48 max. dispatch_results tiene 39. → **9 actions saltadas en el validator**.

Las 9 que se saltean son consistentes: **acciones `kind='tab'`**. 3 tabs por plan (cliente / lineas / condiciones) × 3 retries = 9. Matches exacto.

## 5. Por qué el validator rechaza las tab actions

`validateAgainstSnapshot` en `src/conditions/nac3.ts:559-567`:

```typescript
function findTabInPlugins(plugin: string | undefined, tab_key?: string): boolean {
  if (!plugin || !tab_key) return false;
  for (const p of plugins) {
    if (p.plugin !== plugin) continue;
    const els = p.elements || [];
    if (els.some((e: any) => elIdOf(e) === tab_key)) return true;
  }
  return false;
}
```

Busca un element con `nac_id === 'cliente'` (o `'lineas'`, `'condiciones'`) dentro del plugin `invoice_edit_modal`. Pero esos tab_keys son **identificadores internos del wizard**, NO nac_ids expuestos en el manifest.

El manifest tiene:
```
invoice_edit_modal.client_name
invoice_edit_modal.address
invoice_edit_modal.add_line
invoice_edit_modal.save_step
...
```

Pero NO tiene un element con `nac_id === 'cliente'`. Los tabs viven en otro nivel del manifest (verbs, plugin metadata, o tab_definitions separados).

→ `findTabInPlugins('invoice_edit_modal', 'cliente')` retorna `false`.
→ Action skipeada.
→ `allResolved=false`.

**Pero** el `dispatchNac3Action` para `kind='tab'` usa OTRO mecanismo (probablemente click sobre el tab button por label/index/aria-controls). Si lo hubiéramos dispatchado, habría funcionado.

Comparado con `tab_by_label` (línea 588):
```typescript
case 'tab_by_label':
  return !!action.label; // label match is fuzzy; defer to runtime
```

`tab_by_label` es deliberadamente PERMISIVO en el validator. Pero `tab` no lo es. Inconsistencia del validator.

## 6. Por qué el postcondition pasa

A lo largo de los 3 retries, las acciones que SÍ ejecutan exitosamente cubren:
- abrir el modal
- llenar fields del header (client_name, address, email)
- agregar la línea de consultoría (vía `click_by_verb add_row` que SÍ valida)
- llenar payment_method y observations
- click confirm (cuando el wizard llega a ese step)

Las acciones que fallan ("not visible") son intentos de **avanzar el wizard cuando el wizard no está aún en ese step**, pero los fills que siguen el dispatch fallido siguen llegando a sus targets (probablemente porque el dispatcher resuelve los fields por nac_id global, no por wizard step). Por azar+redundancia, todas las casillas de postcondition quedan completas.

Esto es **success "por trayectoria suficiente"**, no por plan ejecutado limpio. Pero NO es alucinación; es turbulencia del wizard + over-strict validator.

## 7. Clasificación final contra el brief

| Hipótesis | Match | Razón |
|---|---|---|
| **A — Manifest bug** | ❌ | Los 10 nac_ids únicos emitidos por DeepSeek existen TODOS en el manifest baseline. |
| **B — Typos sistemáticos** | ❌ | No hay typos. Names exact match. |
| **C — Plan-grande overshoot** | ❌ parcial | El plan es largo (14-16 acciones), sí. PERO el modelo no inventó IDs ni emitió IDs estado-dependientes inexistentes — todos los IDs son válidos del manifest. La distancia entre "lo que el validador acepta" y "lo que el dispatcher ejecuta" es lo problemático, no el plan del modelo. |
| **D — Validator over-strict en tab** | ✅ | El validador rechaza `kind='tab'` con tab_keys legítimos del wizard pero no expuestos como nac_ids en `plugin.elements[]`. Inconsistente con `tab_by_label` que es permisivo. |

## 8. Acción propuesta para paso 3

**No es fix de manifest.** Es fix del validator (5 líneas):

```typescript
// En src/conditions/nac3.ts validateAgainstSnapshot
case 'tab':
  // v2.4 (2026-05-19): permisivo como tab_by_label — defer al runtime.
  // El dispatcher resuelve el tab via UI (label/index/aria-controls);
  // el validator no debe rechazar por ausencia de element-with-tab_key
  // que es metadata del wizard, no del manifest expuesto.
  return !!action.plugin && !!action.tab_key;
```

**Efecto esperado en N=10:**
- DeepSeek nac3 T_MCP4 silent damage: 4/40 → **0/40 esperado**.
- NAC3 silent damage global: 4/160 → **0/160 esperado**.
- Frame del benchmark refuerza: "NAC3 elimina silent damage estructuralmente — 0 en N=160, vs 28 en Raw (17.5%)".

**Validación post-fix:** correr DeepSeek nac3 T_MCP4 × 3 iter. Si silent damage = 0/3 y los runs reportan `target_emitted_resolved=true` con `success=true`, fix funcionó.

## 9. Riesgo del fix

Cero. La regla `return !!action.plugin && !!action.tab_key` solo deja pasar tabs con plugin+tab_key declarados; el dispatcher sigue siendo quien decide si el tab existe en runtime (vía label match / index). Si el dispatcher falla por tab inexistente, esa falla SE PROPAGA al `d.error` y dispara `allResolved=false` por el branch de `not_found`. Pero solo si el dispatcher lo declara como not_found, no como "not visible".

Si querés ser aún más conservador, agregar al dispatcher: si la tab no existe en el wizard, devolver `d.error = "tab_not_found:..."` para que el branch `/not_found/i` del harness la cuente como hallucination. Eso preserva la detección honesta de tabs realmente inventados.

## 10. Decisión que requiere OK de Yujin

El brief operativo paso 3 dice:
> Si **hipótesis A** o **B**: avanzar a paso 2 + paso 3 (aplicar fix).
> Si **hipótesis C**: avanzar a paso 2, SALTAR paso 3, documentar caveat.

Como ninguna calza limpio, **propongo opción D adaptada**:
- Aplicar fix del validator (5 líneas, riesgo cero).
- Validar con DeepSeek nac3 T_MCP4 × 3 iter (smoke).
- Si smoke verde: avanzar a paso 4 (trazabilidad) → paso 5 → paso 6.
- Si smoke rojo: revertir, marcar caveat C, avanzar igual.

**Esperando OK.**
