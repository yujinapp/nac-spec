# NAC3 2.3 improvement list (extracted from invoice-app benchmark)

Each item is sourced from a real failure mode observed running
3 agents (Claude Sonnet 4.6 + Haiku 4.5 + Gemini 3.1 Flash Lite)
across NAC3, Raw DOM, and MCP conditions on T1 / T_MCP1 / T_MCP4.

Categories:
- **(spec)** belongs in the SPEC.md normative text.
- **(runtime)** belongs in `js/nac.js` / `js/nac-v2-extensions.js`.
- **(guide)** belongs in `guides/LLM_WIRING.md` or a new host
  authoring guide.

---

## Bigger items (closed real benchmark gaps)

### 1. (spec + runtime) Parameterised `click_by_verb` -- formalise v2.3 preview

The 2.3 preview shows `NAC.click_by_verb('myplugin', 'edit_field',
{nac_id: 'invoice.client_name'})` but the v2.2.1 runtime forwards the
third arg into `click()` opts; the host's handler never sees it.

Formal v2.3:

- The third arg of `click_by_verb(plugin, verb, args)` is a host
  handler payload (NOT ClickOpts).
- If `args` carries any key outside the ClickOpts allow-list
  (`{timeout, source, plugin}`), the runtime dispatches a custom
  event `nac:action:invoke_with_args` with `detail: {plugin, verb,
  args}` instead of synthesising a DOM click.
- If a host listener responds with `nac:action:succeeded` within
  `timeout` (default 5s), the call resolves. Otherwise the runtime
  falls back to a plain DOM click (back-compat).
- The 2.3 preview's `edit_field` modal can be re-implemented on top
  of this primitive.

**Benchmark evidence**: closed T_MCP4 NAC3 from 0/1 to 1/1 across
all 3 models. Agents could atomically add a line with values
(`{description, qty, unit_price}`) instead of click + dt_edit_cell
dance that broke because the new row id is not in-snapshot.

### 2. (runtime) Strict `supports[]` enforcement

The v2.1 spec text declares `supports[]` advisorily; the runtime
mutates table state regardless. Agents misusing read-only tables
(`supports=[]`) get silent partial behaviour.

v2.3-final: `NAC.dt_add_row / dt_remove_row / dt_edit_cell` MUST
throw `NacError({code:'operation_not_supported'})` if the called op
is not in the table's declared `supports[]`. Hosts that want silent
no-op semantics should not register the table at all.

**Benchmark evidence**: agents called `dt_add_row` on the read-only
`invoice_app.invoice_directory` table; without enforcement the
runtime mutated NAC-internal state silently, the bridge never
fired, and the post-condition failed without a clear error to
trigger a retry.

### 3. (spec + runtime) Snapshot `current_visibility` on data-tables

v2.1 snapshots are a static manifest dump. The agent can not tell
whether a data-table's owning panel is currently rendered.

v2.3: `NAC.describe_v2()` MUST include `current_visibility:
'visible'|'hidden'` per data-table, computed from the owner DOM
element (`schema.scope_owner` -> live computed style). Optionally
also per element in `NAC.describe().plugins[*].elements[*]`.

**Benchmark evidence**: 5K-token savings (hidden data-table rows
omitted from the snapshot when their owning panel is closed) plus
the agent can plan navigation correctly.

### 4. (spec) `companion_primitive` annotation in the snapshot

When a button-action's verb matches a primitive on a data-table
whose scope_owner is the button's plugin, the snapshot annotates the
button with `companion_primitive: "dt_add_row(<table_id>, {values})"`
and `prefer_primitive: true`.

Agents reading this prefer the atomic primitive over the value-less
button click, when they have values to set.

**Benchmark evidence**: partial; without #1 (parameterised
click_by_verb) the annotation alone was not enough to change agent
behaviour. Combined with #1, the agent has a clear "use this verb
with args atomically" path.

---

## Snapshot-size hygiene (production pattern, formalise it)

LLM_WIRING.md sec 5 mentions these as production techniques. v2.3
should formalise the contract.

### 5. (guide + runtime) Snapshot encoding compact

The user prompt MUST send `JSON.stringify(snapshot)` compact (no
pretty-printer). Saves ~20% tokens without semantic loss. Reference
backend code in LLM_WIRING.md sec 2 currently shows
`JSON.stringify(snapshot, null, 2)`; remove the indent.

### 6. (guide) Single-locale label collapse at snapshot time

`label_i18n` (10 locales) collapses to `label` (1 locale) at
snapshot build time, picking from the active language with `es`/
`en` fallback. Saves ~30% tokens on element-heavy plugins.

### 7. (guide) Role filter at snapshot time

Default-omit `section / region / navigation / breadcrumb-item`
from `plugins[*].elements[*]`; agents rarely target them. Hosts
can opt-out per snapshot if needed.

### 8. (guide) Hidden-element field minimisation

For elements with `visible: false`, keep only the planning-minimum
keys (`nac_id`, `role`, `label`, `visible`, `action`). Drop runtime
state (`state`, `disabled`, `field_type`, `value`, etc).

### 9. (guide) Hidden data-table row omission

For tables with `current_visibility: 'hidden'`, replace
`current_state.rows` with
`{row_count, rows_omitted_reason: 'table_hidden -- open owner panel to read'}`.
The agent plans around the schema; it cannot operate on hidden rows
anyway.

### 10. (guide) Strip null + default-value fields

Drop fields where the value is `null` / `undefined`, and the known
boolean-defaults (`disabled: false`, `undoable: false`,
`state: 'idle'`). Agents do not need to see absent state.

---

## Host-author guidelines (no spec change)

### 11. (guide) DOM render pipeline must be drainable

When the host mutates DOM via async chains (`fetch().then(refresh)`),
the runtime can dispatch a NAC action before the resulting render
finishes -- e.g., before a freshly-opened modal's data-table is
registered. The host should expose a counter (e.g.
`window.__pendingMutations`) that the dispatcher / harness can
await. The async chain must keep the counter > 0 across the FULL
mutation pipeline (api fetch + state refresh + re-render +
__nacSync), not just the leading fetch.

**Benchmark evidence**: race condition where `data-table not
registered` fired on the first dt_add_row after a new-invoice
click, because the harness saw the counter drain prematurely.

### 12. (guide) Data-table naming convention

Tables nested inside a plugin should use the plugin slug as prefix
of their `table_id` (`invoice_edit_modal.lines`, not `invoice.lines`).
Agents consistently infer the `table_id` from the enclosing plugin
scope when picking primitives. Mis-prefix is a top failure mode
on compound tasks.

### 13. (guide) State-sync bridge pattern for backend-owned state

Hosts that keep state outside NAC (backend HTTP, etc) should
implement a bridge:

- Listen for `nac:dt:row_added / row_removed / cell_edited`.
- Issue the corresponding REST mutation.
- After the mutation lands, fetch a fresh snapshot and call a
  documented `window.__pushState(snapshot)` so app code + NAC tree
  re-sync.

This pattern is what production MCP servers do (Asana / GitHub /
Linear etc); making it the recommended NAC3 pattern means NAC3-
based apps inherit the same back-end-of-truth architecture.

---

## Bug-fix candidates against the v2.2.1 runtime

### 14. (runtime) `click_by_verb` resolution when both `action` and `actions[]` exist

The runtime threw `No action with verb="new_invoice" found in plugin
"invoice_app"` even though the element was registered with
`actions: [{verb: 'new_invoice', ...}]`. Suspect: resolver only
walks `_manifests[plugin].actions[]` (a top-level array maintained
by `NAC.register`), not the per-element `actions` array. Worth
a dedicated repro.

### 15. (runtime) `tab()` should accept short form when manifest uses full id

Currently `NAC.tab(plugin, tab_key)` requires the exact `tab_key`
that the manifest registered. Agents intuit short form (`'cliente'`)
when the manifest declares full (`'tab.cliente'`). Suggested:
runtime accepts both `'tab.<X>'` and `'<X>'` (suffix match)
documented as a v2.3 leniency. This was patched into the benchmark
harness and then reverted -- it belongs in the runtime once Pablo
signs off.

---

## Status against the benchmark

After applying items 1+2+3+5-10+11+12, with the v2.3 baseline:

|                          | claude-sonnet-4-6 | claude-haiku-4-5 | gemini-3.1-flash-lite |
|--------------------------|-------------------|------------------|------------------------|
| T1            NAC3       | 1/1               | 1/1              | 1/1                    |
| T_MCP1        NAC3       | 1/1 (flaky N=1)   | 1/1              | 1/1                    |
| T_MCP4        NAC3       | **1/1** (closed)  | (rerun pending)  | (rerun pending)        |
| NAC3 input mean tokens   | 5,740             | 5,573            | 5,315                  |
| MCP  input mean tokens   | 4,402             | 5,752            | 3,886                  |
| Raw  input mean tokens   | 28,204            | 28,166           | 27,190                 |

NAC3 input tokens essentially tied with MCP, ~5x cheaper than Raw.
T_MCP4 closed on Sonnet after items 1+12. Pending re-pilot on Haiku
+ Gemini to confirm.

---

## Recommended sequencing

1. Land items 5 / 6 / 7 / 8 / 9 / 10 in `guides/LLM_WIRING.md` --
   pure documentation, zero risk.
2. Land item 1 (parameterised click_by_verb) -- behavioural change
   in runtime, gated on the `args`-has-non-opts-keys check so
   v2.1/v2.2 callers see no diff.
3. Land item 2 (strict supports[]) behind a feature flag
   `NAC.STRICT_SUPPORTS` defaulting to false in v2.3, flipping to
   true in v2.4.
4. Land item 3 (current_visibility) as additive snapshot fields.
5. Land item 4 (companion_primitive) as additive snapshot fields.
6. File items 14 + 15 as separate runtime bug reports against the
   v2.2.1 head.
