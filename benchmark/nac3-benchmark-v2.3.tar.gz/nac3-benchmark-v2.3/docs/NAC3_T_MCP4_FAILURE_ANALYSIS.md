# NAC3 T_MCP4 failure analysis

**Status:** All three models (Claude Sonnet 4.6, Claude Haiku 4.5,
Gemini 3.1 Flash Lite) fail T_MCP4 on the NAC3 condition while
succeeding on Raw DOM + MCP. The pattern is **architectural, not
model-specific**.

This document captures:

1. The full system prompt sent to the NAC3 agent.
2. The full NAC tree snapshot for T_MCP4's setup state, pretty-indented
   (`docs/T_MCP4_DUMP.txt` is the verbatim payload; open with Notepad++).
3. The action sequences each model emitted.
4. My analysis of where the agent gets confused.
5. Proposed NAC3 v2.4 protocol fixes.

---

## 1. The task

User prompt sent in `task` field:

> Creame una factura nueva para el cliente Acme con: direccion
> "Av. Corrientes 1234", email "contacto@acme.com". Agregale una linea
> de "consultoria" con cantidad 10 horas a 150 cada una. Condiciones:
> forma de pago contado, plazo 0 dias, observaciones "proyecto urgente".
> Dejala lista para confirmar.

Setup: backend reset; modal is **closed**; list view visible.
The agent must:

1. Pick the Acme client from the new-invoice form.
2. Click "Crear factura" -> backend creates INV-0016 and opens it.
3. Fill the header in step 1 of the wizard.
4. Switch to step 2 ("Lineas").
5. Add a line `{description: "consultoria", qty: 10, unit_price: 150}`.
6. Switch to step 3 ("Condiciones").
7. Set `payment_method: "contado"`, `term: 0`, observations, accept.
8. Optionally confirm.

Post-condition (DOM-observable, identical across the 3 conditions):

- A new invoice exists with `client_name` matching `/acme/i`.
- Its header has the address + email from the task.
- It has at least one line with description matching `/consultor/i`,
  `qty=10`, `unit_price=150`.
- Conditions: `payment_method='contado'`, `payment_term_days=0`,
  observations matching `/urgente/i`.
- Status: `pendiente`.

## 2. What the agent sees

### System prompt (sent verbatim to all 3 conditions; NAC3 version):

```
You drive a web UI by emitting structured NAC actions.

Rules:
1. Resolve the user's intent against the NAC tree below. Prefer
   click_by_verb when a verb matches; fall back to click(nac_id)
   only if no verb fits.
2. For tab switching, use tab() with the plugin + tab_key from
   the manifest, NOT click().
3. NEVER invent nac_ids. Every action MUST reference a name
   present in the tree. If you cannot find a matching name, ask
   the user a clarifying question via {message} with empty actions[].
4. Reply in language: es.
5. Output a single JSON object. NO prose, NO Markdown fences, NO
   explanation before or after. Your entire response must be the
   JSON. { "message": "...", "actions": [...] }
6. message is what the user sees + hears. Keep it short.
7. If the user said "cambia a <language>" emit a single
   change_locale action with the 2-letter code.
8. For data-tables: use dt_add_row / dt_remove_row / dt_edit_cell /
   dt_commit / dt_discard. Compute aggregates with dt_read_aggregate
   then read in the message.
   IMPORTANT: dt_add_row(table_id, values) is ATOMIC. It creates a
   new row with the values you provide in ONE call -- you do NOT
   click the "add row" button and then dt_edit_cell each field.
   Prefer dt_add_row over clicking the host's add-row button
   whenever you already have the row's content.
9. Bare 2-letter locale codes ('de','es','en') are language codes
   ONLY when followed/preceded by an explicit language word.

Multi-step tasks: your response IS the entire plan. Include ALL the
steps in one response.

Confirmation dialogs: if a destructive action opens a confirm dialog,
include the confirm click in the same response.

Data tables (v2.4 strict supports): each table declares supports[].
Calling dt_* on an operation not in supports[] throws. A table with
supports=[] is read-only.

Data tables (current_visibility): each table reports current_visibility
("visible" | "hidden"). dt_* on a hidden table is rejected.

Elements visibility (v2.4): each element reports visible:true|false.
visible:true -- target now. visible:false -- you must navigate first
(tab/parent click) before targeting.

Tab nac_ids use "tab." prefix per spec sec 2 -- copy from snapshot.

Snapshot labels are single-locale (already pre-resolved).

Action JSON shape (every action object MUST use "kind"):

   { "kind": "click",          "nac_id": "<id>" }
   { "kind": "click_by_verb",  "plugin": "<plugin>", "verb": "<verb>" }
   { "kind": "fill",           "nac_id": "<id>", "value": ... }
   { "kind": "select",         "nac_id": "<id>", "value": "..." }
   { "kind": "tab",            "plugin": "<plugin>", "tab_key": "<tab_key>" }
   { "kind": "tab_by_label",   "plugin": "..."|null, "label": "..." }
   { "kind": "go_to_section",  "nac_id": "..." }
   { "kind": "change_locale",  "locale": "<2-letter>" }
   { "kind": "say",            "text": "..." }
   { "kind": "dt_add_row",         "table_id": "...", "values": { ... } }
   { "kind": "dt_remove_row",      "table_id": "...", "row_id": "..." }
   { "kind": "dt_edit_cell",       "table_id": "...", "row_id": "...", "column": "...", "value": ... }
   { "kind": "dt_commit",          "table_id": "..." }
   { "kind": "dt_discard",         "table_id": "..." }
   { "kind": "dt_read_aggregate",  "table_id": "...", "agg_key": "...", "column": "..." }
```

### NAC snapshot (truncated; full pretty-indented version in `docs/T_MCP4_DUMP.txt`)

State at T_MCP4 setup: modal closed, list view visible, 15 invoices,
8 clients, language='es'.

The snapshot the agent receives includes:

- 4 plugins (topbar auto, invoice_app, invoice_edit_modal,
  confirm_cancel), with 33 + 23 + 2 elements respectively.
- 2 data-tables: `invoice_app.invoice_directory` (15 rows, supports=[]
  -- read-only) and `invoice_edit_modal.lines` (NOT REGISTERED yet
  because no invoice is open).
- Each element carries: `nac_id`, `role`, `action` (verb), `label`,
  `visible:true|false`.

Key elements visible (or registered as hidden) the agent sees in
`invoice_edit_modal`:

| nac_id                                    | role            | action verb        | visible at setup |
|-------------------------------------------|-----------------|--------------------|------------------|
| tab.cliente                               | tab             | --                 | false            |
| tab.lineas                                | tab             | --                 | false            |
| tab.condiciones                           | tab             | --                 | false            |
| invoice_edit_modal.client_name            | field           | --                 | false            |
| invoice_edit_modal.address                | field           | --                 | false            |
| invoice_edit_modal.email                  | field           | --                 | false            |
| invoice_edit_modal.add_line               | action          | add_row            | false            |
| invoice_edit_modal.save_step              | action          | save_step          | false            |
| invoice_edit_modal.payment_method         | field           | --                 | false            |
| invoice_edit_modal.term.0                 | option          | --                 | false            |
| invoice_edit_modal.observations           | field           | --                 | false            |
| invoice_edit_modal.confirm                | action          | confirm            | false            |

Plus `invoice_app.new_invoice_client` (field, visible) and
`invoice_app.new_invoice` (action verb=`new_invoice`, visible).

## 3. What each model emitted

**Claude Sonnet 4.6** (15 actions, post-fail):

```
[ 0] fill   invoice_app.new_invoice_client = "Acme"
[ 1] click_by_verb invoice_app verb=new_invoice
     --> FAILED: "No action with verb new_invoice found in plugin invoice_app"
[ 2] tab    invoice_edit_modal tab_key=tab.cliente
[ 3] fill   invoice_edit_modal.address = "Av. Corrientes 1234"
[ 4] fill   invoice_edit_modal.email = "contacto@acme.com"
[ 5] click_by_verb invoice_edit_modal verb=save_step
     --> FAILED: "Element invoice_edit_modal.save_step is not visible"
[ 6] tab    invoice_edit_modal tab_key=tab.lineas
[ 7] click_by_verb invoice_edit_modal verb=add_row
     --> FAILED: "Element invoice_edit_modal.add_line is not visible"
[ 8] click_by_verb invoice_edit_modal verb=save_step
     --> FAILED: ...
[ 9] tab    invoice_edit_modal tab_key=tab.condiciones
[10] fill   invoice_edit_modal.payment_method = "contado"
[11] click  invoice_edit_modal.term.0
     --> FAILED: not visible
[12] fill   invoice_edit_modal.observations = "proyecto urgente"
[13] fill   invoice_edit_modal.accepted = true
```

**Claude Haiku 4.5** (11 actions, post-fail with "no line matches /consultor/i"):
Same overall shape: clicks `add_line` instead of `dt_add_row(values)`;
new line is created with default `description="Nueva linea"`, not
`"consultoria"`, so the post-condition fails.

**Gemini 3.1 Flash Lite** (11 actions, post-fail with "no line matches /consultor/i"):
Same pattern. Gemini's plan is cleaner but the same critical error:
clicks the add-row button without atomically setting the values.

## 4. Where the agent gets confused (root cause analysis)

### Confusion A: dual representation of "add a line"

The NAC3 manifest exposes BOTH:

1. `invoice_edit_modal.add_line` -- an `action` element with verb
   `add_row` that, when clicked, creates an EMPTY row with default
   values.
2. `invoice_edit_modal.lines` -- a data-table with
   `supports: ["add_row", "remove_row", "edit_cell"]` that responds
   to `dt_add_row(table_id, values)` ATOMICALLY (row + values in
   one call).

These are *semantically equivalent for end-user clicks* but very
different for agents:

| Path                                              | Atomic?  | Knows new row id ahead of time? |
|---------------------------------------------------|----------|----------------------------------|
| click `add_line` -> dt_edit_cell each field       | No (2-N) | No (id is created post-click)    |
| dt_add_row(`invoice_edit_modal.lines`, {values})  | Yes (1)  | N/A (atomic)                     |

All three agents picked the UI-button path. The button is in the
manifest, has a clear verb, and looks like "the canonical way to add a
line". The system prompt tells them to prefer the primitive
("dt_add_row is ATOMIC. Prefer dt_add_row over clicking the host's
add-row button whenever you already have the row's content."), but
the models still pick the button. Reason hypothesised:

- The button is rendered exactly the same way as every other action
  (role=action, verb=add_row). It does not visually signal "I am
  redundant with a primitive".
- The agent is composing a 11-15 action plan in one response. Holding
  the "prefer primitive" rule in working memory while building the plan
  is harder than it sounds; the agent reflexively writes `click +
  edit_cell` because that is the visible UI flow.

After clicking the button, the agent CAN NOT emit `dt_edit_cell` to
fill the new row because *the new row id (e.g. L1) is created at
backend response time*. It is not in the snapshot the agent received
upfront, so the agent has no `row_id` to target with edit_cell. The
agent emits the click and moves on, leaving the row with default
values (description="Nueva linea", qty=1, unit_price=0).

### Confusion B: stale snapshot for multi-step flows

The agent's snapshot is captured at `setup()` time -- modal closed.
All `invoice_edit_modal` elements have `visible: false`. The agent
plans 11-15 actions in one shot:

- Action 1: open modal (makes step 1 visible).
- Action 5: click save_step. **But save_step lives in the step-2
  panel.** It is visible only after action 6 (tab.lineas). So action 5
  fires before save_step becomes visible -> rejected.

The agent does not have a way to express "wait for action N to make
this visible". The prompt tells it to "insert the right tab/parent
click before targeting" but for elements rendered conditionally inside
a wizard panel, the agent has to mentally simulate the panel
transitions across 15 actions. That fails for all three models.

### Confusion C: verb resolution ambiguity

Sonnet emitted `click_by_verb invoice_app verb=new_invoice`. The
runtime rejected with "No action with verb=new_invoice found in plugin
invoice_app". Looking at the snapshot, `invoice_app.new_invoice` is
registered with `actions: [{verb: "new_invoice", ...}]`. The error is
spurious -- the verb IS in the manifest. This looks like a runtime
bug in click_by_verb's resolution when the action's element-level
`action` field is set redundantly with the `actions[].verb` array
form. Worth opening a separate issue against nac-spec runtime.

### Why Raw DOM and MCP win where NAC3 loses

- **Raw DOM** wins because the agent emits Playwright clicks against
  CSS selectors. After clicking `#btn-add-line`, the new row's row-id
  appears in the DOM (`tr[data-row-id="L1"]`) and the **next** Playwright
  action can target the new row's input fields via aria-label like
  `[aria-label="Descripcion de la linea L1"]`. The agent CAN guess L1
  because line ids are sequential. Even if the guess is wrong, the
  next-row's id is also predictable.

- **MCP** wins because the tool catalog gives `add_invoice_line(invoice_id,
  description, qty, price)` as an atomic backend op. The agent does
  not need to mentally simulate panel state or row id materialisation
  -- it just calls the tool and gets `{line_id: "L1"}` back. Subsequent
  reads naturally use the returned id.

The architectural difference: **NAC3 v2.1's UI primitives are
intrinsically stateful (the post-click state matters and the agent
can not see it within a single turn)**, while MCP's tool catalog
is intrinsically functional (each tool call returns the new state).

## 5. Proposed NAC3 v2.4+ resolutions

Three orthogonal ideas, in increasing invasiveness:

### Option 1: snapshot annotation `companion_primitive` (already implemented)

When a button-action's verb matches a primitive on a data-table whose
scope_owner is the button's plugin, annotate the button with
`companion_primitive: "dt_add_row(invoice_edit_modal.lines, {values})"`
and `prefer_primitive: true`. The agent reads the hint and uses the
primitive.

**Effect observed in pilot:** no change. The agent still clicks the
button. Annotation needs to be louder, or the system prompt needs to
echo it more aggressively. Maybe a runtime rejection: "this button is
agent-deprecated; use dt_add_row instead".

### Option 2: parameterised actions (v2.3 `NAC.edit_field` pattern generalised)

Add `NAC.click_with_args(nac_id, args)` as a first-class primitive.
Hosts register handlers via
`NAC.registerActionHandler(plugin, action_id, handler)`. The handler
takes args and does the work atomically.

```
NAC.click_with_args('invoice_edit_modal.add_line',
  { description: 'consultoria', qty: 10, unit_price: 150 });
```

The agent can use the button + values atomically, mirroring MCP's
tool-call semantics inside NAC3. This is a real spec extension.

### Option 3: action-result feedback within a single agent turn

Currently the agent has no way to see the result of action N before
emitting action N+1 (single-response model). v2.4 could add a special
action like:

```
{ "kind": "snapshot", "after_action_index": 1 }
```

The runtime executes actions 0..1, captures a fresh snapshot, then
attaches it to the response so the agent can refine. But this is
multi-turn under the hood and changes the benchmark dynamics.

## 6. Conclusion

The T_MCP4 failure is a stable architectural finding for NAC3 v2.1:
**single-turn agents emitting long action sequences cannot reliably
materialise new entities** (rows, sub-records) because they cannot
reference yet-to-be-created ids in the same turn.

NAC3 v2.1 + the v2.4 enhancements piloted here (strict supports,
visibility hints, single-locale labels, hidden-element trim,
companion_primitive annotation) bring NAC3's input-token cost down to
~5.5K (essentially tied with MCP) and recover T1 + T_MCP1 to 1/1, but
do NOT close the T_MCP4 gap. To close it, NAC3 needs either:

- a parameterised click primitive (option 2 above), or
- a real action-result feedback step (option 3).

Both qualify as legitimate spec extensions; the choice is between
preserving the single-turn property of the contract (option 2 keeps
it; option 3 breaks it). Recommend option 2 for v2.4-final.
