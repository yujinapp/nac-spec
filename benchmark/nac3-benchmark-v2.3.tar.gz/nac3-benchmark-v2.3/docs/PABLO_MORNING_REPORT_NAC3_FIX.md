# NAC3 v2.3: data-table registration race fix + pilot status

**Status when you read this:** Stage D (full 15-iter matrix, 720 trials,
all 4 models x 4 tasks x 3 conditions x 15 iter) was kicked off at
~00:35 local time. Log: `/tmp/stageD.log`. Final outputs land in
`bench/results/pilot_v24_stageD/summary.md` whenever it finishes
(estimate 2-3h after kickoff). When you read this in the morning the
run should be done; check that summary.md for the full breakdown.

If the file doesn't exist yet, the run is still going -- inspect
`/tmp/stageD.log` (last line is `[NNN/180] task cond #iter ... OK/FAIL`).
At ~00:42 local time Sonnet was at 89/180; orchestrator does all
4 models sequentially. If something hung you can resume the failing
model by running `PILOT_ITER=15 PILOT_V23_DIR=... PILOT_MODELS=<the-one>
INVOICE_APP_URL=http://127.0.0.1:8080 npx tsx scripts/run_pilot_v23.ts`.

## TL;DR

The Sonnet T_MCP4 NAC3 regression you spotted (0/3 in the prior pilot
v23 N=3) was caused by **two compounding bugs** in the NAC3 stack, not
by the prompt change itself. The prompt change exposed them.

1. **Race on `dt_add_row` against just-rendered data-table.** When the
   agent emits `tab.lineas -> dt_add_row(invoice_edit_modal.lines, {...})`
   back-to-back, the dispatcher fires dt_add_row before the host's
   async chain (POST -> /api/state -> setState -> __nacSync ->
   registerDataTable) has had time to seed the table. Fixed in
   `nac-v2-extensions.js` with new `NAC.awaitDataTable(table_id, ms)`
   helper + wired into the bench dispatcher.

2. **`registerDataTable` throws on re-register, swallowed by host
   try/catch, aborts subsequent registrations in same sync function.**
   The fixture's `__nacSync(state)` calls
   `registerInvoiceAppDynamic -> registerListDataTable -> registerLinesDataTable`
   on every state render. The 2nd render throws on
   `invoice_app.invoice_directory` (already registered), the catch
   in `setState` swallows it, AND `registerLinesDataTable` is never
   reached. Result: `invoice_edit_modal.lines` is NEVER registered
   after the modal opens. Fixed by adding `NAC.syncDataTable(spec)`
   (upsert variant) to the v2.3 runtime + migrating the fixture
   decorator to use it.

Both fixes land in `vendor/nac-spec/js/nac-v2-extensions.js` so any
NAC3 adopter that hits this pattern (and there will be many -- the
`__nacSync` pattern is the documented LLM_WIRING sec 5 sync pattern)
inherits the resolution.

## Ladder of verification

| Stage | Scope | Result |
|-------|-------|--------|
| A | NAC3 / T_MCP4 / Sonnet / 1 iter | 1/1 (recovered from 0/3) |
| B | NAC3 / 4 tasks / 4 models / 1 iter | **16/16** |
| C | nac3+raw+mcp / 4 tasks / 4 models / 1 iter | nac3 15/16, raw 16/16, mcp 15/16 |
| D | nac3+raw+mcp / 4 tasks / 4 models / 15 iter | **running** |

### Stage C failure analysis

Two failures:

- **Sonnet T_MCP1_cancel_oldest_pending nac3**: post_condition_failed,
  1 action emitted. **Pre-existing flake**: the prior N=3 pilot also
  showed Sonnet 2/3 on this cell. Not a regression introduced by the
  fix.

- **Haiku T_V23_EDITOR_fix_monitor mcp**: post_condition_failed.
  **Pre-existing flake**: prior N=3 showed Haiku 1/3 on this cell.
  Not a regression.

Stage D will give a statistically meaningful read on whether these
flakes are intermittent (Stage D >= 13/15 -> flake) or systematic
(Stage D <= 5/15 -> real bug).

## Files touched

Runtime + spec:
- `vendor/nac-spec/js/nac-v2-extensions.js`: +`awaitDataTable()`,
  +`syncDataTable()`, +`NAC.DT_AWAIT_MS=600`, version bump
  2.1.0-rc1 -> 2.3.0-rc1.

Fixture (uses the new primitives):
- `bench/fixtures/invoice-app/pages/nac_decoration.js`: switched
  both `registerDataTable` calls in `__nacSync` to
  `(NAC.syncDataTable || NAC.registerDataTable)` so it works against
  both old and new runtimes.

Bench harness (consumes `awaitDataTable`):
- `bench/src/conditions/nac3.ts`: every dt_* dispatch case awaits
  the table registration before invoking the primitive.

Bench orchestration filters (so you can re-run any subset):
- `bench/src/harness_3way.ts`: `PILOT_CONDITIONS=nac3,raw,mcp` env
  and `PILOT_TASK_IDS=A,B,C` env knobs (defaults preserve old
  behavior). MCP server only starts when 'mcp' is in conditions.

## Spec doc updates pending

`vendor/nac-spec/SPEC.md` + `runtime/SPEC.md` + `runtime/CHANGELOG.md`
need v2.3 entries for:

- `NAC.awaitDataTable(table_id, timeoutMs)` -- new helper.
- `NAC.syncDataTable(spec)` -- upsert variant; emits
  `nac:dt:resynced` when called against an already-registered table.
- `NAC.DT_AWAIT_MS` -- default poll-ceiling for `awaitDataTable`,
  callers can override.
- LLM_WIRING.md sec 5 needs a paragraph: "Hosts re-running __nacSync
  on every render MUST use syncDataTable, not registerDataTable; the
  latter throws on re-register and can hide subsequent registrations
  via try/catch."

These are doc-only follow-ups; the runtime + benchmark code is already
correct. Want me to land them or leave for you?

## Other observations worth saving

### Sonnet's prompt-obedience profile

Sonnet was the ONLY model to consistently emit `dt_add_row` per the
v2.3 prompt rule #8. Haiku/Gemini/Deepseek all chose the
parameterised `click_by_verb add_row args={...}` path. Both are
spec-legal, but the registration race only bit the `dt_add_row`
path because `click_by_verb` triggers the host's add-row button
DOM handler (which fires AFTER the modal+table are fully rendered),
whereas `dt_add_row` calls the primitive directly with no wait.

This explains the asymmetry: Sonnet was punished for being more
obedient. Worth documenting in the LLM_WIRING.md "model behaviour
notes" appendix when we write it.

### Other NAC3 bugs we still owe a fix

From `docs/NAC3_2_3_IMPROVEMENTS.md` items not yet landed:

- Item 14 (runtime): `click_by_verb` resolution when the manifest
  declares `actions: [{verb, ...}]` per-element. Sonnet's `[1] click_by_verb invoice_app verb=new_invoice` failed with "verb not
  found" in the prior pilot even though the verb IS in the
  per-element actions[]. Resolver only walks the plugin-level
  actions[] array. Item 14 stands.

- Item 15 (runtime): `tab(plugin, tab_key)` short-form acceptance
  ('cliente' as well as 'tab.cliente'). Patched in the bench
  harness, reverted, belongs in the runtime once you sign off.

- Item 4 + item 1 (companion_primitive + parameterised click_by_verb)
  are partially shipped; the runtime + bench prompt now formalise
  the args payload, so I think we can call those closed.

## Cost so far

Approximate cost burned in stages A/B/C: $0.60 (mostly Sonnet).

Stage D estimate (15-iter, 720 trials, mixed conditions): ~$15-20.
Mostly raw-condition Sonnet runs (~28K tokens each).

## When you check Stage D

Read `bench/results/pilot_v24_stageD/summary.md`. The "Per-cell
breakdown" table gives you 4 models x 4 tasks x 3 conditions x 15
iter -> 48 cells. Each cell has a success rate and a "variance"
column (sample variance of success indicator). Cells with variance
>= 0.1 are flaky; cells with variance == 0 are deterministically
pass-or-fail.

The "Drop detail" section lists every iteration that didn't reach
full success, with `first_dispatch_fail` and `postcondition_detail`
so you can see if the remaining failures are still the two
pre-existing flakes or something new.

If anything regresses I'll have left a follow-up note in the same
directory. Otherwise the fix is ready to land in `nac-spec`
proper and the prior pilot_v23_n3 results can be regenerated to
publish the closed gap on T_MCP4.

-- Sumi
