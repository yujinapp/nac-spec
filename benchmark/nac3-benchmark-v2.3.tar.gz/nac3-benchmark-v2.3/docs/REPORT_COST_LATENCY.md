# Cost-latency trade-off — NAC3 vs MCP for production agents

**Audience:** technical founders, eng leadership choosing protocols. LinkedIn, X.

**TL;DR:** NAC3 and MCP charge similar money per task (US$2.35 vs US$1.72 for 200 runs each). But NAC3 delivers the same task in **1 round-trip instead of 3.5**, with **2.4× lower end-to-end latency**. What looks like equal cost on a balance sheet is a 2× UX gap in user wait time that compounds at scale.

---

## The numbers (600 runs, 5 models, 4 tasks)

| Cond | Success | Latency p50 | Latency p95 | Round-trips | Cost (200 runs) |
|---|---|---|---|---|---|
| **MCP** | 78.5% | 5.5s | varies | **3.5 turns** | $1.72 |
| **NAC3** | **95.5%** | **3.1s** | varies | **1 turn** | $2.35 |
| **Raw DOM** | 91.0% | 7.4s | varies | 1 turn | $5.93 |

Same task, same model roster, same prompt — but NAC3 is **76% faster end-to-end than MCP**.

---

## The trade-off properly framed

- **MCP charges less per LLM call** because each call carries less context.
- **NAC3 charges more per call** because the full UI surface goes into the prompt once.
- **Total tokens-in is comparable**: MCP 7.7k * 3.5 turns ≈ 27k effective context replayed across turns; NAC3 11.4k in one shot.
- **What scales linearly with users is wall-clock time**, not just dollars.

For a chatbot or in-app copilot:
- 200ms per LLM round-trip = MCP costs 700ms × 200 users = 140s of compound wait time per minute of usage.
- NAC3 costs 200ms × 200 users = 40s. 3.5× less perceived latency for the same task.

For backend automation (no human watching): the difference is minor — go with whichever is easier to integrate.

For frontend automation (every second visible to the user): NAC3 wins by 2-3× UX margin.

---

## Cost per success (excluding silent damage)

This is where it gets interesting. Raw DOM passes 91% of CI checks, but **15% of those passes are silent damage** — the test succeeds while the model emitted phantom selectors. In production, those runs break.

Re-computed with silent damage excluded:

| Cond | Honest success | Cost / honest success | Cost / total run |
|---|---|---|---|
| MCP | 78.5% | $0.011 | $0.009 |
| **NAC3** | **95.5%** | **$0.012** | $0.012 |
| Raw DOM | 76.0% (91% - 15% silent) | $0.039 | $0.030 |

**NAC3 and MCP are tied on cost-per-honest-success ($0.011 vs $0.012). Raw DOM is 3-4× more expensive when you only count runs that actually worked.**

This is the number a CFO cares about: cost per task that did its job, not cost per API call that returned 200.

---

## What changes with cheap models?

The breakdown by model is striking. Gemini 3.1 Flash Lite (the cheapest in our roster) does 95% success at NAC3 for **$0.04 total across 120 runs** — pennies. Same model in raw DOM: 87% success at $0.10. Same model in MCP: 80% success at $0.03.

**Cheap models become capable when given structure.** NAC3's shared-surface manifest gives the model exactly the context it needs in one shot. The cost of "richer protocol" is paid by token efficiency; the gain is unlocking cheap models for tasks that previously required frontier models in MCP mode.

This means: production deployments that fork to expensive models (Sonnet, GPT-4o) for UI automation could fall back to Gemini Flash Lite or DeepSeek under NAC3 with marginal quality loss.

---

## When MCP beats NAC3

- **Backend tools where tool-use is the natural surface** (file ops, CRM API calls, integrations): MCP's tool catalog beats NAC3's UI manifest.
- **Server-to-server automation** where latency isn't user-perceived: the round-trip cost is amortized into batch processing.
- **Existing MCP-integrated stacks**: changing to NAC3 has integration cost; if your team has MCP in muscle memory, the marginal switch isn't worth the latency win unless UX directly suffers.

---

## When Raw DOM beats nothing

This benchmark didn't find a scenario. The 15% silent damage rate plus 31k token cost per run rules out Raw DOM for production CI. Even prototyping is cheaper with NAC3 because the protocol prevents the worst class of failure.

The only argument for Raw DOM today: **no engineering investment required**. You can start with Raw DOM in week 1, but you'll migrate to NAC3 or MCP when scaling.

---

## Methodology notes

- Latency measured end-to-end from prompt dispatch to postcondition evaluation, NOT just LLM call.
- Cost computed per provider pricing as of 2026-05-19. Anthropic credits, OpenAI credits, DeepSeek/Google free-tier-equivalent.
- Latency varies by region (this dataset: Argentina → US-East). Customers in EU or APAC see different absolute numbers.

Full dataset: `results/N10_final/`. 600 runs, 5 models, 3 protocols, 4 tasks, manifest_checksum `67db3eef3658`.

---

*Next reading: technical deep-dive in `REPORT_PROTOCOL.md`; model-fit table in `REPORT_MODEL_FIT.md`.*
