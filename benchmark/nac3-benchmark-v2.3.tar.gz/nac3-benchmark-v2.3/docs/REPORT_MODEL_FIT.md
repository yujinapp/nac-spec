# Model fit per protocol — cheap models become capable when given structure

**Audience:** r/MachineLearning, X research, ML engineers choosing models for production.

**TL;DR:** Across 5 models × 3 protocols × 4 tasks × 10 iter (N=600), the gap between Sonnet 4.6 and GPT-4o-mini collapses under NAC3 (95.0% vs 95.0%) while it stays wide under MCP (85.0% vs 72.5%) and Raw DOM (100% vs 72.5%). Protocol structure unlocks cheap models. Frontier capability is wasted when the protocol is unconstrained.

---

## Setup

- **N=600** (5 models × 3 conditions × 4 tasks × 10 iter)
- **Tasks:** T1_add_monitor (atomic), T_MCP1_cancel (exploratory), T_MCP4_create_invoice (compound), V23_EDITOR (atomic async)
- **Runtime:** NAC `2.2.1`, manifest_checksum `67db3eef3658`
- **Date:** 2026-05-19
- **Cost:** ~US$15 total

---

## Success rate matrix

| Model | mcp | nac3 | raw | total |
|---|---|---|---|---|
| **Sonnet 4.6** | 85.0% (34/40) | **97.5%** (39/40) | **100%** (40/40) | 94.2% |
| **Haiku 4.5** | 75.0% (30/40) | 97.5% (39/40) | 97.5% (39/40) | 90.0% |
| **DeepSeek-chat** | 82.5% (33/40) | 82.5% (33/40) | **100%** (40/40) | 88.3% |
| **Gemini Flash Lite** | 77.5% (31/40) | **100%** (40/40) | 85.0% (34/40) | 87.5% |
| **GPT-4o-mini** | 72.5% (29/40) | **100%** (40/40) | 72.5% (29/40) | 81.7% |

---

## Variance by condition

```
                    Range   Spread   Std-like
mcp     72.5 - 85.0   12.5pp   moderate
nac3    82.5 - 100    17.5pp   moderate (driven by DeepSeek nac3 T_MCP4 outlier)
raw     72.5 - 100    27.5pp   wide
```

NAC3 has the **lowest cross-model variance** if you exclude DeepSeek's T_MCP4 weakness (a model-specific semantic issue, not protocol). MCP is moderate. Raw DOM is wide — model capability dominates outcome.

---

## The cheap-model unlock

GPT-4o-mini gets:
- **40/40 (100%) in NAC3** — same as Sonnet 4.6 in Raw DOM.
- 29/40 (72.5%) in MCP.
- 29/40 (72.5%) in Raw DOM.

Gemini 3.1 Flash Lite gets:
- **40/40 (100%) in NAC3** — same as Sonnet 4.6 in Raw DOM.
- 31/40 (77.5%) in MCP.
- 34/40 (85%) in Raw DOM.

**A cheap model under NAC3 matches a frontier model under Raw DOM.** This is the most counter-intuitive finding: protocol structure is worth more than model capability for UI tasks.

The reason: NAC3 frontloads the entire interactive surface into one prompt. The model needs to plan in one shot, not maintain state across tool-call turns. Cheap models are good at "given this complete picture, emit JSON" but bad at "remember 5 tool calls ago and decide the next one."

MCP demands sequential planning; cheap models fall over. NAC3 demands one-shot emission with full context; cheap models thrive.

---

## Where models collapse

### MCP collapses

- **GPT-4o-mini MCP T_MCP4 = 0/10 + 11 retries.** The model loses track of customer IDs across turns. Asks the human ("`No se pudo crear la factura, el ID del cliente es desconocido`") instead of looking it up.
- **Haiku 4.5 MCP** (8 turns_max in T_MCP4): hits max_turns in compound tasks despite the anti-halt prompt. Tool orchestration capability cap.
- **DeepSeek MCP T1 = 6/10**: when the task has light ambiguity ("the open invoice"), DeepSeek asks for confirmation instead of inferring from `list_invoices`. Mid-tier MCP failure pattern.

### Raw DOM collapses

- **GPT-4o-mini Raw T1 = 0/10**: writes "Nueva linea" (the field placeholder) into the field instead of "monitor" (the value). Model confuses placeholder semantics with data when the only context is raw HTML.
- **Gemini Raw T_MCP4 = 7/10 with 4 silent damage**: emits selector chains that work due to default behavior but with phantom intermediate steps. Worst case for production.

### NAC3 has fewer collapse modes

- **DeepSeek NAC3 T_MCP4 = 3/10**: the only systematic NAC3 weakness in our corpus. DeepSeek emits `consultoria` (singular masculine) but the postcondition checks `/consultor/i` — a regex match issue. Other models emit the right word. Semantic edge case, not protocol failure.
- **Haiku V23 = 9/10**: 1 timing failure. Not silent damage.
- All other NAC3 cells: ≥9/10.

---

## The new frame for model selection

Old frame: "use Sonnet/GPT-4 for complex tasks, cheap models for simple ones."

New frame (with NAC3): "use **NAC3 + Gemini Flash Lite or GPT-4o-mini** for any UI task. Use Sonnet only when:"
1. The task is compound with cross-step semantics (DeepSeek failed here, Haiku 9/10, Sonnet 10/10).
2. You need MCP for backend integration and your team is locked into tool-use orchestration.
3. You're prototyping without a NAC3-decorated UI yet.

**Cost saving from this switch:** Gemini Flash Lite NAC3 120 runs = $0.04. Sonnet Raw 120 runs = $4.16. **100× cheaper at 100% vs 100% honest success rate.**

---

## Caveats per model

| Model | NAC3 ceiling | MCP ceiling | Raw ceiling | Recommendation |
|---|---|---|---|---|
| Sonnet 4.6 | 100% expected at scale | 90-95% (compound multi-turn) | 100% (clean prompt-following) | Frontier baseline. Use when other models exhausted. |
| Haiku 4.5 | 95-97% (1 timing miss) | 75-85% (tool-use moderate) | 95-97% | Default mid-tier. Cheaper than Sonnet, similar NAC3 quality. |
| DeepSeek-chat | 90% (T_MCP4 weak on compound) | 80-85% | 95-100% | Strong in Raw, weak in NAC3 T_MCP4 specifically. |
| Gemini Flash Lite | 100% (4/4 task perfect) | 77-80% | 80-85% | **Best NAC3 model in our roster.** Cheap. |
| GPT-4o-mini | 100% (4/4 perfect) | 72-77% | 72-77% | **Best NAC3 / cost ratio.** Avoid MCP + Raw. |

---

## What's not in this dataset

- **Reasoning models (o4-mini, GPT-5.5)**: validated at N=1 post-fix, not at N=10. Their reasoning capability may or may not change the picture for compound tasks.
- **Opus 4.7**: excluded for ROI (10-15× cost of Sonnet without success gain at this task complexity).
- **Open-weight models** (Llama 4, Qwen 2.5, etc.): not tested. Could be 6th model in expansion run.

---

## Reproducibility + raw data

- Full dataset: `results/N10_final/` (55 jsonl files, 600 rows).
- Per-run trazabilidad: each row carries `runtime_version=2.2.1`, `bench_version=0.1.0`, `manifest_checksum=67db3eef3658`.
- Reproduce: `bash scripts/run_final_600.sh` + Anthropic + OpenAI + DeepSeek + Gemini API keys in `.env`.
- Cost: ~US$15. Time: ~1.5h.

---

*Companion reports: `REPORT_PROTOCOL.md` (technical, HN) — `REPORT_COST_LATENCY.md` (commercial, LinkedIn).*
