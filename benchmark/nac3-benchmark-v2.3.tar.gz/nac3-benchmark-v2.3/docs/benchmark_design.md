# Decisiones ejecutivas pre-N=10 — Benchmark NAC3 v2.4

**Para:** Claude Code, antes de lanzar la corrida grande.
**Por:** Claude (Opus 4.7), 2026-05-19, consolidando análisis propio + análisis de fallos de Claude Code.
**Estado:** acciones requeridas antes de quemar US$50-100 en N=10.

---

## Resumen ejecutivo

Tres decisiones críticas antes del benchmark grande:

1. **Cuatro problemas técnicos** identificados en el piloto N=1 que producen sesgo artificial. Tres tienen fix concreto, uno es bug del fixture. Resolver los cuatro antes de N=10.
2. **Roster de 8 modelos en N=10 es ineficiente**. Estrategia tier diferenciado: ITER=10 sobre los baratos (Haiku, DeepSeek, Gemini), ITER=3 sobre los caros (Sonnet, GPT-4o-mini), ITER=3 condicional sobre los problemáticos (o4-mini, GPT-5.5, Opus).
3. **Piloto de validación pre-N=10**: 12-20 runs para confirmar que los fixes funcionan antes de escalar. Costo: US$1-3. Sin esto, el dataset grande va a tener los mismos sesgos.

---

## 1. Hallazgos consolidados del piloto N=1 (96 runs)

### 1.1 Lo que es información real

- **NAC3 elimina alucinaciones por construcción.** 0 hallucinations en NAC3 (0/32), 0 en MCP (0/32), 3 en Raw DOM (3/32). El validator `isActionSafe` cumple su rol. Esto es reproducible y publicable.
- **NAC3 tiene la mejor relación costo/confiabilidad en aggregate.** 28/32 success, $2.15 total, tokens_in_mean 12,830. Comparado con Raw ($4.22, tokens 31,350) y MCP ($1.36 pero solo 26/32 success).
- **MCP gana en costo absoluto pero pierde en latencia.** turns_mean 4.1 vs 0.9 NAC3/Raw. Latencia end-to-end MCP 13.7s vs NAC3 7.7s — NAC3 es 1.8× más rápido percibido por usuario.
- **MCP exige modelos buenos en tool-use multiturno.** Sonnet 4.6/Opus 4.7/DeepSeek/Gemini Flash Lite todos 4/4 en MCP. GPT-4o-mini cae a 1/4. o4-mini a 2/4. Modelos chicos colapsan en MCP, NAC3 los salva.
- **Las 3 alucinaciones de Raw son particularmente peligrosas:** las 3 tuvieron `success=true` Y `hallucinated_target=true`. Selectores fantasma que pasan postcondition por suerte. Esto **es el escenario que NAC3 elimina estructuralmente** — el frame "Raw passes CI silently with phantom selectors that break in production" es vendible.

### 1.2 Lo que NO es información — sesgo del piloto

- **6 de 13 fallos son artefactos técnicos**, no señal sobre el protocolo:
  - 4 parse_error por token cap en modelos OpenAI reasoning (problema de harness, no de modelo o protocolo).
  - 1-2 V23-EDITOR failures por async handler del fixture (problema de fixture).
  - 1 gpt-4o-mini MCP halt prematuro por sobrecaución (problema de prompt para modelo específico).
- **NAC3 tiene 4 fallos atribuidos** (Opus V23-EDITOR, GPT-5.5 V23+T_MCP4, o4-mini T_MCP4). De estos, 3 son por los artefactos mencionados arriba. Solo 1 es señal real.

**Implicación crítica:** si N=10 se corre sin los fixes, NAC3 va a verse artificialmente peor de lo que es, y los modelos OpenAI van a verse artificialmente catastróficos. Datos publicables comprometidos.

---

## 2. Los cuatro problemas técnicos y sus fixes

### 2.1 Problema A: token cap mata a reasoning models en parse

**Síntoma:** 4 runs con `tok_out=3072` exacto (cap), `n_actions=0`, `parse_error: "no JSON object found"`. Todos en GPT-5.5 y o4-mini, todos en T_MCP4 (la tarea más compleja).

**Diagnóstico:** los reasoning models consumen tokens en "pensar" y se quedan sin presupuesto para emitir el JSON final. Cap actual de 3072 tokens es insuficiente para T_MCP4 en estos modelos.

**Fix:**

```typescript
// En llm.ts (línea ~213)
const REASONING_MODELS = ['o4-mini', 'o4', 'o5', 'gpt-5.5', 'gpt-5-pro'];
const isReasoner = REASONING_MODELS.some(m => model_id.includes(m));
body.max_completion_tokens = isReasoner ? 8192 : (args.max_tokens ?? 1024);
```

Costo: tokens adicionales solo se gastan si el modelo razona. Para modelos non-reasoning el cap queda en 1024 (sin cambio). Para reasoners sube a 8192. Costo marginal estimado: +30% en runs de reasoners. Aceptable.

**Métrica adicional:** agregar `truncated_by_cap` (bool) al output: true si `tok_out === max_completion_tokens` Y `parse_error`. Permite distinguir "modelo verdaderamente atascado" de "harness mal configurado".

### 2.2 Problema B: V23_EDITOR fix asíncrono produce false negatives

**Síntoma:** 3 modelos (Opus 4.7 NAC3, GPT-5.5 NAC3, GPT-4o-mini MCP) fallaron V23_EDITOR con mensaje declarando "aplicando corrección gramatical" pero DOM sin cambios. `target_emitted_resolved=true`, `target_reached_dom=true`. El click llegó. Solo no se reflejó a tiempo.

**Diagnóstico:** el handler de `ai_correct_syntax` en el fixture es asíncrono (~150ms desde click hasta render del corregido). El postcondition lo lee antes. Sonnet, DeepSeek, Gemini Flash Lite y Haiku no fallan porque sus drafts emitieron un click adicional (`save` o equivalente) que dio tiempo al render. Es artefacto del fixture, no del protocolo.

**Fix (elegir uno):**

- **Fix A (fixture):** hacer `ai_correct_syntax` sincrónico en el fixture — aplicar la corrección directamente sobre el textarea antes de retornar del handler.
- **Fix B (harness):** agregar `await page.waitForFunction(...)` antes de evaluar postcondition de V23_EDITOR. Esperar hasta 300ms o hasta detectar cambio en el textarea de la línea L1.

**Recomendación: Fix B**. Es más realista — en producción los handlers son asíncronos siempre. El postcondition debe tolerar timing real.

```typescript
// En el postcondition de V23_EDITOR
await page.waitForFunction(() => {
  const ta = document.querySelector('textarea[aria-label*="Descripcion"][aria-label*="L1"]');
  return ta && ta.value && ta.value !== 'monitr LCD 24 plgada';
}, { timeout: 300 });
```

Costo: hasta 300ms adicionales por run de V23_EDITOR. Despreciable.

### 2.3 Problema C: gpt-4o-mini en MCP hace halt prematuro

**Síntoma:** GPT-4o-mini falla MCP 3/4 con mensajes tipo *"Necesito el ID de la factura abierta..."*. El modelo pide al humano información que ya tiene disponible vía tool calls previos.

**Diagnóstico:** modelo chico + MCP multiturno = halt por sobrecaución. No es falla del protocolo MCP per se; es falla del modelo orquestando tool-use.

**Fix:** ajustar el system prompt de la condición MCP con instrucción explícita:

```
Adicional al system prompt MCP existente:

"You have access to tool results from previous calls in this conversation.
Do NOT ask the user for IDs, names, or data that you can fetch via tools.
Always call tools first before asking. Only ask the user if a tool returns
an explicit ambiguity that cannot be resolved by another tool call."
```

**Decisión necesaria:** este ajuste cambia el prompt MCP para todos los modelos. ¿Aplicarlo universal o solo cuando model_id es de modelos chicos?

**Mi voto:** aplicar universal. La regla es buena para cualquier modelo. Sonnet/DeepSeek/Gemini no la necesitan pero tampoco les hace daño.

**Métrica adicional:** registrar `asked_human` (bool) — true si actions=[] y message contiene "necesito", "podrías indicarme", "qué". Permite cuantificar el patrón.

### 2.4 Problema D: hallucinaciones con success=true se reportan como success

**Síntoma:** 3 runs en raw + T_MCP4 con `success=true` Y `hallucinated_target=true`. La factura quedó creada pero algunos selectores emitidos eran fantasmas. La postcondition pasó por suerte (defaults del fixture cerraron el flujo).

**Diagnóstico:** la métrica binaria `success` oculta la calidad de la ejecución. Un run que pasa CI con dispatches fantasma es exactamente el escenario de producción que NAC3 elimina — y el frame público necesita poder mostrarlo.

**Fix: tres categorías de hallucination separadas en el reporting.**

| Categoría | Condición | Significado |
|---|---|---|
| `hallucination_filtered` | dispatch rechazado pre-side-effect por validador | NAC3: `isActionSafe` filtra el target inventado. **El runtime previene daño.** |
| `hallucination_reached_failed` | dispatch ejecutó, side effect produjo `success=false` | Raw/MCP: target inventado, runtime no filtra, side effect falla. **Daño visible.** |
| `hallucination_reached_succeeded` | dispatch ejecutó con target inventado, postcondition pasó por suerte | Raw: silent damage. **El run pasa CI pero la calidad es mala. Worst case en producción.** |

Agregar al output JSON:

```typescript
interface RunResult {
  // ... existentes
  hallucination_category: 'none' | 'filtered' | 'reached_failed' | 'reached_succeeded';
}
```

Y al reporte agregado:

```
| Cond | hallucination_filtered | hallucination_reached_failed | hallucination_reached_succeeded |
|------|------------------------|------------------------------|--------------------------------|
| nac3 | N (filtered count)     | 0                            | 0                              |
| mcp  | 0                      | M_fail                       | M_silent                       |
| raw  | 0                      | R_fail                       | R_silent                       |
```

**Esta métrica es lo más vendible del benchmark.** Mostrar que NAC3 filtra hallucinations *antes* del DOM mientras Raw las deja pasar silenciosamente es el argumento más fuerte que tenés. Vale la pena la complejidad de tracking.

---

## 3. Estrategia de roster diferenciado para N=10

### 3.1 Análisis costo-valor por modelo

Basado en los 96 runs del piloto:

| Modelo | Success 12 | Cost/run avg | $/success | Notas |
|---|---|---|---|---|
| Gemini 3.1 Flash Lite | 12/12 | $0.0006 | $0.0006 | Mejor ratio. Tier free. |
| DeepSeek | 12/12 | $0.0017 | $0.0017 | Excelente. |
| Haiku 4.5 | 11/12 | $0.0068 | $0.0074 | El único miss es fixable (prompt). |
| Sonnet 4.6 | 12/12 | $0.0220 | $0.0220 | Standard caro pero confiable. |
| GPT-4o-mini | 8/12 | $0.0007 | $0.0011 | Falla MCP — fixable con prompt nuevo. |
| Opus 4.7 | 11/12 | $0.3331 | $0.3634 | **10-15× más caro que Sonnet sin success extra.** |
| GPT-5.5 | 9/12 | $0.0739 | $0.0985 | 3 fallos por token cap (fixable). |
| o4-mini | 8/12 | $0.0156 | $0.0234 | Mismo problema cap + overthinking en MCP. |

### 3.2 Roster propuesto

**Tier 1 (ITER=10) — modelos baratos y sólidos:**
- Gemini 3.1 Flash Lite
- DeepSeek
- Haiku 4.5
- GPT-4o-mini (después del fix de prompt MCP)

Total: 4 modelos × 10 iter × 3 cond × 4 task = **480 runs**. Costo estimado: **US$3-5**.

**Tier 2 (ITER=5) — frontier de Anthropic y reasoning de OpenAI (post-fix):**
- Sonnet 4.6
- GPT-5.5 (después del fix de cap)

Total: 2 modelos × 5 iter × 3 cond × 4 task = **120 runs**. Costo estimado: **US$15-25**.

**Tier 3 (ITER=3) — opcionales si querés cross-provider completo:**
- Opus 4.7
- o4-mini (después del fix de cap)

Total: 2 modelos × 3 iter × 3 cond × 4 task = **72 runs**. Costo estimado: **US$20-40**.

**Total con tier 1+2+3:** 672 runs, US$38-70. Estadísticamente más sólido que 8 modelos × ITER=10 que costaría US$100-200.

### 3.3 Mi recomendación

**Empezá solo con Tier 1.** 480 runs, US$3-5, una tarde de cómputo. Te da significancia estadística en los 4 modelos baratos donde NAC3 muestra sus mejores resultados. Si esos números son sólidos, agregar Tier 2 después.

Tier 3 (Opus + o4-mini) tiene mal ROI técnico — los datos del piloto sugieren que están al límite de lo que sus arquitecturas hacen bien. Reservar para validación final si el dataset principal pide más cross-provider coverage.

---

## 4. Piloto de validación pre-N=10

Antes de N=10 completo, una corrida pequeña valida que los fixes funcionan.

### Setup

- Modelos: GPT-5.5, o4-mini, gpt-4o-mini, Opus 4.7
- Tareas: solo las que fallaron en el piloto N=1 (T_MCP4, V23_EDITOR, T_MCP1)
- Iteraciones: 3 por celda
- Condiciones: las relevantes según fallo

**Runs específicos:**

| Modelo | Cond | Task | Por qué |
|---|---|---|---|
| GPT-5.5 | nac3, raw | T_MCP4 | Validar fix cap → no más parse_error |
| o4-mini | nac3, raw, mcp | T_MCP4 | Validar fix cap |
| o4-mini | mcp | V23_EDITOR | Validar que sin cap falla, no por overthinking |
| Opus 4.7 | nac3 | V23_EDITOR | Validar fix async |
| GPT-5.5 | nac3 | V23_EDITOR | Validar fix async |
| GPT-4o-mini | mcp | T1, T_MCP4, V23_EDITOR | Validar fix prompt MCP |
| Haiku 4.5 | mcp | T_MCP1 | Validar fix prompt MCP |

Total: ~12-18 runs. Costo: US$0.50-2. Tiempo: 5-10 minutos.

### Criterios de aprobación

- Parse_errors de GPT-5.5/o4-mini en T_MCP4 → 0 con el cap nuevo.
- V23_EDITOR con Opus y GPT-5.5 → 3/3 success post-fix (o falla por razón distinta a "DOM intacto").
- GPT-4o-mini MCP → al menos 2/3 en cada tarea con el prompt nuevo.
- Haiku 4.5 MCP T_MCP1 → success post-fix.

Si los cuatro criterios se cumplen, los fixes están validados y se procede a N=10. Si alguno falla, iteración antes de escalar.

---

## 5. Cambios al pipeline de reporting

Para hacer el dataset N=10 publicable, el reporting necesita estos cambios:

### 5.1 Métricas nuevas por run

```typescript
interface RunResult {
  // existentes
  
  // NUEVAS
  hallucination_category: 'none' | 'filtered' | 'reached_failed' | 'reached_succeeded';
  truncated_by_cap: boolean;     // tok_out === max_completion_tokens AND parse_error
  asked_human: boolean;           // actions=[] AND message contiene patrón de pregunta
}
```

### 5.2 Tablas agregadas a producir

1. **Success rate por (modelo × condición × tarea)** — la habitual.
2. **Hallucination breakdown por condición** — 3 categorías mencionadas en 2.4.
3. **Cost efficiency (USD per successful run) por (modelo × condición)** — incluyendo solo runs con `hallucination_category != 'reached_succeeded'`. Esto castiga apropiadamente a Raw donde aplique.
4. **Latency end-to-end mediana + p95 por condición** — el frame "MCP más barato en USD, NAC3 más rápido en tiempo de usuario".
5. **Failure mode taxonomy** — la tabla del análisis de Claude Code, ampliada con N=10.
6. **Truncation events** — runs donde `truncated_by_cap=true`. Si después del fix son 0, confirmar.

### 5.3 Tres reportes finales

- `REPORT_PROTOCOL.md` — NAC3 vs MCP vs Raw, foco en hallucination category breakdown.
- `REPORT_COST_LATENCY.md` — trade-off costo/latencia per modelo.
- `REPORT_MODEL_FIT.md` — qué modelos sirven para qué condición (ej: GPT-4o-mini no es bueno para MCP, o4-mini para tareas complejas, etc).

---

## 6. Checklist accionable

En orden estricto de ejecución:

1. [ ] **Implementar fix A** (token cap 8192 para reasoning models en `llm.ts`).
2. [ ] **Implementar fix B** (waitForFunction de 300ms en postcondition V23_EDITOR).
3. [ ] **Implementar fix C** (instrucción anti-halt en system prompt MCP).
4. [ ] **Implementar fix D** (3 categorías de hallucination + métricas `truncated_by_cap` y `asked_human`).
5. [ ] **Correr piloto de validación** (12-18 runs específicos del paso 4).
6. [ ] **Verificar criterios de aprobación** del piloto.
7. [ ] **Si aprobado: lanzar N=10 con Tier 1** (4 modelos, 480 runs, US$3-5).
8. [ ] **Analizar Tier 1**. Si los hallazgos del piloto N=1 se confirman estadísticamente, decisión: ¿Tier 2 también?
9. [ ] **Lanzar Tier 2 condicional** (Sonnet, GPT-5.5 con fix, ITER=5).
10. [ ] **Tier 3 solo si justificado** (Opus, o4-mini) — probablemente no.
11. [ ] **Generar 3 reportes finales** según 5.3.

---

## 7. Decisiones que requieren tu OK explícito

Antes de avanzar, confirmá:

1. **¿Aplicar fix C (instrucción anti-halt en MCP prompt) universal o solo a modelos chicos?** Mi voto: universal.
2. **¿Roster final?** Tier 1 (4 modelos) solo, o Tier 1+2 (6), o los tres (8)? Mi voto: empezar con Tier 1, escalar según resultados.
3. **¿Mantener Opus 4.7 en el dataset?** Mal ROI técnico, pero relevante para "frontier coverage". Mi voto: no, salvo que quieras un punto de "incluso el modelo más caro no salva un protocolo mal diseñado" — útil para narrativa.
4. **¿Fix B fixture vs harness?** Recomiendo fix en harness (waitForFunction). Más realista, no requiere tocar fixture.

Sin estas 4 decisiones, el plan no es ejecutable. Con ellas, los 11 ítems del checklist son trabajo lineal.

---

## Lo no negociable

- **No correr N=10 sin los fixes A-D.** Va a producir un dataset publicable pero comprometido.
- **El piloto de validación es obligatorio.** US$1-3 que ahorran sesgo en US$30-70.
- **La métrica de hallucination separada en 3 categorías es lo que vende el benchmark.** No omitirla por simplicidad.
- **No publicar resultados sin disclaimer de N y modelos exactos.** Aún con N=10 sobre 4 modelos, hay que ser explícito en limitaciones (un solo fixture, español, sin SSR, etc).

---

## 8. Caveats del runtime post-fix (anotados durante implementación)

### 8.1 Decisiones tomadas sobre los 4 puntos del bloque 7

- **Fix C universal** (no per-model). Razón: mantener un único prompt MCP
  reproducible. Sin esto el reporte tendría que llevar asterisco "se usó
  prompt distinto para gpt-4o-mini", lo que arruina la comparabilidad.
- **Roster Tier 1 sólo** (Gemini 3.1 Flash Lite, DeepSeek, Haiku 4.5,
  gpt-4o-mini). 480 runs cuando se autorice escalar. Tier 2/3 quedan
  gated por la lectura de Tier 1.
- **Opus 4.7 fuera del dataset principal**. ROI técnico bajo
  ($0.36/run × 96 = US$35 sin señal extra). Sí queda dentro del
  re-piloto post-fix para validar Fix B (V23 async).
- **Fix B en harness** (no fixture). El postcondition poll-ea el backend
  hasta 300ms buscando el delta de seed. Más realista: en producción los
  handlers son async.

### 8.2 Cut de prompt entre baseline (paso 9 v1) y baseline limpio (paso 9 v2)

El cambio de prompt MCP del Fix C invalida los 32 runs MCP del piloto
N=1 actual. **No mezclar** en agregados publicables: el prompt v1 decía
"For ambiguous references, ask the user" (regla 2 anterior), el v2 dice
"call tools first, only ask if a tool returns explicit ambiguity"
(regla 2 nueva + regla 10 de sensible-defaults).

Operativo: el reporte final usa exclusivamente paso 9 v2 (post-fix) +
los Tier 1/2/3 que sigan. `PASO9_REPORT.md` v1 queda como registro
histórico; los datos nuevos van a `PASO9_REPORT.md` v2 (regenerar el
file completo, no append). El `system_prompt_hash` (fnv1a sobre el
prompt) cambia entre v1 y v2 — útil para chequear en jsonl crudo de
qué cut viene cada run.

### 8.3 Caveat del `asked_human` post-Fix-C: falsos positivos por ambigüedad legítima

La nueva regla 2 del prompt MCP empuja al modelo a llamar tools antes
de preguntar. La métrica `asked_human=true` se activa cuando el modelo
devuelve `actions=[]` y el mensaje matchea patrones de pregunta
("necesito...", "podrías indicarme...", "¿cuál es...?", finish con `?`,
etc).

**Limitación intrínseca:** la métrica no distingue dos casos
estructuralmente distintos:

1. **Halt malo** (lo que queremos cazar): el modelo se rinde y pide al
   humano un dato que sí puede obtener via tool (gpt-4o-mini pidiendo
   un ID que está expuesto por `list_invoices`).
2. **Halt válido** (no es problema): el modelo encuentra ambigüedad
   real que ninguna tool puede resolver (dos clientes con nombre exacto
   "Acme S.A." en `list_customers`). En ese caso la regla 2 nueva
   permite preguntar al humano.

**Por qué decidimos vivir con el falso positivo:**

- Las 4 tareas del benchmark (T1, T_MCP1, T_MCP4, V23_EDITOR) **no
  contienen ambigüedad legítima**. Hay una única factura abierta, una
  única factura pendiente más antigua, un único cliente "Acme", una
  única línea L1 con typo. Cualquier `asked_human=true` en este corpus
  es estructuralmente un halt malo. La métrica está calibrada para
  *este* corpus.
- Si el corpus se extiende en el futuro con tareas que sí tengan
  ambigüedad real (T5: "factura para Acme" cuando hay 3 Acme), va a
  haber que partir la métrica en `asked_human_total` vs
  `asked_human_avoidable`. Esto requiere anotación manual por tarea o
  un classifier que mire si el contexto resuelve la ambigüedad. **No
  vale la pena ahora**: agrega complejidad por un bug que el corpus
  actual no expone.
- En el reporte final se incluye disclaimer explícito: *"`asked_human`
  cuenta cualquier `actions=[]` con mensaje-pregunta. En el corpus
  actual no hay ambigüedad legítima, así que toda activación es halt
  evitable. Si querés reusar esta métrica en otro corpus, validá
  primero que la tarea sea resoluble sin input adicional."*

**Cómo se lee en la tabla del paso 9 v2:**

- Tier 1 model con `asked_human=0` en MCP → Fix C funcionó.
- Tier 1 model con `asked_human≥1` en MCP → caso para abrir
  manualmente el jsonl y leer el `parsed_message`. Si es un halt malo
  (modelo pidió un ID que tenía disponible), regression del Fix C.
  Si por algún motivo el modelo recodificó el mensaje como pregunta
  pero hizo el trabajo, anotar como falso positivo y excluir del count
  publicable.

### 8.4 Caveat del `truncated_by_cap`

La heurística combina dos señales: `output_tokens >= cap_applied` y
(`finish_reason ∈ {length, max_tokens}` OR el payload no termina con
`}` ni `]`). Cubre los tres providers:

- **Anthropic**: `stop_reason='max_tokens'` cuando hit del cap. La
  heurística primaria.
- **OpenAI**: `finish_reason='length'`. Idem.
- **Google Gemini**: a veces no popula `finishReason` aún con cap hit;
  ahí cae al fallback heurístico "payload no cierra con } o ]". Puede
  producir falso positivo si el modelo intencionalmente emite un
  string que no es JSON puro (sólo prosa, condición de parse_error).

Si el reporte muestra `truncated_by_cap` > 0 con `output_tokens < cap`,
es bug en la heurística — abrir jsonl crudo y revisar la condición.

### 8.5 Caveat del Fix B (V23_EDITOR poll de 300ms)

El postcondition ahora poll-ea hasta 300ms al backend buscando un
delta vs seed. Si el modelo nunca emitió la acción correcta, los 300ms
no cambian el resultado (sigue devolviendo
`no line description changed`). Pero el run dura ~300ms más en el caso
fallido. En el caso éxito real ahora con timing realista, el poll cierra
en cuanto detecta el delta — sin penalización adicional.

Risk: si en algún flow patológico el modelo emite la corrección + un
segundo edit que vuelve a poner el texto original dentro de la
ventana de 300ms, el postcondition podría salir antes del segundo edit
y reportar success cuando el estado final es "no change". Improbable
con los modelos del roster, pero queda anotado.

---

*Fin del documento ejecutivo. Actualizado 2026-05-19 con caveats
operativos post-implementación.*
