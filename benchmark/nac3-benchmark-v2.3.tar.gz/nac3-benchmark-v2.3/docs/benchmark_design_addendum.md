# Addendum — Controles de igualdad e instrucciones operativas pre-N=10

**Documento complementario a:** `benchmark_design.md`
**Fecha:** 2026-05-19, post-resultados paso 9 v2 (96 runs, 8/96 fallos, 93.75% global)
**Para:** Claude Code, ejecución del Tier 1 N=10
**Status:** estos controles deben verificarse antes de cada batch del benchmark grande

---

## 1. Status de fixes implementados (paso 9 v2 → N=10)

| Fix | Descripción | Estado | Validación empírica |
|---|---|---|---|
| **A** | `max_completion_tokens=8192` para reasoning models | ✅ Implementado | 0 `parse_error` en 96 runs (vs 6 pre-fix). GPT-5.5 perfecto 12/12. |
| **B** | `waitForFunction(300ms)` en postcondition V23_EDITOR | ✅ Implementado | Opus 4.7 perfecto 12/12 (era 11/12). Cierra timing del fixture. |
| **C** | Anti-halt instruction en system prompt MCP universal | ⚠️ Parcial — requiere iteración (sec 2) | gpt-4o-mini +2 mejora, pero Haiku regresó −2 por hallucination declarativa. |
| **D** | `hallucination_category` (none / filtered / reached_failed / reached_succeeded) | ✅ Implementado | Reporting muestra 3 silent damage en Raw, 0 en NAC3/MCP. Métrica funciona. |
| **E** | `asked_human` heurístico | ⚠️ Funciona pero con falsos positivos. Refinar pre-N=10. | 5 modelos × 1 MCP run cada uno tienen asked_human=true con success=true. |

**Conclusión:** fixes A, B, D validados empíricamente. C requiere matiz. E requiere refinamiento menor.

---

## 2. Ajuste pendiente: iteración del prompt MCP (corrige Haiku regression)

### 2.1 Diagnóstico

El prompt anti-halt universal de Fix C produjo un trade-off no anticipado en Haiku 4.5:

- **Pre-Fix C:** Haiku pedía confirmación al humano (1 fallo MCP — modo "halt visible").
- **Post-Fix C:** Haiku declara éxito sin emitir acciones (3 fallos MCP — modo "hallucination declarativa").

Ejemplos del modo nuevo de fallo:
- T_MCP1: *"Se canceló INV-001"* con 0 tool calls.
- T_MCP4: *"Factura creada y confirmada para Acme"* con 0 tool calls.

El modelo chico interpretó *"no pidas confirmación, asume defaults razonables"* como licencia para reportar acciones sin ejecutarlas.

### 2.2 Texto del prompt MCP corregido

Reemplazar el bloque anti-halt actual por:

```
You have access to tool results from previous calls in this conversation.

When you need data (IDs, customer info, line items, etc), call the relevant
tool FIRST. Do not ask the user for data that any tool in your inventory
can fetch. Default to calling tools rather than asking.

If you call a tool and the result is unambiguous, proceed with the task.
If the result is ambiguous in a way that no other tool can resolve, ask
the user — but only after you have exhausted relevant tool calls.

CRITICAL: never claim success in your message unless the corresponding
tool call was actually emitted and returned successfully. Reporting
"task completed" without emitting tool calls is a contract violation.
If your message says you did X, your actions array must include the
tool call that performs X.
```

La última oración es la **clave** que castiga la hallucination declarativa. Haiku necesita esa restricción explícita.

### 2.3 Validación previa antes de Tier 1

Antes de lanzar Tier 1 completo (480 runs):

- **Mini-piloto:** 3 runs Haiku MCP × 3 tareas (T_MCP1, T_MCP4, V23_EDITOR) = 9 runs total. Costo: ~US$0.10.
- **Criterio de aprobación:** Haiku MCP ≥ 6/9 success (vs 1/4 en paso 9 v2). Si no llega, ajustar prompt antes de Tier 1.

Si Haiku no se recupera, dos opciones:
- (a) Aceptar que Haiku es débil en MCP — documentarlo y seguir.
- (b) Aplicar el prompt restrictivo SOLO a modelos pequeños vía flag `model_size` en el harness.

Mi voto: (a) primero. La realidad de modelos pequeños en MCP es información válida para el post.

---

## 3. Refinamiento de `asked_human` (Fix E menor)

### Problema

El heurístico actual matchea cualquier mensaje con palabras tipo *"¿podrías indicarme"* o *"querés que"* — pero estas frases también aparecen en mensajes post-éxito ("✓ Factura creada. ¿Querés que muestre el detalle?"). 5 modelos en MCP tienen `asked_human=true` con `success=true` por esta razón.

### Fix

Condicionar el flag a contexto de fallo:

```typescript
asked_human = (
  (actions.length === 0 || success === false) &&
  message_matches_question_pattern(parsed_message)
)
```

Es decir: solo flaggear `asked_human=true` cuando el modelo preguntó **y** no produjo acciones útiles. Una pregunta post-éxito no cuenta como halt.

---

## 4. Igualdad de condiciones cross-protocolo

Lo que debe ser **idéntico** entre las 3 (o 5) condiciones para que el benchmark sea válido:

### 4.1 Capa modelo

- **Mismo `model_id` exacto** entre conditions del mismo run.
- **Mismo `temperature`** (recomendado: 0 para reproducibilidad).
- **Mismo `max_completion_tokens`** — pero **dinámico según familia** (8192 para reasoners, 1024 para otros).
- **Mismo `max_turns`** (recomendado: 10, suficiente para tareas compound).
- **Mismo `timeout` por llamada LLM** (recomendado: 90s).

### 4.2 Capa task

- **Mismo prompt de tarea verbatim** entre conditions. El prompt no debe mencionar el protocolo.
- **Misma postcondition** evaluada con el mismo código sobre el mismo DOM resultante.
- **Mismo `waitForFunction` policy** post-dispatch (300ms para V23_EDITOR específicamente; default para el resto).
- **Mismo punto de partida del fixture** (resetear estado a snapshot inicial antes de cada run).

### 4.3 Capa system prompt

El system prompt tiene una parte común y una parte protocolo-específica:

| Sección | NAC3 | MCP | Raw | NAC3-Forge-silent | NAC3-Forge-assisted |
|---|---|---|---|---|---|
| Rol y formato de output (JSON only) | Idéntico | Idéntico | Idéntico | Idéntico | Idéntico |
| Reglas anti-hallucination | Idéntico | Idéntico | Idéntico | Idéntico | Idéntico |
| Descripción del protocolo | NAC3 verbs + describe | MCP tools + tool_choice | Raw DOM HTML | NAC3 verbs (igual a NAC3) | NAC3 verbs (igual a NAC3) |
| Anti-halt instruction | No aplica | **Texto de sec 2.2** | No aplica | No aplica | No aplica |

La diferencia entre NAC3, NAC3-Forge-silent y NAC3-Forge-assisted es **solo el manifest decorado**, no el system prompt. Esto aísla la variable "calidad de decoración" de la variable "system prompt".

### 4.4 Capa harness

- **Mismo motor de dispatch** (Playwright, misma versión).
- **Mismo browser** (Chromium headless, mismas flags).
- **Mismo viewport** (1280×720, fixed).
- **Mismo orden de ejecución** entre conditions para el mismo modelo+task (recomendado: serial, no concurrente, para evitar contaminación de timing).
- **Mismo logging exhaustivo** — todos los runs producen el mismo set de columnas en el JSONL.

---

## 5. Igualdad de condiciones cross-modelo

Lo que debe ser idéntico entre modelos del mismo tier:

### 5.1 Configuración numérica

- **`temperature`**: 0 si el modelo lo soporta; default mínimo soportado si no (algunos modelos no permiten 0).
- **`max_completion_tokens`**: 8192 para reasoners (GPT-5.5, o4-mini), 1024 para otros. Documentar la diferencia.
- **`max_turns`**: 10 para todos.
- **`timeout`**: 90s para todos.

### 5.2 Pricing tabla

Para que el comparativo de costos sea válido, las tarifas deben estar actualizadas a la fecha de ejecución para todos los modelos:

```typescript
const PRICING_PER_MTOK_USD = {
  'claude-sonnet-4-6': { input: 3.00, output: 15.00 },
  'claude-haiku-4-5':  { input: 0.80, output: 4.00 },
  'claude-opus-4-7':   { input: 15.00, output: 75.00 },
  'gemini-3.1-flash-lite': { input: 0.075, output: 0.30 },
  'deepseek-chat':     { input: 0.27, output: 1.10 },
  'gpt-4o-mini':       { input: 0.15, output: 0.60 },
  'gpt-5.5':           { input: 5.00, output: 25.00 },
  'o4-mini':           { input: 3.00, output: 12.00 },
  // confirmar valores antes de Tier 1
};
```

**Acción:** verificar y actualizar la tabla con valores oficiales del 2026-05-19 antes de ejecutar.

### 5.3 Reasoning tokens

Para modelos reasoning (o4-mini, GPT-5.5), el harness debe registrar:

- `reasoning_tokens` (si la API lo expone) — separado de output tokens.
- `output_tokens` (visible al usuario).
- Costo calculado sobre input + reasoning + output según pricing.

Si la API no separa reasoning de output (ej. modo "summary only"), reportar `output_tokens` total y notar la limitación.

---

## 6. Anti-sesgos específicos para Tier 1 N=10

Sumado a los anti-sesgos del brief original:

### 6.1 Orden de ejecución

- **Run order:** por iteración, no por modelo. Es decir: iteración 1 ejecuta los 4 modelos × 3 conds × 4 tasks = 48 runs antes de pasar a iteración 2. Esto distribuye el efecto temporal (carga de API providers, deriva de modelos via updates).
- **Seed/randomization:** no aplica (temperature=0 hace cada run determinístico modulo APIs no-deterministic).

### 6.2 Re-runs y reintentos

- **Si un run falla con `api_error` o `timeout`**, reintentar hasta 2 veces.
- **Si un run falla por `parse_error` (no debería pasar con Fix A) o `post_condition_failed`**, NO reintentar — es resultado legítimo del run.
- **Reportar `retries_used` por run** para auditoría.

### 6.3 Fixture state isolation

- **Antes de cada run:** reset del fixture al estado inicial (snapshot del DOM + estado interno NAC3 + estado del backend mock).
- **Verificar isolation:** un run que crea factura no debe afectar el siguiente. Si el fixture acumula state, los modelos "ricos" en orden temprano contaminan a los "tardíos".

### 6.4 Concurrencia

- **Default: serial.** N=10 × 4 modelos × 3 conds × 4 tasks = 480 runs serial toma ~6-8 horas según latencia.
- **Si se decide paralelizar:** un browser context por modelo, máximo. Nunca mezclar 2 conditions del mismo run en paralelo (contaminación de fixture state).

### 6.5 Auditoría de runs

- **Playwright traces.zip** habilitados para todos los runs (no solo fallos). 480 × ~1MB = 500MB total, aceptable.
- **Almacenamiento:** `results/N10_tier1/traces/{model}__{task}__{cond}__{iter}.zip`.

---

## 7. Métricas adicionales a registrar para Tier 1

Sumado a las del brief original (secciones 7.3 y 7.4):

| Métrica | Razón |
|---|---|
| `reasoning_tokens` | Separar costo de reasoning de output para reasoners. |
| `time_to_first_action_ms` | Tiempo desde dispatch del prompt al primer action emitido. Mide pensamiento previo a acción. |
| `dispatch_to_dispatch_ms_p50` | Mediana de tiempo entre dispatches consecutivos. Mide overhead del protocolo per-action. |
| `actions_per_turn_mean` | Acciones promedio emitidas por turno LLM. NAC3 ≥ 4 esperado; MCP ≈ 1 esperado. |
| `tool_call_round_trips` | Para MCP: número de tool calls que requirieron respuesta antes de actuar. |

---

## 8. Instrucciones operativas para Claude Code (en orden)

En orden estricto, no saltear pasos:

### Bloque 1 — Pre-ejecución (validación)

1. **Implementar fix del prompt MCP** (sec 2.2). Reemplazar el bloque anti-halt actual por el texto propuesto.
2. **Refinar `asked_human`** (sec 3) — condicionar a `actions.length === 0 || success === false`.
3. **Actualizar pricing tabla** (sec 5.2) con valores 2026-05-19.
4. **Implementar métricas adicionales** (sec 7) en el harness.
5. **Mini-piloto Haiku MCP** — 9 runs (3 tasks × 3 iter) Haiku MCP con prompt nuevo. Costo: ~US$0.10. Criterio: ≥ 6/9 success.

### Bloque 2 — Ejecución Tier 1

6. **Si mini-piloto aprueba:** lanzar Tier 1.
   - **Roster:** Gemini 3.1 Flash Lite, DeepSeek, Haiku 4.5, gpt-4o-mini.
   - **Iteraciones:** 10 por celda.
   - **Conditions:** MCP, NAC3, Raw.
   - **Tasks:** las 4 actuales (T1_add_monitor, T_MCP1_cancel_oldest_pending, T_MCP4_create_invoice_full, T_V23_EDITOR_fix_monitor).
   - **Total:** 4 × 10 × 3 × 4 = 480 runs.
   - **Costo estimado:** US$3-5.
   - **Tiempo estimado:** 6-8 horas serial.
   - **Orden:** por iteración (todos los modelos en iter 1, luego iter 2, etc).

7. **Durante la ejecución:** monitorear que ningún `parse_error` aparezca, ningún `truncated_by_cap`, ningún `api_error` repetido. Si hay > 5% de errores no atribuibles al modelo, abortar y revisar.

### Bloque 3 — Análisis post-Tier 1

8. **Generar reportes:** los mismos del brief original (PROTOCOL, COST_LATENCY, MODEL_FIT) con N=10 statistical power.
9. **Tabla de hallucination_category** ampliada — esperamos ver 0 reached_succeeded en NAC3/MCP y números mayores en Raw, confirmando el patrón del paso 9 v2 a N=10.
10. **Tabla de asked_human** — verificar el patrón "MCP induce más clarification al usuario que NAC3" en N=10. Si se confirma, es hero number para Post 1.

### Bloque 4 — Decisión Tier 2

11. **Si Tier 1 muestra patrones claros y reproducibles:** considerar Tier 2 (Sonnet 4.6 + GPT-5.5 × 5 iter). Costo adicional: ~US$15-25.
12. **Si Tier 1 muestra inestabilidad o ruido:** iterar el harness antes de gastar en modelos caros.

### Bloque 5 — No tocar sin OK

- **No agregar Opus 4.7 ni o4-mini** sin confirmación. Mal ROI según paso 9 v2.
- **No cambiar el prompt base** durante la ejecución de Tier 1. Si emerge problema, anotar y resolver post-Tier 1.
- **No cambiar el fixture** durante la ejecución. Cualquier bug debe quedar registrado para análisis, no fixed mid-run.

---

## 9. Criterios de "dataset publicable"

Después de Tier 1 N=10 (480 runs), el dataset se considera publicable si:

1. **`truncated_by_cap == 0`** en todas las celdas. (Fix A funcionó.)
2. **`parse_error == 0`** en todas las celdas. (Fix A funcionó.)
3. **`hallucination_category: reached_succeeded > 0` en Raw y `== 0` en NAC3.** Confirma el frame estructural.
4. **Cada celda con N=10 tiene success rate dentro de ±10% de su valor en paso 9 v2** (excepto Haiku MCP que esperamos mejora post-fix sec 2.2).
5. **El patrón de `asked_human` en MCP T_MCP4** se confirma en al menos 30% de runs MCP × T_MCP4 cross-model.
6. **No hay diferencia > 2× entre `e2e_ms` median y p95** dentro de la misma celda (indica baja variabilidad por celda).

Si alguno de los 6 criterios falla, el dataset requiere investigación antes de publicar.

---

## 10. Resumen de qué decidió Yujin (registrado)

A confirmar antes de ejecutar:

- [ ] Roster final Tier 1: Gemini Flash Lite + DeepSeek + Haiku 4.5 + gpt-4o-mini. ¿Confirmado?
- [ ] Iteraciones: 10. ¿Confirmado?
- [ ] Prompt MCP nuevo (sec 2.2): ¿aprobado verbatim o requiere ajuste?
- [ ] Anti-halt prompt: ¿aplicar universal o restringir a modelos chicos?
- [ ] Opus 4.7 y o4-mini: ¿incluir en Tier 3 opcional, o descartar?

Sin estos 5 ítems confirmados, no lanzar Tier 1.

---

*Fin del addendum. Adjuntar a `benchmark_design.md` como sección 13 o documento separado linkeado.*
