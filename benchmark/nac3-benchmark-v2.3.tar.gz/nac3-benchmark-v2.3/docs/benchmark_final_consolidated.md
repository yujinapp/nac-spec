# Adenda al brief-benchmark-v24-grande.md — Estado consolidado post-iteración

**Documento padre:** `brief-benchmark-v24-grande.md` (plan original con 5 condiciones, 4+ modelos, 10 iter)
**Documentos relacionados:**
- `brief-benchmark-v24-equality-controls.md` — controles cross-protocolo/cross-modelo
- `decisiones-ejecutivas-pre-N10.md` — decisiones técnicas pre-corrida grande
- `brief-corrida-final-600-runs.md` — pipeline operativo final de 8 pasos
- `diagnostico-RFC-V24-05.md` — notas separadas sobre la RFC de authority

**Estado:** plan original ajustado por evidencia empírica del piloto N=1 (96 runs) + Tier 1 N=10 (480 runs).

---

## 1. Cambios al plan original (resumen ejecutivo)

| Aspecto | Plan original | Plan final |
|---|---|---|
| **Condiciones** | 5 (MCP, Raw, NAC3 Claude Code, Forge silent, Forge assisted) | **3** (MCP, NAC3, Raw) — las 2 condiciones de Forge se posponen a corrida separada |
| **Modelos** | 4-5 cross-proveedor frontier | **5 confirmados**: Gemini 3.1 Flash Lite, DeepSeek V3, Haiku 4.5, gpt-4o-mini, Sonnet 4.6 |
| **Modelos descartados** | — | Opus 4.7 (mal ROI 10-15× costo), GPT-5.5 y o4-mini (validados a N=1, no aportan suficiente a N=10), Gemini Flash mid-tier (lite alcanza) |
| **Iteraciones** | 10 | **10 confirmado** |
| **Total runs** | 800 (5 cond × 4 mod × 10 iter × 4 task) | **600** (3 cond × 5 mod × 10 iter × 4 task) |
| **Costo estimado** | US$20-50 | **US$15-25** (validado: Tier 1 con 4 modelos baratos costó $1.30 en 480 runs) |
| **Tarea adicional propuesta** | T-MCP2 exploratoria | No agregada — las 4 actuales cubren el espacio suficientemente |
| **Función "usuario" de assisted** | Decidir opciones (a/b/c) | N/A — Forge fuera de scope esta corrida |
| **Métricas de decoración** | 4 grupos (tiempo, costo, calidad, runtime) | Postponed con Forge — solo métricas de operación esta vez |

---

## 2. Por qué Forge se postpone

El plan original incluía 5 condiciones donde 3 eran variantes NAC3 con diferentes orígenes del manifest (Claude Code, Forge silent, Forge assisted). Esto requería Forge en estado MVP funcional + piloto de validación de reproducibilidad de Forge (sec 6 del brief original).

**Realidad:** Forge no está listo a tiempo para esta corrida. La decisión correcta es:

- **Esta corrida (final):** mide el protocolo NAC3 vs MCP vs Raw con manifest decorado a mano (estado de adopción real hoy).
- **Corrida posterior (Forge benchmark):** cuando Forge esté listo, medirá las 2 variantes de Forge contra el baseline de manifest manual.

Esta separación es metodológicamente mejor que esperar — el dataset del protocolo no depende del producto comercial, y los dos comparativos quedan editorialmente separados (Post 1 sobre protocolo, Post 2 sobre Forge eventual cuando exista).

**Implicación para el plan original:**
- Sección 1.5 (planos comparativos) reducida a NAC3 vs MCP vs Raw.
- Sección 4.3 (definir "usuario" de Forge assisted): no aplica esta corrida.
- Sección 6 (piloto de validación de Forge): no aplica esta corrida; aplica antes del Forge benchmark separado.
- Sección 7.1 + 7.2 (métricas de decoración): no aplican esta corrida; aplican al Forge benchmark.

---

## 3. Aprendizajes empíricos del piloto + Tier 1 (96 + 480 runs)

### 3.1 Lo que se confirmó del plan original

- **Anti-sesgos cross-protocolo funcionan.** Mismo runtime para las 3 conditions, fixture isolation entre runs, orden por iteración — todo verificado en Tier 1.
- **El roster diferenciado en tiers no era necesario.** El plan original proponía Tier 1 ITER=10, Tier 2 ITER=5, Tier 3 ITER=3 para diferenciar por costo. La corrida real demostró que con los 5 modelos seleccionados (sin Opus, sin reasoners caros) ITER=10 cuesta solo US$15-25 total — no hay razón para mantener tiers diferenciados.
- **Las 4 tareas actuales cubren el espacio suficiente.** Atomic (T1, V23), exploratoria (T_MCP1), compound (T_MCP4). Agregar T-MCP2 exploratoria pura no aportaba información nueva — la exploración ya está cubierta en T_MCP1.

### 3.2 Lo que cambió el frame público

- **NAC3 no es "más barato que MCP" en USD.** Empata en costo absoluto, pero gana en latencia (2× menor), turns (3.5× menos), y silent damage (7× menos). El frame correcto es trade-off, no superioridad simple.
- **`asked_human` emergió como métrica vendible.** No existía en el plan original. MCP fuerza al modelo a pedir clarification al usuario en ~30% de tareas donde NAC3 expone state visualmente. Cuantifica una diferencia UX real entre protocolos.
- **NAC3 tiene silent damage propio (~2.5% en Tier 1, todos en DeepSeek + T_MCP4).** El frame original asumía "NAC3 zero hallucinations". La realidad: NAC3 reduce silent damage 7× vs Raw pero no a cero. Hay que reportarlo honestamente. Investigación pendiente puede bajarlo más (ver `brief-corrida-final-600-runs.md` paso 1).
- **Cuatro fixes técnicos aplicados durante el desarrollo del benchmark.** Token cap a 8192 (reasoners), waitForFunction(300ms) en V23, anti-halt en MCP system prompt, categorización de hallucination en 4 buckets. Cap default 2048 (non-reasoners) pendiente para la corrida final. Todos documentados en `decisiones-ejecutivas-pre-N10.md` y `brief-benchmark-v24-equality-controls.md`.

### 3.3 Lo que se descartó

- **Opus 4.7 del roster.** Mal ROI técnico (10-15× costo de Sonnet sin success extra). Reservado para validación posterior si justificado.
- **o4-mini y GPT-5.5 del roster final.** Validados a N=1 post-fix con resultados sólidos. No aportan dato cualitativo nuevo a ITER=10. Pueden agregarse como expansión "frontier + reasoning coverage" en corrida adicional.
- **Métricas de reasoning_tokens detalladas.** Sin reasoners en el roster final, irrelevantes.

---

## 4. Configuración final del benchmark publicable

### 4.1 Setup

```
Total runs: 600
  5 modelos × 3 conditions × 4 tasks × 10 iteraciones

Modelos:
  - claude-sonnet-4-6      (frontier, Anthropic)
  - claude-haiku-4-5       (mid-tier, Anthropic)
  - deepseek-chat          (cheap, DeepSeek)
  - gemini-3.1-flash-lite  (cheap, Google)
  - gpt-4o-mini            (cheap, OpenAI)

Conditions:
  - MCP   (tool-based)
  - NAC3  (shared surface, v2.4-rc1 con V24-01 + V24-02 fixes)
  - Raw   (HTML DOM serializado)

Tasks:
  - T1_add_monitor                  (atomic)
  - T_MCP1_cancel_oldest_pending    (exploratory)
  - T_MCP4_create_invoice_full      (compound, multi-step)
  - T_V23_EDITOR_fix_monitor        (atomic, async-handler)

Output directory:
  results/N10_final/

Trazabilidad académica:
  - Cada JSONL incluye runtime_version (ej. "2.4.0-rc1")
  - Cada JSONL incluye manifest_checksum (sha256 truncado a 12 chars)
```

### 4.2 Parámetros del harness

| Parámetro | Valor | Justificación |
|---|---|---|
| `temperature` | 0 (si soporta) | Reproducibilidad |
| `max_completion_tokens` (non-reasoner) | 2048 | Pendiente — paso 2 del brief operativo |
| `max_completion_tokens` (reasoner) | 8192 | Confirmado — Fix A validado |
| `max_turns` | 10 | Suficiente para tareas compound |
| `timeout` | 90s por llamada LLM | Conservador |
| `retries` | 2 solo si `api_error` o `timeout` | NO retry para parse_error o post_condition |
| Orden de ejecución | Por iteración, no por modelo | Anti-sesgo temporal |
| Concurrencia | Serial | Evitar contaminación de fixture state |

### 4.3 Métricas a registrar (consolidado)

**Por run, en el JSONL:**

- Identidad: `run_id`, `model_id`, `condition`, `task_id`, `iteration`, `started_at`, `ended_at`.
- Trazabilidad: `runtime_version`, `manifest_checksum`.
- Operación: `success` (bool), `error_class`, `error_detail`, `n_actions_emitted`, `n_model_turns`, `n_tool_calls`.
- Tokens y costo: `input_tokens`, `output_tokens`, `cache_creation_input_tokens`, `cache_read_input_tokens`, `serialization_overhead_tokens`, `total_cost_usd`.
- Latencia: `llm_latency_ms`, `dispatch_latency_ms`, `end_to_end_ms`, `time_to_first_action_ms`.
- Calidad: `hallucinated_target` (bool), `hallucination_category` (none/filtered/reached_failed/reached_succeeded), `target_emitted_resolved`, `target_reached_dom`.
- Comportamiento del modelo: `asked_human` (refinado: solo true si actions=[] o success=false), `truncated_by_cap`, `clarification_emitted`.
- Tareas específicas: `parsed_message`, `postcondition_detail`.
- Auditoría: Playwright trace.zip por run.

### 4.4 Pipeline de ejecución

El pipeline operativo está en `brief-corrida-final-600-runs.md`, 8 pasos con criterios de aprobación. Resumen:

1. Investigar 4 silent damage de DeepSeek nac3 T_MCP4 (15-30 min).
2. Subir cap default a 2048.
3. Aplicar fix de manifest si hipótesis A/B (condicional).
4. Agregar `runtime_version` y `manifest_checksum` al JSON.
5. Confirmar roster (5 modelos) y crear `results/N10_final/`.
6. Ejecutar 600 runs.
7. Verificar 6 criterios del addendum sec 9.
8. Generar 3 reportes finales.

---

## 5. Caveats honestos a publicar

El dataset debe declarar explícitamente estas limitaciones:

### 5.1 Sobre el alcance

- **Un solo fixture.** Aplicación de facturación en español, single-page, sin SSR. No cubre marketplaces, dashboards en tiempo real, ni apps con auth multi-step.
- **Cuatro tareas.** Atomic + exploratory + compound + async-handler. No cubre flujos de pago, búsqueda fuzzy, o navegación cross-page.
- **Cinco modelos.** Frontier (Sonnet), mid (Haiku), cheap (DeepSeek, Gemini, GPT-4o-mini). No incluye Opus 4.7, GPT-5.5, o4-mini, ni modelos open-weight grandes.
- **Un solo idioma.** Español (los prompts y el fixture). Comportamiento en inglés puede diferir marginalmente.

### 5.2 Sobre las métricas

- **NAC3 silent damage no es cero.** Es ~2.5% en Tier 1 (4/160 runs), 7× menor que Raw pero no estructuralmente perfecto.
- **MCP cost depende del proveedor.** MCP empata NAC3 en costo USD con los 5 modelos del roster; con modelos más caros (Opus) podría cambiar.
- **`asked_human` es heurístico.** Refinado para reducir falsos positivos (sec 3 del addendum) pero no es 100% preciso.
- **Latencia depende de proveedor + región.** Los números reflejan ejecución desde Argentina hacia US-East API endpoints. Diferentes regiones pueden variar.

### 5.3 Sobre la reproducibilidad

- **Modelos son no-determinísticos** a pesar de `temperature=0`. Anthropic y OpenAI no garantizan determinismo bit-a-bit.
- **Pricing cambia.** La tabla de costos refleja precios al 2026-05-19. Re-ejecutar el benchmark en otra fecha puede dar costos distintos.
- **Manifest es de v2.4.0-rc1.** Versiones futuras pueden cambiar nac_id resolution u otras propiedades del runtime.

---

## 6. Estructura de los tres reportes finales

Cada reporte tiene audiencia y foco distintos. Compartido entre los tres: setup completo, trazabilidad, caveats de sec 5.

### 6.1 `REPORT_PROTOCOL.md` (Post 1 — técnico)

- Audiencia: HN, Lobsters, dev.to.
- Foco: comparar protocolos.
- Hero numbers: silent damage (NAC3 ~2.5% vs Raw 17.5%), success rate, latencia, turns.
- Frame: *"NAC3 trades higher per-dispatch cost for fewer round-trips, lower end-to-end latency, and structural reduction of phantom selectors."*
- Posición vs MCP: *"MCP for backend, NAC3 for frontend — complementary, not competing."*
- Limitations: las 4 de sec 5.1.

### 6.2 `REPORT_COST_LATENCY.md` (Post 2 — comercial/UX)

- Audiencia: LinkedIn, X tech founders.
- Foco: trade-off costo/latencia + UX.
- Hero numbers: NAC3 paga 0% más que MCP por 2× menos latencia + 3.5× menos round-trips + `asked_human` 30%+ en MCP vs 0% en NAC3.
- Frame: *"What looks like equal cost on a balance sheet is a 2-3× UX gap in user wait time and a clarification round-trip difference that compounds over scale."*
- 200 palabras de análisis "What this means for production agents."

### 6.3 `REPORT_MODEL_FIT.md` (Post 3 — research)

- Audiencia: r/MachineLearning, X research.
- Foco: cross-modelo, comportamiento bajo protocolo.
- Hero numbers: varianza cross-model por condición, success rate de cheap models por protocolo, qué modelos colapsan dónde.
- Frame: *"Cheap models become capable when given structure. Here's the curve across protocols."*
- Análisis de failure modes: por modelo y por protocolo.

---

## 7. Lo que cambia para el roadmap post-publicación

Una vez publicados los 3 reports:

1. **Corrida separada para Forge** cuando esté listo. Reusar la metodología de este benchmark (5 modelos, 4 tasks, 10 iter) pero agregar las 2 condiciones Forge. Total: 5 × 5 × 4 × 10 = 1000 runs si reusa modelos. Costo: ~US$25-40.
2. **Expansión opcional cross-provider:** GPT-5.5 + o4-mini × 10 iter sobre las mismas condiciones. Agrega "reasoning coverage" sin invalidar el dataset principal. Costo: ~US$30-50.
3. **Benchmark V24-05 (authority + auto-interposition):** una vez implementada la RFC, comparar NAC3 v2.4 vs NAC3 v2.5 sobre tareas que requieren confirm (cancel, delete, irreversible). Nuevo benchmark dedicado.
4. **Aplicación real (no fixture):** eventualmente, ejecutar el benchmark contra una app real (Yujin CRM o adopter externo). Sirve como validación external.

Estos 4 trabajos están fuera del scope de la corrida final, pero son la roadmap natural del dataset N10_final.

---

## 8. Checklist de cambios respecto al brief original

Lo que se mantiene del `brief-benchmark-v24-grande.md`:

- [x] Objetivos generales (publicar dataset cross-modelo)
- [x] Anti-sesgos (mismo runtime, fixture isolation, orden temporal)
- [x] Tres posts derivados de un dataset
- [x] Las 4 tareas del set actual

Lo que cambió:

- [ ] ~~5 condiciones~~ → 3 condiciones (Forge postponed)
- [ ] ~~4-5 modelos~~ → 5 modelos exactos (Sonnet + 4 baratos)
- [ ] ~~Tier diferenciado~~ → ITER=10 estricto para todos
- [ ] ~~Piloto de validación de Forge~~ → no aplica esta corrida
- [ ] ~~Métricas de decoración~~ → no aplica esta corrida
- [ ] Métricas adicionales agregadas: `asked_human`, `truncated_by_cap`, `hallucination_category`, `runtime_version`, `manifest_checksum`, `time_to_first_action_ms`
- [ ] Fixes técnicos consolidados en `decisiones-ejecutivas-pre-N10.md` y validados en Tier 1
- [ ] Caveats explícitos para publicación (sec 5 de esta adenda)

---

*Fin de la adenda. Una vez ejecutada la corrida final y generados los 3 reportes, este conjunto de documentos (brief original + 4 adendas + brief operativo) constituye el design doc completo del benchmark NAC3 v2.4. Sirve como evidencia metodológica si alguien audita el proceso.*
