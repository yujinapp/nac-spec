
/* Forge-decorated variant -- NO MANIFEST REGISTRATION.
 *
 * The page is decorated statically by Forge's walker. The NAC
 * runtime auto-discovers verbs + roles from data-nac-* attributes
 * on the DOM via click_by_verb's fallback path. The manifest is
 * intentionally absent so the bench measures "what an agent can
 * do with walker-decorated UI alone, without manual manifest
 * authoring".
 */
(function () {
  if (typeof window === 'undefined' || !window.NAC) return;
  /* No-op. */
})();
