/* invoice-app -- shared vanilla app logic for the 3 variants.
 *
 * On boot it reads window.__INITIAL_STATE__ (injected by the server)
 * and renders. All mutations go through fetch('/api/...') so the
 * server is the source of truth; this script only renders + dispatches.
 *
 * For the MCP variant the harness mutates state via the MCP server
 * (which calls the same /api/*) and then forces a re-render via
 * window.__pushState(snapshot).
 *
 * For the NAC3 variant, after every render we notify window.__nacSync
 * (defined in nac_decoration.js) so it can re-register data-tables +
 * per-row elements with the current state. The raw variant has no
 * NAC scripts and no __nacSync.
 */

(function () {
  'use strict';

  /** @type {any} */
  var STATE = window.__INITIAL_STATE__ || { invoices: [], clients: [], open_invoice_id: null, wizard_step: 1, language: 'es' };

  /** True for nac3 + mcp variants; false for raw + forge-* (those
     either have no manifest at all, or carry static decorations baked
     into the source by Forge and the runtime walker -- nacAttrs()
     would only add duplicate attrs). The forge-* variants set
     window.__USES_NAC_MANIFEST = false at boot. */
  var USES_NAC = (document.body && document.body.getAttribute('data-variant') !== 'raw'
                  && window.__USES_NAC_MANIFEST !== false);

  /** Pending fetch mutations -- the harness waits for this to drain. */
  window.__pendingMutations = 0;

  /* Re-render trigger. Called by app code and by window.__pushState. */
  function setState(next) {
    STATE = next;
    renderAll();
    if (USES_NAC && typeof window.__nacSync === 'function') {
      try { window.__nacSync(STATE); }
      catch (e) { console.warn('[nacSync]', e); }
    }
  }
  window.__pushState = setState;
  window.__state = function () { return STATE; };

  /* ---- fetch helpers ----
     api() chains the state refresh + nacSync inside the same pending
     block so the harness's waitForFunction(__pendingMutations === 0)
     truly drains the whole mutation pipeline. Without this there was a
     race where the api() fetch returned, dropped the counter, the
     harness saw 0 and dispatched the next action before refresh's
     state load + __nacSync had run -- causing "data-table not
     registered" on the just-opened modal. */
  function api(method, path, body, opts) {
    var fopts = { method: method, headers: { 'Content-Type': 'application/json' } };
    if (body !== undefined) fopts.body = JSON.stringify(body);
    window.__pendingMutations++;
    return fetch(path, fopts)
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (opts && opts.skipRefresh) return res;
        return fetch('/api/state').then(function (r) { return r.json(); }).then(setState).then(function () { return res; });
      })
      .finally(function () { window.__pendingMutations--; });
  }
  function refresh() {
    window.__pendingMutations++;
    return fetch('/api/state').then(function (r) { return r.json(); }).then(setState).finally(function () {
      window.__pendingMutations--;
    });
  }
  window.__refresh = refresh;

  /* ---- helpers ---- */
  function $(sel) { return document.querySelector(sel); }
  function $all(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[c];
    });
  }
  /** Build a data-nac-* attr fragment, but ONLY for variants that expose NAC. */
  function nacAttrs(id, role, verb) {
    if (!USES_NAC) return '';
    var s = ' data-nac-id="' + escapeHtml(id) + '" data-nac-role="' + escapeHtml(role) + '"';
    if (verb) s += ' data-nac-action="' + escapeHtml(verb) + '"';
    return s;
  }
  function log(msg) {
    var pre = $('#log'); if (!pre) return;
    var ts = new Date().toISOString().split('T')[1].slice(0, 12);
    pre.textContent = '[' + ts + '] ' + msg + '\n' + pre.textContent;
  }

  /* ---- list view filters (client-side only) ---- */
  var FILTER = { status: '', sort_col: 'date', sort_dir: 'desc' };

  /* ---- render ---- */
  function renderAll() {
    renderList();
    renderModal();
    renderTopbar();
  }

  function renderTopbar() {
    var langSel = $('#chat-lang');
    if (langSel) langSel.value = STATE.language || 'es';
    document.documentElement.setAttribute('lang', STATE.language || 'es');
    document.body.setAttribute('data-page-lang', STATE.language || 'es');
    renderNewInvoiceForm();
  }

  function renderNewInvoiceForm() {
    var sel = $('#field-new-invoice-client'); if (!sel) return;
    /* Preserve current selection if still present. */
    var prev = sel.value;
    sel.innerHTML = (STATE.clients || []).map(function (c) {
      return '<option value="' + escapeHtml(c.id) + '">' + escapeHtml(c.name) + ' (' + escapeHtml(c.cuit) + ')</option>';
    }).join('');
    if (prev && (STATE.clients || []).some(function (c) { return c.id === prev; })) sel.value = prev;
  }

  function renderList() {
    var tbody = $('#invoice-list-body'); if (!tbody) return;
    var rows = (STATE.invoices || []).slice();
    if (FILTER.status) rows = rows.filter(function (r) { return r.status === FILTER.status; });
    rows.sort(function (a, b) {
      var av = a[FILTER.sort_col]; var bv = b[FILTER.sort_col];
      if (typeof av === 'number' && typeof bv === 'number') {
        return FILTER.sort_dir === 'asc' ? av - bv : bv - av;
      }
      av = String(av || ''); bv = String(bv || '');
      return FILTER.sort_dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    var html = rows.map(function (inv) {
      var clientName = inv.header && inv.header.client_name;
      var editAttrs = nacAttrs('invoice_app.invoice.' + inv.id + '.edit', 'action', 'edit_invoice');
      var cancelAttrs = nacAttrs('invoice_app.invoice.' + inv.id + '.cancel', 'action', 'cancel_invoice');
      return '<tr data-invoice-id="' + escapeHtml(inv.id) + '">' +
        '<td>' + escapeHtml(inv.id) + '</td>' +
        '<td>' + escapeHtml(clientName) + '</td>' +
        '<td>' + escapeHtml(inv.date) + '</td>' +
        '<td>' + Number(inv.total || 0).toFixed(2) + '</td>' +
        '<td><span class="status-badge status-' + escapeHtml(inv.status) + '">' + escapeHtml(inv.status) + '</span></td>' +
        '<td class="row-actions">' +
          '<button class="small invoice-edit-btn"' + editAttrs +
          ' data-invoice-id="' + escapeHtml(inv.id) + '" aria-label="Editar factura ' + escapeHtml(inv.id) + '">Editar</button> ' +
          '<button class="small cta-danger invoice-cancel-btn"' + cancelAttrs +
          ' data-invoice-id="' + escapeHtml(inv.id) + '" aria-label="Cancelar factura ' + escapeHtml(inv.id) + '">Cancelar factura</button>' +
        '</td>' +
        '</tr>';
    }).join('');
    tbody.innerHTML = html;

    $all('table.invoice-list th[data-sort-col]').forEach(function (th) {
      th.removeAttribute('aria-sort');
      if (th.getAttribute('data-sort-col') === FILTER.sort_col) {
        th.setAttribute('aria-sort', FILTER.sort_dir === 'asc' ? 'ascending' : 'descending');
      }
    });
  }

  function renderModal() {
    var modal = $('#invoice-modal'); if (!modal) return;
    var open = !!STATE.open_invoice_id;
    modal.setAttribute('data-state', open ? 'open' : 'closed');
    modal.setAttribute('aria-hidden', open ? 'false' : 'true');
    if (!open) return;
    var inv = (STATE.invoices || []).find(function (i) { return i.id === STATE.open_invoice_id; });
    if (!inv) return;
    var title = $('#invoice-modal-title');
    if (title) title.textContent = 'Editar factura ' + inv.id;
    var step = STATE.wizard_step || 1;
    $all('.wizard-step-btn').forEach(function (b) {
      var on = Number(b.getAttribute('data-step')) === step;
      if (on) b.setAttribute('aria-current', 'step');
      else b.removeAttribute('aria-current');
    });
    $all('.wizard-panel').forEach(function (p) {
      p.setAttribute('data-active', String(Number(p.getAttribute('data-step')) === step ? 1 : 0));
    });
    if (step === 1) renderStep1(inv);
    if (step === 2) renderStep2(inv);
    if (step === 3) renderStep3(inv);
  }

  function renderStep1(inv) {
    var p = $('#wizard-panel-cliente'); if (!p) return;
    var h = inv.header || {};
    function set(id, val) { var e = p.querySelector('#' + id); if (e) e.value = val == null ? '' : val; }
    set('field-client-name', h.client_name);
    set('field-cuit',        h.cuit);
    set('field-address',     h.address);
    set('field-email',       h.email);
    set('field-phone',       h.phone);
  }

  function renderStep2(inv) {
    var tbody = $('#lines-body'); if (!tbody) return;
    /* raw variant gets a textarea + inline "Corregir gramatica" button
       per row, no modal. POSTs /api/grammar-fix with {invoice_id,
       line_id}; the same deterministic GRAMMAR_FIXES stub backs the
       NAC3 ai_correct_syntax + the MCP correct_field_grammar paths,
       keeping all three conditions reproducible. */
    var rawDescCell = function (line) {
      if (USES_NAC) {
        return '<td><input class="line-desc" data-col="description" aria-label="Descripcion de la linea ' + escapeHtml(line.id) + '" value="' + escapeHtml(line.description) + '"></td>';
      }
      return '<td class="raw-desc-cell">' +
        '<textarea class="line-desc raw-desc-ta" data-col="description" rows="2" aria-label="Descripcion de la linea ' + escapeHtml(line.id) + '">' + escapeHtml(line.description) + '</textarea>' +
        '<button class="small line-grammar-btn" type="button" data-line-id="' + escapeHtml(line.id) + '" aria-label="Corregir gramatica de la linea ' + escapeHtml(line.id) + '">Corregir gramatica</button>' +
        '</td>';
    };
    var html = (inv.lines || []).map(function (line) {
      return '<tr data-line-id="' + escapeHtml(line.id) + '">' +
        rawDescCell(line) +
        '<td><input class="line-qty"  type="number" data-col="qty" min="0" aria-label="Cantidad de la linea ' + escapeHtml(line.id) + '" value="' + Number(line.qty || 0) + '"></td>' +
        '<td><input class="line-price" type="number" data-col="unit_price" min="0" step="0.01" aria-label="Precio unitario de la linea ' + escapeHtml(line.id) + '" value="' + Number(line.unit_price || 0) + '"></td>' +
        '<td><input class="line-discount" type="number" data-col="discount_pct" min="0" max="100" aria-label="Descuento (%) de la linea ' + escapeHtml(line.id) + '" value="' + Number(line.discount_pct || 0) + '"></td>' +
        '<td class="line-total">' + Number(line.line_total || 0).toFixed(2) + '</td>' +
        '<td><button class="small cta-danger line-remove-btn" data-line-id="' + escapeHtml(line.id) + '" aria-label="Eliminar la linea ' + escapeHtml(line.id) + '">Eliminar</button></td>' +
        '</tr>';
    }).join('');
    tbody.innerHTML = html;
    var sum = (inv.lines || []).reduce(function (s, l) { return s + (Number(l.line_total) || 0); }, 0);
    var sumEl = $('#lines-sum'); if (sumEl) sumEl.textContent = sum.toFixed(2);
  }

  function renderStep3(inv) {
    var c = inv.conditions || {};
    var p = $('#wizard-panel-condiciones'); if (!p) return;
    var pm = p.querySelector('#field-payment-method'); if (pm) pm.value = c.payment_method || 'contado';
    p.querySelectorAll('input[name="payment-term"]').forEach(function (r) { r.checked = String(c.payment_term_days || 0) === r.value; });
    var obs = p.querySelector('#field-observations'); if (obs) obs.value = c.observations || '';
    var acc = p.querySelector('#field-accepted'); if (acc) acc.checked = !!c.accepted;
  }

  /* Emit the NAC3 conformance event after a click handler runs, so
     NAC.click() resolves. Only fires when the host runtime is loaded
     AND the clicked element carries data-nac-id (raw variant skips). */
  function fireNacSucceeded(targetEl) {
    if (!USES_NAC) return;
    var id = targetEl && targetEl.getAttribute && targetEl.getAttribute('data-nac-id');
    if (!id) return;
    /* The plugin is read from the enclosing data-nac-plugin attribute or
       inferred from the id's prefix (dotted notation). */
    var enclosingPlugin = targetEl.closest && targetEl.closest('[data-nac-plugin]');
    var plugin = enclosingPlugin ? enclosingPlugin.getAttribute('data-nac-plugin') : id.split('.')[0];
    setTimeout(function () {
      document.dispatchEvent(new CustomEvent('nac:action:succeeded', {
        detail: { plugin: plugin, action_id: id, is_trusted: false },
      }));
    }, 0);
  }

  /* ---- event delegation: clicks ---- */
  document.addEventListener('click', function (ev) {
    var t = ev.target; if (!t) return;
    var inv;
    /* schedule conformance ack first so NAC.click() resolves even if
       the handler below kicks off an async refresh. */
    fireNacSucceeded(t);
    if (t.matches && t.matches('.invoice-edit-btn')) {
      api('POST', '/api/open-invoice', { invoice_id: t.getAttribute('data-invoice-id'), step: 1 }).then(refresh);
      return;
    }
    if (t.matches && t.matches('.invoice-cancel-btn')) {
      var id = t.getAttribute('data-invoice-id');
      openConfirmCancel(id);
      return;
    }
    if (t.matches && t.matches('.wizard-step-btn')) {
      var step = Number(t.getAttribute('data-step'));
      api('POST', '/api/wizard-step', { step: step }).then(refresh);
      return;
    }
    if (t.id === 'btn-wizard-prev') {
      var prev = Math.max(1, (STATE.wizard_step || 1) - 1);
      api('POST', '/api/wizard-step', { step: prev }).then(refresh);
      return;
    }
    if (t.id === 'btn-wizard-next') {
      var nxt = Math.min(3, (STATE.wizard_step || 1) + 1);
      api('POST', '/api/wizard-step', { step: nxt }).then(refresh);
      return;
    }
    if (t.id === 'btn-save-step') { log('save_step pressed on step ' + STATE.wizard_step); return; }
    if (t.id === 'btn-save-close') {
      api('POST', '/api/wizard-step', { step: 1 }).then(function () {
        api('POST', '/api/open-invoice', { invoice_id: null }).then(refresh);
      });
      return;
    }
    if (t.id === 'btn-cancel-changes') {
      log('cancel_changes pressed');
      api('POST', '/api/open-invoice', { invoice_id: null }).then(refresh);
      return;
    }
    if (t.id === 'btn-cancel-invoice-from-modal') {
      openConfirmCancel(STATE.open_invoice_id);
      return;
    }
    if (t.id === 'btn-confirm-invoice') {
      api('POST', '/api/invoices/' + encodeURIComponent(STATE.open_invoice_id) + '/submit', {}).then(refresh);
      return;
    }
    if (t.id === 'btn-add-line') {
      inv = currentOpenInvoice();
      if (inv) {
        api('POST', '/api/invoices/' + encodeURIComponent(inv.id) + '/lines',
            { description: 'Nueva linea', qty: 1, unit_price: 0, discount_pct: 0 }).then(refresh);
      }
      return;
    }
    if (t.id === 'btn-save-draft') { log('save_draft pressed'); return; }
    if (t.id === 'btn-new-invoice') {
      var sel = $('#field-new-invoice-client');
      var cid = sel ? sel.value : '';
      if (!cid) { log('new_invoice: no client selected'); return; }
      api('POST', '/api/invoices', { client_id: cid }).then(refresh);
      return;
    }
    if (t.matches && t.matches('.line-remove-btn')) {
      inv = currentOpenInvoice();
      if (inv) {
        api('DELETE',
            '/api/invoices/' + encodeURIComponent(inv.id) +
            '/lines/' + encodeURIComponent(t.getAttribute('data-line-id'))).then(refresh);
      }
      return;
    }
    if (t.matches && t.matches('.line-grammar-btn')) {
      inv = currentOpenInvoice();
      if (inv) {
        api('POST', '/api/grammar-fix', {
          invoice_id: inv.id,
          line_id: t.getAttribute('data-line-id'),
        }).then(refresh);
      }
      return;
    }
    if (t.id === 'btn-confirm-cancel-yes') {
      var cid = $('#confirm-cancel-modal').getAttribute('data-target-invoice') || '';
      if (cid) {
        api('POST', '/api/invoices/' + encodeURIComponent(cid) + '/cancel', {}).then(function () {
          closeConfirmCancel();
          refresh();
        });
      }
      return;
    }
    if (t.id === 'btn-confirm-cancel-no') { closeConfirmCancel(); return; }
    if (t.matches && t.matches('table.invoice-list th[data-sort-col]')) {
      var col = t.getAttribute('data-sort-col');
      if (FILTER.sort_col === col) FILTER.sort_dir = FILTER.sort_dir === 'asc' ? 'desc' : 'asc';
      else { FILTER.sort_col = col; FILTER.sort_dir = 'asc'; }
      renderList();
      return;
    }
  });

  document.addEventListener('change', function (ev) {
    var t = ev.target; if (!t) return;
    if (t.id === 'filter-status') { FILTER.status = t.value; renderList(); return; }
    if (t.id === 'chat-lang') {
      api('POST', '/api/language', { language: t.value }).then(refresh); return;
    }
    var tr = t.closest && t.closest('#lines-body tr');
    if (tr) {
      var lineId = tr.getAttribute('data-line-id');
      var col = t.getAttribute('data-col');
      var val = col === 'description' ? t.value : Number(t.value);
      var inv = currentOpenInvoice();
      if (inv && lineId && col) {
        var patch = {}; patch[col] = val;
        api('PATCH', '/api/invoices/' + encodeURIComponent(inv.id) +
            '/lines/' + encodeURIComponent(lineId), patch).then(refresh);
      }
      return;
    }
    if (t.closest && t.closest('#wizard-panel-cliente')) {
      var fmap = {
        'field-client-name': 'client_name', 'field-cuit': 'cuit',
        'field-address': 'address', 'field-email': 'email', 'field-phone': 'phone',
      };
      var key = fmap[t.id]; if (!key) return;
      var p = {}; p[key] = t.value;
      var inv2 = currentOpenInvoice();
      if (inv2) api('PATCH', '/api/invoices/' + encodeURIComponent(inv2.id) + '/header', p).then(refresh);
      return;
    }
    if (t.closest && t.closest('#wizard-panel-condiciones')) {
      var inv3 = currentOpenInvoice(); if (!inv3) return;
      var patch3 = {};
      if (t.id === 'field-payment-method') patch3.payment_method = t.value;
      else if (t.name === 'payment-term') { if (t.checked) patch3.payment_term_days = Number(t.value); }
      else if (t.id === 'field-observations') patch3.observations = t.value;
      else if (t.id === 'field-accepted') patch3.accepted = !!t.checked;
      api('PATCH', '/api/invoices/' + encodeURIComponent(inv3.id) + '/conditions', patch3).then(refresh);
      return;
    }
  });

  function openConfirmCancel(id) {
    var m = $('#confirm-cancel-modal'); if (!m) return;
    m.setAttribute('data-state', 'open');
    m.setAttribute('aria-hidden', 'false');
    m.setAttribute('data-target-invoice', id || '');
    var lbl = $('#confirm-cancel-target'); if (lbl) lbl.textContent = id || '';
  }
  function closeConfirmCancel() {
    var m = $('#confirm-cancel-modal'); if (!m) return;
    m.setAttribute('data-state', 'closed');
    m.setAttribute('aria-hidden', 'true');
    m.removeAttribute('data-target-invoice');
  }
  function currentOpenInvoice() {
    if (!STATE.open_invoice_id) return null;
    return (STATE.invoices || []).find(function (i) { return i.id === STATE.open_invoice_id; });
  }

  window.__benchHelpers = {
    currentOpenInvoice: currentOpenInvoice,
    refresh: refresh,
    state: function () { return STATE; },
  };

  /* v2.4 parameterised actions -- host handler for click_by_verb with
     a payload. The nac_decoration script intercepts click_by_verb
     when args carry non-ClickOpts keys and dispatches this event. */

  /* Tolerant key resolution: agents emit semantically-correct keys
     (quantity, price, ammount) that may not match the host schema
     literally (qty, unit_price). The host normalises a small fixed
     synonym table per field. This is host hygiene, not test rigging --
     a real backend would do the same on its inbound REST surface. */
  function pickKey(obj, names) {
    for (var i = 0; i < names.length; i++) {
      if (obj && obj[names[i]] !== undefined && obj[names[i]] !== null) return obj[names[i]];
    }
    return undefined;
  }
  document.addEventListener('nac:action:invoke_with_args', function (ev) {
    if (!USES_NAC) return;
    if (!ev || !ev.detail) return;
    var plugin = ev.detail.plugin;
    var verb   = ev.detail.verb;
    var args   = ev.detail.args || {};
    var inv = currentOpenInvoice();
    function ack(action_id) {
      document.dispatchEvent(new CustomEvent('nac:action:succeeded', {
        detail: { plugin: plugin, verb: verb, action_id: action_id || '' },
      }));
    }
    if (plugin === 'invoice_edit_modal' && verb === 'add_row') {
      if (!inv) return;
      var values = args.values || args;
      api('POST', '/api/invoices/' + encodeURIComponent(inv.id) + '/lines', {
        description:  pickKey(values, ['description','desc','descripcion','name','product']) || '',
        qty:          Number(pickKey(values, ['qty','quantity','cantidad','count']) || 0),
        unit_price:   Number(pickKey(values, ['unit_price','price','precio','precio_unitario']) || 0),
        discount_pct: Number(pickKey(values, ['discount_pct','discount','descuento']) || 0),
      }).then(function () { ack('invoice_edit_modal.add_line'); });
      return;
    }
    /* Atomic cancel_invoice: agent emits click_by_verb('invoice_app',
       'cancel', {invoice_id:'INV-0001', confirm: true}) and the host
       bypasses the confirm modal. Matches the production pattern of
       a "force" flag on destructive backend ops. */
    if (plugin === 'invoice_app' && (verb === 'cancel' || verb === 'cancel_invoice') && args && args.confirm) {
      var id = args.invoice_id || (typeof args === 'object' && args.invoice_id);
      if (!id) return;
      api('POST', '/api/invoices/' + encodeURIComponent(id) + '/cancel', {}).then(function () {
        ack('invoice_app.invoice.' + id + '.cancel');
      });
      return;
    }
    /* v2.3 parameterised edit_description: agent emits
         click_by_verb('invoice_edit_modal', 'edit_description', { row_id: 'L1' })
       and the host opens the runtime field editor on that row's
       description input. The manifest exposes ONE element per row table
       (invoice_edit_modal.edit_description) instead of N per-row entries,
       keeping the manifest flat regardless of how many lines an invoice
       has. The transient data-nac-id is stamped just-in-time so
       NAC.edit_field can resolve the source element. On save the runtime
       fires input+change on the source input, which the host's existing
       change listener picks up and PATCHes the backend. */
    if (plugin === 'invoice_edit_modal' && verb === 'edit_description' && args && args.row_id) {
      if (!inv) return;
      var rowId = String(args.row_id);
      var tr = document.querySelector('#lines-body tr[data-line-id="' + rowId.replace(/"/g, '\\"') + '"]');
      if (!tr) return;
      var input = tr.querySelector('input.line-desc');
      if (!input) return;
      var transientId = 'invoice_edit_modal.line.' + rowId + '.description';
      input.setAttribute('data-nac-id', transientId);
      input.setAttribute('data-nac-role', 'field');
      try {
        if (window.NAC && typeof window.NAC.edit_field === 'function') {
          window.NAC.edit_field(transientId);
        }
      } catch (e) { console.warn('[edit_description]', e); }
      ack('invoice_edit_modal.edit_description');
      return;
    }
  });

  /* Boot */
  renderAll();
  if (USES_NAC && typeof window.__nacSync === 'function') {
    try { window.__nacSync(STATE); }
    catch (e) { console.warn('[nacSync boot]', e); }
  }
  log('boot: invoice-app ready (' + (STATE.invoices || []).length + ' invoices, lang=' + (STATE.language || 'es') + ')');
})();
