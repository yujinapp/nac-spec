/* nac_decoration.js
 *
 * Adapts the invoice-app to the NAC3 v2.1 contract:
 *   - Registers three static plugin manifests (invoice_app, invoice_edit_modal,
 *     confirm_cancel) for the surface that doesn't change shape.
 *   - Exposes __nacSync(state) which re-registers PER-ROW elements (per-invoice
 *     edit + cancel verbs) and the two data-tables (invoice_app.invoices_list +
 *     invoice.lines) every time the app state changes. app.js calls this
 *     after every render.
 *   - Bridges dt_* mutations from the NAC runtime back to the HTTP backend
 *     so the contract feels native to the agent while the server stays the
 *     single source of truth (production MCP-style architecture; see
 *     REPORT_THREE_WAY.md methodology).
 *
 * Loaded only on /nac3 and /mcp; never on /raw.
 */
(function () {
  'use strict';

  function makeLi(es, en) {
    return { es: es, en: en, pt: es, fr: en, ja: en, zh: en,
             hi: en, ar: en, de: en, it: en };
  }

  function bumpPending() {
    if (typeof window.__pendingMutations === 'number') window.__pendingMutations++;
  }
  function dropPending() {
    if (typeof window.__pendingMutations === 'number') window.__pendingMutations--;
  }
  function postJson(path, body) {
    bumpPending();
    return fetch(path, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    }).then(function (r) { return r.json(); }).finally(dropPending);
  }
  function patchJson(path, body) {
    bumpPending();
    return fetch(path, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    }).then(function (r) { return r.json(); }).finally(dropPending);
  }
  function del(path) {
    bumpPending();
    return fetch(path, { method: 'DELETE' }).then(function (r) { return r.json(); }).finally(dropPending);
  }

  /* ---- 0. NAC3 v2.4 proposed enhancements ---- */

  /* v2.3 preview / v2.4 formalisation: click_by_verb(plugin, verb, args)
     where `args` carries a host-handler payload (not just ClickOpts).
     The v2.2 runtime forwards `args` to click() as opts which the host
     never sees. We intercept here: when args looks like a payload
     (any key outside the ClickOpts allow-list), dispatch a custom
     event nac:action:invoke_with_args so the host can act atomically.
     If the host emits nac:action:succeeded in response, the runtime
     leg is skipped. */
  var CLICK_OPTS_KEYS = { timeout: 1, source: 1, plugin: 1 };
  function isPayloadArgs(args) {
    if (!args || typeof args !== 'object') return false;
    for (var k in args) if (Object.prototype.hasOwnProperty.call(args, k)) {
      if (!CLICK_OPTS_KEYS[k]) return true;
    }
    return false;
  }

  function installClickWithArgs() {
    if (!window.NAC || window.NAC.__click_with_args_v24) return;
    var orig = window.NAC.click_by_verb;
    if (typeof orig !== 'function') return;
    window.NAC.click_by_verb = function (plugin, verb, args) {
      if (isPayloadArgs(args)) {
        return new Promise(function (resolve, reject) {
          var handled = false;
          var onSuccess = function (e) {
            if (!e || !e.detail) return;
            if (e.detail.plugin !== plugin || e.detail.verb !== verb) return;
            handled = true;
            document.removeEventListener('nac:action:succeeded', onSuccess);
            resolve({ ok: true });
          };
          document.addEventListener('nac:action:succeeded', onSuccess);
          document.dispatchEvent(new CustomEvent('nac:action:invoke_with_args', {
            detail: { plugin: plugin, verb: verb, args: args },
          }));
          /* If no host handler responds within 4s, fall back to plain click. */
          setTimeout(function () {
            if (handled) return;
            document.removeEventListener('nac:action:succeeded', onSuccess);
            orig.call(window.NAC, plugin, verb).then(resolve, reject);
          }, 4000);
        });
      }
      return orig.apply(this, arguments);
    };
    window.NAC.__click_with_args_v24 = true;
  }


  /* Strict supports[] enforcement. v2.1 advisorily declares supports
     but the runtime mutates table state regardless. v2.4 makes the
     runtime refuse operations not listed in supports[]. Agents that
     misuse a read-only table get a clear error. */
  function installSupportsEnforcement() {
    if (!window.NAC || window.NAC.__supports_enforced_v24) return;
    function tbl(id) { return window.NAC.__v2_dataTables && window.NAC.__v2_dataTables[id]; }
    function check(id, op) {
      var t = tbl(id);
      if (!t || !t.schema || !Array.isArray(t.schema.supports)) return;
      if (t.schema.supports.indexOf(op) < 0) {
        var err = new Error('operation_not_supported: ' + op + ' not in supports[] for table ' + id);
        err.code = 'operation_not_supported';
        throw err;
      }
    }
    var origAdd  = window.NAC.dt_add_row;
    var origRem  = window.NAC.dt_remove_row;
    var origEdit = window.NAC.dt_edit_cell;
    if (typeof origAdd  === 'function') window.NAC.dt_add_row    = function (id) { check(id, 'add_row');    return origAdd.apply(this,  arguments); };
    if (typeof origRem  === 'function') window.NAC.dt_remove_row = function (id) { check(id, 'remove_row'); return origRem.apply(this,  arguments); };
    if (typeof origEdit === 'function') window.NAC.dt_edit_cell  = function (id) { check(id, 'edit_cell');  return origEdit.apply(this, arguments); };
    window.NAC.__supports_enforced_v24 = true;
  }

  /* v2.3 preview: NAC.describe() walks the DOM for [data-nac-plugin]
     groups -- plugins registered via NAC.register() without any DOM
     presence (the editor overlay, modal dialogs, transient widgets)
     never appear in the snapshot, so an agent cannot plan a chain of
     verbs against them in a single turn. We wrap describe() to merge
     in any registered plugin missing from the DOM walk, marking each
     synthesised element visible:false so the agent treats them as
     "currently dormant but reachable after a navigation/open action".
     The brief explicitly calls out the nac_editor case: pre-register
     so the agent can plan edit_field + ai_correct_syntax + save in
     one turn. Without this, ai_correct_syntax is invisible until the
     editor overlay mounts -- by then the planning round is over. */
  function installRegisteredManifestExposure() {
    if (!window.NAC || window.NAC.__registered_manifest_v23) return;
    var origDescribe = window.NAC.describe;
    if (typeof origDescribe !== 'function') return;
    if (typeof window.NAC.manifest !== 'function') return;

    function synthElement(e) {
      var out = {};
      for (var k in e) if (Object.prototype.hasOwnProperty.call(e, k)) out[k] = e[k];
      if (!out.nac_id && out.id) out.nac_id = out.id;
      /* Synthesised: no DOM presence yet, so element is not visible.
         The agent should know it is dormant-but-reachable. */
      out.visible = false;
      return out;
    }

    window.NAC.describe = function () {
      var base = origDescribe.apply(this, arguments) || {};
      var registered;
      try { registered = window.NAC.manifest(); } catch (_) { return base; }
      if (!Array.isArray(registered) || registered.length === 0) return base;

      /* For plugins already present in the DOM-derived snapshot, MERGE
         missing manifest elements (e.g. invoice_edit_modal.edit_description
         which is a parameterised verb with no DOM presence). For plugins
         entirely absent from the DOM (e.g. nac_editor before the modal
         opens), append the full plugin block. Both cases mark the
         synthesised elements visible:false. */
      var manifestBySlug = {};
      for (var i = 0; i < registered.length; i++) {
        var m = registered[i] || {};
        var slug = m.plugin_slug || m.plugin || m.slug;
        if (slug) manifestBySlug[slug] = m;
      }
      var seenInPlugin = {};
      var newPlugins = (base.plugins || []).map(function (p) {
        if (!p || !p.plugin) return p;
        var manifest = manifestBySlug[p.plugin];
        if (!manifest) return p;
        var have = {};
        (p.elements || []).forEach(function (e) {
          var id = (e && (e.nac_id || e.id));
          if (id) have[id] = 1;
        });
        seenInPlugin[p.plugin] = 1;
        var extras = (manifest.elements || [])
          .filter(function (e) {
            var id = e && (e.id || e.nac_id);
            return id && !have[id];
          })
          .map(synthElement);
        if (extras.length === 0) return p;
        var merged = {};
        for (var k in p) if (Object.prototype.hasOwnProperty.call(p, k)) merged[k] = p[k];
        merged.elements = (p.elements || []).concat(extras);
        return merged;
      });
      /* Now append plugins entirely missing from base. */
      for (var slug2 in manifestBySlug) {
        if (seenInPlugin[slug2]) continue;
        var m2 = manifestBySlug[slug2];
        newPlugins.push({
          plugin:       slug2,
          plugin_state: 'idle',
          elements:     (m2.elements || []).map(synthElement),
        });
      }
      var out = {};
      for (var bk in base) if (Object.prototype.hasOwnProperty.call(base, bk)) out[bk] = base[bk];
      out.plugins = newPlugins;
      return out;
    };
    window.NAC.__registered_manifest_v23 = true;
  }

  /* Enrich data-table snapshots with current_visibility ('visible' |
     'hidden') computed from the owner element's live display. v2.1
     snapshot is a static manifest dump -- agents emit clicks on hidden
     elements blindly. */
  function installVisibilityHints() {
    if (!window.NAC || window.NAC.__visibility_v24) return;
    var orig = window.NAC.describe_v2;
    if (typeof orig !== 'function') return;
    window.NAC.describe_v2 = function () {
      var r = orig.apply(this, arguments) || {};
      var out = {};
      for (var k in r) if (Object.prototype.hasOwnProperty.call(r, k)) out[k] = r[k];
      out.data_tables = (r.data_tables || []).map(function (dt) {
        var ownerId = dt.schema && dt.schema.scope_owner;
        var owner = ownerId ? document.querySelector('[data-nac-id="' + ownerId + '"]') : null;
        var visible = true;
        if (owner) {
          var cs = getComputedStyle(owner);
          visible = (owner.offsetParent !== null) && (cs.display !== 'none') && (cs.visibility !== 'hidden');
        }
        var copy = {};
        for (var kk in dt) if (Object.prototype.hasOwnProperty.call(dt, kk)) copy[kk] = dt[kk];
        copy.current_visibility = visible ? 'visible' : 'hidden';
        return copy;
      });
      return out;
    };
    window.NAC.__visibility_v24 = true;
  }

  /* ---- 1. Static manifests (registered once at boot) ---- */

  function bootNac() {
    if (!window.NAC || typeof window.NAC.register !== 'function') {
      return setTimeout(bootNac, 30);
    }

    /* Install v2.4 enhancements once the runtime is alive. */
    installSupportsEnforcement();
    installVisibilityHints();
    installClickWithArgs();
    installRegisteredManifestExposure();

    /* Point the runtime's ai_correct_syntax POST at our deterministic
       grammar-fix endpoint instead of the production NacChat backend.
       The reference impl in nac.js reads
       window.NacChat._endpoint and falls back to a fixed URL. We set
       a minimal NacChat-shaped stub so the editor's "AI fix" call
       lands on /api/grammar-fix. */
    if (!window.NacChat) window.NacChat = {};
    window.NacChat._endpoint = '/api/grammar-fix';
    window.NacChat._lang = window.NacChat._lang || 'es';

    /* Pre-register the nac_editor plugin with its 8 canonical verbs
       so the agent can plan the edit_field flow in one response.
       Labels carry the prerequisite hint -- the editor modal must
       be opened first via invoice_edit_modal.edit_description (or
       another field-opener). Without that hint Sonnet/Haiku consistently
       skip the open step and try ai_correct_syntax in isolation. */
    var openHintEs = ' [requiere editor abierto -- abrir via invoice_edit_modal.edit_description con args:{row_id} primero]';
    var openHintEn = ' [requires editor open -- open via invoice_edit_modal.edit_description with args:{row_id} first]';
    function withHint(es, en) {
      return makeLi(es + openHintEs, en + openHintEn);
    }
    NAC.register({
      plugin_slug: 'nac_editor',
      version: '2.3.0',
      nac_version: '2.3',
      elements: [
        { id: 'nac_editor.select_word',      role: 'action',
          actions: [{ verb: 'select_word',      label_i18n: withHint('Seleccionar palabra', 'Select word') }],
          label_i18n: withHint('Seleccionar palabra', 'Select word') },
        { id: 'nac_editor.select_sentence',  role: 'action',
          actions: [{ verb: 'select_sentence',  label_i18n: withHint('Seleccionar oracion', 'Select sentence') }],
          label_i18n: withHint('Seleccionar oracion', 'Select sentence') },
        { id: 'nac_editor.select_all',       role: 'action',
          actions: [{ verb: 'select_all',       label_i18n: withHint('Seleccionar todo', 'Select all') }],
          label_i18n: withHint('Seleccionar todo', 'Select all') },
        { id: 'nac_editor.replace',          role: 'action',
          actions: [{ verb: 'replace',          label_i18n: withHint('Reemplazar seleccion', 'Replace selection') }],
          label_i18n: withHint('Reemplazar seleccion', 'Replace selection') },
        { id: 'nac_editor.delete_selection', role: 'action',
          actions: [{ verb: 'delete_selection', label_i18n: withHint('Borrar seleccion', 'Delete selection') }],
          label_i18n: withHint('Borrar seleccion', 'Delete selection') },
        { id: 'nac_editor.ai_correct_syntax', role: 'action',
          actions: [{ verb: 'ai_correct_syntax', label_i18n: withHint('Corregir gramatica con IA', 'AI fix grammar') }],
          label_i18n: withHint('Corregir gramatica con IA', 'AI fix grammar') },
        { id: 'nac_editor.save', role: 'action',
          actions: [{ verb: 'save', label_i18n: withHint('Guardar cambios del editor', 'Save editor changes') }],
          label_i18n: withHint('Guardar cambios del editor', 'Save editor changes') },
        { id: 'nac_editor.cancel', role: 'action',
          actions: [{ verb: 'cancel', label_i18n: withHint('Cancelar edicion', 'Cancel edit') }],
          label_i18n: withHint('Cancelar edicion', 'Cancel edit') },
      ],
    });

    /* invoice_edit_modal: wizard tabs + step actions + field ids stay
       stable across renders. Registered once. */
    NAC.register({
      plugin_slug: 'invoice_edit_modal',
      version: '1.0.0',
      nac_version: '2.3',
      elements: [
        { id: 'invoice_edit_modal.cancel_changes', role: 'action',
          actions: [{ verb: 'cancel_changes', label_i18n: makeLi('Cancelar cambios', 'Cancel changes') }],
          label_i18n: makeLi('Cancelar cambios (descarta edicion del modal)', 'Cancel changes (discard modal edits)') },
        { id: 'invoice_edit_modal.cancel_invoice', role: 'action',
          actions: [{ verb: 'cancel_invoice', label_i18n: makeLi('Cancelar factura', 'Cancel invoice') }],
          label_i18n: makeLi('Cancelar factura (cambiar estado)', 'Cancel invoice (change status)') },
        { id: 'invoice_edit_modal.save_close', role: 'action',
          actions: [{ verb: 'save_close', label_i18n: makeLi('Guardar y cerrar', 'Save and close') }],
          label_i18n: makeLi('Guardar y cerrar', 'Save and close') },
        { id: 'tab.cliente', role: 'tab',
          label_i18n: makeLi('Paso 1: Datos del cliente', 'Step 1: Client data') },
        { id: 'tab.lineas', role: 'tab',
          label_i18n: makeLi('Paso 2: Lineas', 'Step 2: Lines') },
        { id: 'tab.condiciones', role: 'tab',
          label_i18n: makeLi('Paso 3: Condiciones', 'Step 3: Conditions') },
        { id: 'invoice_edit_modal.client_name', role: 'field',
          label_i18n: makeLi('Cliente', 'Client') },
        { id: 'invoice_edit_modal.cuit',        role: 'field',
          label_i18n: makeLi('CUIT', 'Tax ID') },
        { id: 'invoice_edit_modal.address',     role: 'field',
          label_i18n: makeLi('Direccion', 'Address') },
        { id: 'invoice_edit_modal.email',       role: 'field',
          label_i18n: makeLi('Email', 'Email') },
        { id: 'invoice_edit_modal.phone',       role: 'field',
          label_i18n: makeLi('Telefono', 'Phone') },
        { id: 'invoice_edit_modal.add_line',  role: 'action',
          actions: [{ verb: 'add_row', label_i18n: makeLi('Agregar linea', 'Add row') }],
          label_i18n: makeLi('Agregar linea (boton)', 'Add row (button)') },
        { id: 'invoice_edit_modal.save_step', role: 'action',
          actions: [{ verb: 'save_step', label_i18n: makeLi('Guardar paso', 'Save step') }],
          label_i18n: makeLi('Guardar paso', 'Save step') },
        { id: 'invoice_edit_modal.payment_method', role: 'field',
          label_i18n: makeLi('Forma de pago', 'Payment method') },
        { id: 'invoice_edit_modal.term.0',         role: 'option',
          label_i18n: makeLi('Plazo 0 dias', '0 days') },
        { id: 'invoice_edit_modal.term.15',        role: 'option',
          label_i18n: makeLi('Plazo 15 dias', '15 days') },
        { id: 'invoice_edit_modal.term.30',        role: 'option',
          label_i18n: makeLi('Plazo 30 dias', '30 days') },
        { id: 'invoice_edit_modal.term.60',        role: 'option',
          label_i18n: makeLi('Plazo 60 dias', '60 days') },
        { id: 'invoice_edit_modal.observations',   role: 'field',
          label_i18n: makeLi('Observaciones', 'Observations') },
        { id: 'invoice_edit_modal.accepted',       role: 'field',
          label_i18n: makeLi('Aceptacion de terminos', 'Terms accepted') },
        { id: 'invoice_edit_modal.confirm',        role: 'action',
          actions: [{ verb: 'confirm', label_i18n: makeLi('Confirmar factura', 'Confirm invoice') }],
          label_i18n: makeLi('Confirmar factura (submit final)', 'Confirm invoice (final submit)') },
        { id: 'invoice_edit_modal.prev_step', role: 'action',
          actions: [{ verb: 'prev_step', label_i18n: makeLi('Paso anterior', 'Previous step') }],
          label_i18n: makeLi('Paso anterior', 'Previous step') },
        { id: 'invoice_edit_modal.next_step', role: 'action',
          actions: [{ verb: 'next_step', label_i18n: makeLi('Paso siguiente', 'Next step') }],
          label_i18n: makeLi('Paso siguiente', 'Next step') },
        /* v2.3 field-editor entry point: parameterised verb that takes
           {row_id, field?} and opens the runtime's edit_field modal on
           the matching cell. Wired in app.js's nac:action:invoke_with_args
           handler. */
        { id: 'invoice_edit_modal.edit_description', role: 'action',
          actions: [{ verb: 'edit_description',
            label_i18n: makeLi('Abrir editor de la descripcion de una linea (lanza el modal nac_editor con ai_correct_syntax/save/cancel)',
                               'Open field editor on a line description (opens the nac_editor modal with ai_correct_syntax/save/cancel)') }],
          label_i18n: makeLi('Abrir editor de campo sobre la descripcion de una linea -- usar con args:{row_id}. Abre el modal nac_editor cuyas verbs (select_*, ai_correct_syntax, save, cancel) quedan invocables.',
                             'Open the field editor on a line description -- use with args:{row_id}. Opens the nac_editor modal whose verbs (select_*, ai_correct_syntax, save, cancel) become invokable.') },
      ],
    });

    /* confirm_cancel: yes/no buttons of the cancel-invoice confirm dialog. */
    NAC.register({
      plugin_slug: 'confirm_cancel',
      version: '1.0.0',
      nac_version: '2.3',
      elements: [
        { id: 'confirm_cancel.yes', role: 'confirm-button',
          actions: [{ verb: 'confirm', label_i18n: makeLi('Si, cancelar', 'Yes, cancel') }],
          label_i18n: makeLi('Si, cancelar', 'Yes, cancel') },
        { id: 'confirm_cancel.no',  role: 'confirm-button',
          actions: [{ verb: 'reject', label_i18n: makeLi('No, mantener', 'No, keep') }],
          label_i18n: makeLi('No, mantener', 'No, keep') },
      ],
    });

    /* ---- 2. dt_* bridge listeners ---- */

    document.addEventListener('nac:dt:row_added', function (e) {
      if (!e || !e.detail) return;
      if (e.detail.table_id !== 'invoice_edit_modal.lines') return;
      var s = window.__state ? window.__state() : null;
      if (!s || !s.open_invoice_id) return;
      var vals = e.detail.values || e.detail.row || {};
      postJson('/api/invoices/' + s.open_invoice_id + '/lines', {
        description:  vals.description,
        qty:          Number(vals.qty || 0),
        unit_price:   Number(vals.unit_price || 0),
        discount_pct: Number(vals.discount_pct || 0),
      }).then(function () {
        if (typeof window.__refresh === 'function') window.__refresh();
      });
    });

    document.addEventListener('nac:dt:row_removed', function (e) {
      if (!e || !e.detail) return;
      if (e.detail.table_id !== 'invoice_edit_modal.lines') return;
      var s = window.__state ? window.__state() : null;
      if (!s || !s.open_invoice_id) return;
      del('/api/invoices/' + s.open_invoice_id + '/lines/' + e.detail.row_id)
        .then(function () { if (typeof window.__refresh === 'function') window.__refresh(); });
    });

    document.addEventListener('nac:dt:cell_edited', function (e) {
      if (!e || !e.detail) return;
      var d = e.detail;
      var s = window.__state ? window.__state() : null;
      if (!s) return;
      if (d.table_id === 'invoice_edit_modal.lines' && s.open_invoice_id) {
        var patch = {}; patch[d.column] = d.value;
        patchJson('/api/invoices/' + s.open_invoice_id + '/lines/' + d.row_id, patch)
          .then(function () { if (typeof window.__refresh === 'function') window.__refresh(); });
      }
    });

    /* ---- 3. __nacSync: re-register dynamic state on every render ---- */

    window.__nacSync = function (state) {
      registerInvoiceAppDynamic(state);
      registerListDataTable(state);
      registerLinesDataTable(state);
    };
  }

  function registerInvoiceAppDynamic(state) {
    var elements = [
      { id: 'invoice_app.language', role: 'field',
        label_i18n: makeLi('Idioma de la interfaz', 'UI language') },
      { id: 'invoice_app.filter.status', role: 'field',
        label_i18n: makeLi('Filtro por estado', 'Status filter') },
      { id: 'invoice_app.save_draft', role: 'action',
        actions: [{ verb: 'save_draft', label_i18n: makeLi('Guardar borrador', 'Save draft') }],
        label_i18n: makeLi('Guardar borrador', 'Save draft') },
      { id: 'invoice_app.new_invoice_client', role: 'field',
        label_i18n: makeLi('Cliente para nueva factura', 'Client for new invoice') },
      { id: 'invoice_app.new_invoice', role: 'action',
        actions: [{ verb: 'new_invoice', label_i18n: makeLi('Crear factura nueva', 'Create new invoice') }],
        label_i18n: makeLi('Crear factura nueva (usa el cliente seleccionado y abre el modal en paso 1)', 'Create new invoice (uses the selected client and opens the wizard at step 1)') },
    ];
    var invoices = state.invoices || [];
    for (var i = 0; i < invoices.length; i++) {
      var inv = invoices[i];
      elements.push({
        id: 'invoice_app.invoice.' + inv.id + '.edit',
        role: 'action',
        actions: [{ verb: 'edit', label_i18n: makeLi('Editar factura ' + inv.id, 'Edit invoice ' + inv.id) }],
        label_i18n: makeLi('Editar factura ' + inv.id, 'Edit invoice ' + inv.id),
      });
      elements.push({
        id: 'invoice_app.invoice.' + inv.id + '.cancel',
        role: 'action',
        actions: [{
          verb: 'cancel',
          label_i18n: makeLi(
            'Cancelar factura ' + inv.id + '. Para cancelacion atomica en un solo dispatch (sin abrir el modal de confirmacion), invocar como click_by_verb(\"invoice_app\", \"cancel\", { invoice_id: \"' + inv.id + '\", confirm: true }).',
            'Cancel invoice ' + inv.id + '. For atomic single-dispatch cancellation (no confirm modal), invoke as click_by_verb(\"invoice_app\", \"cancel\", { invoice_id: \"' + inv.id + '\", confirm: true }).'),
          /* V24-05 preview: declare verb args so agents can discover the
             atomic path without reading the label. When V24-05 ships, the
             label-as-documentation hack goes away. */
          args_schema: {
            invoice_id: {
              type: 'string', required: true,
              description: 'Invoice identifier (e.g. INV-0001).',
            },
            confirm: {
              type: 'boolean', required: false, default: false,
              description: 'When true, bypass the confirm modal and execute the cancellation in a single dispatch. Equivalent to opening the modal and clicking confirm_cancel.yes; appropriate for an agent acting with confirmed authority.',
            },
          },
        }],
        label_i18n: makeLi('Cancelar factura ' + inv.id, 'Cancel invoice ' + inv.id),
        /* a11y_hint exposes the action's risk class so agents (and screen
           readers) know cancellation is irreversible + requires explicit
           authority. The bench is testing whether agents pick the atomic
           path armed with this metadata. */
        a11y_hint: 'irreversible|requires_confirmation',
      });
    }
    NAC.register({
      plugin_slug: 'invoice_app',
      version: '1.0.0',
      nac_version: '2.3',
      elements: elements,
    });
  }

  function registerListDataTable(state) {
    var invoices = state.invoices || [];
    /* v2.4: renamed from invoices_list to invoice_directory. The previous
       name was lexically confusable with the editable "lines" table; agents
       sometimes called dt_add_row on this read-only directory. */
    (NAC.syncDataTable || NAC.registerDataTable)({
      table_id: 'invoice_app.invoice_directory',
      subkind: 'collection',
      transactional: false,
      row_id_field: 'id',
      columns: [
        { key: 'id',     label_i18n: makeLi('ID', 'ID'),         type: 'text',     editable: false },
        { key: 'client', label_i18n: makeLi('Cliente', 'Client'), type: 'text',     editable: false },
        { key: 'date',   label_i18n: makeLi('Fecha', 'Date'),    type: 'text',     editable: false },
        { key: 'total',  label_i18n: makeLi('Total', 'Total'),   type: 'currency', editable: false },
        { key: 'status', label_i18n: makeLi('Estado', 'Status'), type: 'text',     editable: false },
      ],
      supports: [],
      initial_rows: invoices.map(function (inv) {
        return {
          id:     inv.id,
          client: (inv.header && inv.header.client_name) || '',
          date:   inv.date,
          total:  inv.total,
          status: inv.status,
        };
      }),
    });
  }

  function registerLinesDataTable(state) {
    /* Only register when a modal is open. */
    if (!state.open_invoice_id) return;
    var inv = (state.invoices || []).find(function (i) { return i.id === state.open_invoice_id; });
    if (!inv) return;
    /* Rename: agents consistently inferred the table_id by prefixing
       with the enclosing plugin slug (invoice_edit_modal.lines) since
       that is how the manifest spec reads -- "globally unique within
       a plugin scope". Honor that intuition. */
    (NAC.syncDataTable || NAC.registerDataTable)({
      table_id: 'invoice_edit_modal.lines',
      subkind: 'collection',
      transactional: false,
      row_id_field: 'id',
      columns: [
        { key: 'id',           label_i18n: makeLi('ID linea', 'Line ID'),         type: 'text',     editable: false },
        { key: 'description',  label_i18n: makeLi('Descripcion', 'Description'),  type: 'text',     editable: true,  required: true },
        { key: 'qty',          label_i18n: makeLi('Cantidad', 'Qty'),             type: 'number',   editable: true,  required: true, min: 0 },
        { key: 'unit_price',   label_i18n: makeLi('Precio unitario', 'Unit price'), type: 'currency', editable: true },
        { key: 'discount_pct', label_i18n: makeLi('Descuento %', 'Discount %'),   type: 'number',   editable: true,  min: 0, max: 100 },
        { key: 'line_total',   label_i18n: makeLi('Total linea', 'Line total'),   type: 'currency', computed: true,
          computed_from: ['qty', 'unit_price', 'discount_pct'] },
      ],
      supports: ['add_row', 'remove_row', 'edit_cell'],
      initial_rows: (inv.lines || []).map(function (l) {
        return {
          id: l.id, description: l.description, qty: l.qty,
          unit_price: l.unit_price, discount_pct: l.discount_pct || 0,
          line_total: l.line_total,
        };
      }),
    });
  }

  bootNac();
})();
