/**
 * invoice-app backend + html server.
 *
 * Single Node http process on :8080 that:
 *   - Holds in-memory state (the source of truth for all 3 variants)
 *   - Serves /nac3 /raw /mcp HTML (skeleton injected with variant-specific
 *     decoration at request time)
 *   - Serves /api/* REST endpoints used by all three pages + the MCP server
 *   - Serves /api/reset for harness teardown between trials
 *
 * Run: tsx fixtures/invoice-app/server.ts
 */
import http from 'node:http';
import url from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = Number(process.env.INVOICE_APP_PORT || 8080);

/* ============================================================
   Domain types
   ============================================================ */

type InvoiceStatus = 'pendiente' | 'aprobada' | 'cancelada';
type PaymentMethod = 'contado' | 'transferencia' | 'cheque' | 'credito';

interface Client {
  id: string;
  name: string;
  cuit: string;
  address: string;
  email: string;
  phone: string;
}

interface InvoiceLine {
  id: string;
  description: string;
  qty: number;
  unit_price: number;
  discount_pct: number;
}

interface InvoiceHeader {
  client_id: string;
  client_name: string;
  cuit: string;
  address: string;
  email: string;
  phone: string;
}

interface InvoiceConditions {
  payment_method: PaymentMethod;
  payment_term_days: number;
  observations: string;
  accepted: boolean;
}

interface Invoice {
  id: string;
  date: string;            // ISO YYYY-MM-DD
  status: InvoiceStatus;
  header: InvoiceHeader;
  lines: InvoiceLine[];
  conditions: InvoiceConditions;
}

interface AppState {
  clients: Client[];
  invoices: Invoice[];
  /** which invoice the modal is "open" on for the current trial. Null if list view. */
  open_invoice_id: string | null;
  /** which wizard step is visible inside the modal */
  wizard_step: 1 | 2 | 3;
  /** language code applied to the page */
  language: string;
  /** monotonically increasing id source so reset is clean */
  _next_invoice_idx: number;
  /** active grammar editor session (for MCP granular set). */
  editor_session: null | {
    invoice_id: string; line_id: string; field: string;
    current_value: string; original_value: string;
    selection?: { start: number; end: number };
  };
}

/* Deterministic grammar fix stub. Documented in the report: in
   production ai_correct_syntax POSTs to the LLM intermediary; for the
   benchmark we stub server-side with this map so all 3 conditions
   share the SAME oracle. */
const GRAMMAR_FIXES: Record<string, string> = {
  'monitr LCD 24 plgada':           'monitor LCD 24 pulgadas',
  'tecaldo mecanico inalambrico':   'teclado mecanico inalambrico',
  'mose optico USB':                'mouse optico USB',
};
function grammarFix(text: string): string {
  if (text == null) return '';
  return Object.prototype.hasOwnProperty.call(GRAMMAR_FIXES, text)
    ? GRAMMAR_FIXES[text]
    : text;
}

/* ============================================================
   Seed data
   ============================================================ */

const SEED_CLIENTS: Client[] = [
  { id: 'C-001', name: 'Acme S.A.',           cuit: '30-71234567-9', address: 'Av. Corrientes 1234', email: 'compras@acme.com',    phone: '+54-11-4123-4567' },
  { id: 'C-002', name: 'Globex',              cuit: '30-71765432-1', address: 'Av. Cabildo 2200',    email: 'finanzas@globex.io',  phone: '+54-11-5432-1098' },
  { id: 'C-003', name: 'Initech',             cuit: '30-71009988-7', address: 'Av. Santa Fe 3000',   email: 'ar@initech.io',       phone: '+54-11-6789-0123' },
  { id: 'C-004', name: 'TechCorp',            cuit: '30-71223344-5', address: 'Florida 500',         email: 'pagos@techcorp.com',  phone: '+54-11-7890-1234' },
  { id: 'C-005', name: 'BetaSoft',            cuit: '30-71667788-6', address: 'Av. de Mayo 800',     email: 'admin@betasoft.io',   phone: '+54-11-8901-2345' },
  { id: 'C-006', name: 'GammaIndustries',     cuit: '30-71445566-2', address: 'Reconquista 600',     email: 'invoicing@gamma.com', phone: '+54-11-9012-3456' },
  { id: 'C-007', name: 'DeltaPro',            cuit: '30-71889900-3', address: 'San Martin 400',      email: 'cuentas@deltapro.io', phone: '+54-11-0123-4567' },
  { id: 'C-008', name: 'Epsilon Group',       cuit: '30-71112233-4', address: 'Maipu 700',           email: 'admin@epsilon.io',    phone: '+54-11-1234-5678' },
];

function clientById(id: string): Client | undefined {
  return SEED_CLIENTS.find(c => c.id === id);
}

/** Build the 50 seed lines for INV-OPEN with intentional ambiguity. */
function buildSeedLines(): InvoiceLine[] {
  const out: InvoiceLine[] = [];
  let n = 1;
  const push = (description: string, qty: number, unit_price: number, discount_pct = 0) => {
    out.push({ id: 'L' + (n++), description, qty, unit_price, discount_pct });
  };

  /* Monitors -- 4 variants. The first one carries an intentional
     typo ("monitr LCD 24 plgada" instead of "monitor LCD 24 pulgadas")
     for T-V23-EDITOR. Agents are expected to find this line and fix
     its grammar via the v2.3 edit_field primitive. */
  push('monitr LCD 24 plgada',       2, 280);
  push('Monitor 27" LG UltraGear',   1, 420);
  push('Monitor curvo Dell 32"',     1, 650);
  push('Monitor portatil 15.6"',     1, 195);

  /* Keyboards -- the first one carries a typo too ("tecaldo mecanico
     inalambrico" instead of "teclado mecanico inalambrico"). The
     T-V23-EDITOR targeting check verifies this row was NOT touched
     when the agent edits the monitor row. */
  push('tecaldo mecanico inalambrico', 1, 65);
  push('Teclado mecanico Razer',       1, 130);
  push('Teclado ergonomico Microsoft', 1, 95);

  /* Mouse family for T5. First row has a typo ("mose optico USB"
     instead of "mouse optico USB"). */
  push('mose optico USB',         5, 18);  // row 8
  push('Mouse gamer Razer',       1, 75);
  push('Mouse vertical ergonomico', 1, 55);

  /* Audio. */
  push('Auriculares Sony WH-1000XM5', 1, 380);
  push('Auriculares Bose QC Ultra',   1, 420);
  push('Microfono Blue Yeti',         1, 145);

  /* Webcams. */
  push('Webcam Logitech C920',  2, 75);
  push('Webcam 4K AverMedia',   1, 180);

  /* Cables / adaptadores -- lots of these to inflate the table. */
  push('Cable USB-C 2m',          10, 8);
  push('Cable HDMI 2.1 3m',       5, 22);
  push('Adaptador USB-A a USB-C', 8, 6);
  push('Hub USB 7 puertos',       2, 45);
  push('Adaptador HDMI a DP',     3, 18);

  /* Almacenamiento. */
  push('SSD 1TB Samsung 990',     2, 110);
  push('SSD 2TB Crucial',         1, 195);
  push('Disco externo 4TB',       1, 165);
  push('Pendrive 128GB',          5, 14);

  /* Conectividad. */
  push('Router WiFi 6 Asus',      1, 220);
  push('Switch 8 puertos',        1, 65);
  push('Cable Ethernet Cat6 5m',  4, 12);

  /* Periferia varia. */
  push('Lampara escritorio LED',  2, 60);
  push('Soporte monitor doble',   1, 95);
  push('Apoyo munecas teclado',   1, 25);
  push('Silla ergonomica',        1, 480);
  push('Escritorio motorizado',   1, 690);

  /* Insumos. */
  push('Tinta HP 664 negro',      3, 22);
  push('Tinta HP 664 color',      3, 24);
  push('Resma papel A4',          10, 8);
  push('Bibliorato A4',           5, 6);
  push('Marcador permanente x4',  8, 4);

  /* Imagen y proyeccion. */
  push('Camara DSLR Canon EOS',   1, 950);
  push('Tripode profesional',     1, 145);
  push('Aro de luz LED 18"',      1, 85);

  /* Conferencia. */
  push('Pizarra magnetica 90cm',  1, 75);
  push('Marcadores tiza liquida', 4, 8);
  push('Proyector portatil HD',   1, 320);

  /* Pequenos. */
  push('Pila AA recargable x4',   6, 12);
  push('Cargador USB 3 bocas',    2, 22);
  push('Funda notebook 15"',      2, 28);

  /* Final fillers to hit 50. */
  push('Tonalizador impresora',   1, 88);
  push('Limpiador pantalla 250ml', 4, 5);

  return out;
}

/* ============================================================
   State factory
   ============================================================ */

function newSeedState(): AppState {
  const today = new Date('2026-05-18T00:00:00Z');
  function daysBack(n: number): string {
    const d = new Date(today);
    d.setUTCDate(d.getUTCDate() - n);
    return d.toISOString().slice(0, 10);
  }

  /* Invoice list -- 15 total, 5 pendiente / 5 aprobada / 5 cancelada.
     Within "pendiente" the oldest one is INV-OPEN-OLDEST so T-MCP1
     ("cancel the oldest pending") is unambiguous. */
  const list: Invoice[] = [];
  function emptyConds(): InvoiceConditions {
    return { payment_method: 'contado', payment_term_days: 0, observations: '', accepted: false };
  }
  function headerFor(client: Client): InvoiceHeader {
    return {
      client_id: client.id, client_name: client.name,
      cuit: client.cuit, address: client.address,
      email: client.email, phone: client.phone,
    };
  }
  function mkInvoice(id: string, daysAgo: number, status: InvoiceStatus, clientIdx: number, lines: InvoiceLine[]): Invoice {
    return {
      id, date: daysBack(daysAgo), status,
      header: headerFor(SEED_CLIENTS[clientIdx % SEED_CLIENTS.length]),
      lines, conditions: emptyConds(),
    };
  }

  /* 5 pendientes -- INV-0001 .. INV-0005, oldest first. */
  /* INV-0001 is the "open invoice" with 50 lines + oldest date. */
  list.push(mkInvoice('INV-0001', 90, 'pendiente', 0, buildSeedLines()));
  list.push(mkInvoice('INV-0002', 30, 'pendiente', 1, [
    { id: 'L1', description: 'Servicio consultoria',          qty: 5,  unit_price: 150, discount_pct: 0 },
    { id: 'L2', description: 'Capacitacion equipo',           qty: 1,  unit_price: 800, discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0003', 22, 'pendiente', 2, [
    { id: 'L1', description: 'Licencia software anual',       qty: 10, unit_price: 95,  discount_pct: 5 },
  ]));
  list.push(mkInvoice('INV-0004', 15, 'pendiente', 3, [
    { id: 'L1', description: 'Hosting mensual',               qty: 3,  unit_price: 120, discount_pct: 0 },
    { id: 'L2', description: 'Dominio .com.ar',               qty: 1,  unit_price: 35,  discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0005', 8, 'pendiente', 4, [
    { id: 'L1', description: 'Soporte tecnico bloque 10hs',   qty: 1,  unit_price: 600, discount_pct: 0 },
  ]));

  /* 5 aprobadas. */
  list.push(mkInvoice('INV-0006', 100, 'aprobada', 5, [
    { id: 'L1', description: 'Hardware varios',               qty: 1,  unit_price: 1200, discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0007', 75,  'aprobada', 6, [
    { id: 'L1', description: 'Setup oficina',                 qty: 1,  unit_price: 3500, discount_pct: 10 },
  ]));
  list.push(mkInvoice('INV-0008', 60,  'aprobada', 7, [
    { id: 'L1', description: 'Migracion datos',               qty: 1,  unit_price: 2200, discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0009', 45,  'aprobada', 0, [
    { id: 'L1', description: 'Auditoria seguridad',           qty: 1,  unit_price: 1800, discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0010', 20,  'aprobada', 1, [
    { id: 'L1', description: 'Renovacion certificados SSL',   qty: 3,  unit_price: 95,   discount_pct: 0 },
  ]));

  /* 5 canceladas. */
  list.push(mkInvoice('INV-0011', 120, 'cancelada', 2, [
    { id: 'L1', description: 'Servicio cancelado por cliente', qty: 1, unit_price: 500,  discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0012', 95,  'cancelada', 3, [
    { id: 'L1', description: 'Equipos retirados',             qty: 1,  unit_price: 800,  discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0013', 70,  'cancelada', 4, [
    { id: 'L1', description: 'Hosting cancelado',             qty: 6,  unit_price: 120,  discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0014', 50,  'cancelada', 5, [
    { id: 'L1', description: 'Proyecto descartado',           qty: 1,  unit_price: 1500, discount_pct: 0 },
  ]));
  list.push(mkInvoice('INV-0015', 35,  'cancelada', 6, [
    { id: 'L1', description: 'Suscripcion cancelada',         qty: 12, unit_price: 45,   discount_pct: 0 },
  ]));

  return {
    clients: SEED_CLIENTS.slice(),
    invoices: list,
    /* Default to list view; tasks that need an open modal call
       /api/open-invoice in their setup. */
    open_invoice_id: null,
    wizard_step: 1,
    language: 'es',
    _next_invoice_idx: 16,
    editor_session: null,
  };
}

/* ============================================================
   In-memory state
   ============================================================ */

let STATE: AppState = newSeedState();

function reset(): void {
  STATE = newSeedState();
}

function findInvoice(id: string): Invoice | undefined {
  return STATE.invoices.find(i => i.id === id);
}

function lineTotal(line: InvoiceLine): number {
  const gross = line.qty * line.unit_price;
  return Math.round((gross * (100 - line.discount_pct) / 100) * 100) / 100;
}

function invoiceTotal(inv: Invoice): number {
  return Math.round(inv.lines.reduce((s, l) => s + lineTotal(l), 0) * 100) / 100;
}

function nextLineId(inv: Invoice): string {
  let n = inv.lines.length;
  for (const l of inv.lines) {
    const m = /^L(\d+)$/.exec(l.id);
    if (m) n = Math.max(n, Number(m[1]));
  }
  return 'L' + (n + 1);
}

/* ============================================================
   HTTP routing helpers
   ============================================================ */

function send(res: http.ServerResponse, code: number, type: string, body: string | Buffer): void {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(body);
}
function json(res: http.ServerResponse, code: number, payload: any): void {
  send(res, code, 'application/json; charset=utf-8', JSON.stringify(payload));
}
function badRequest(res: http.ServerResponse, msg: string): void {
  json(res, 400, { ok: false, error: msg });
}
function notFound(res: http.ServerResponse, msg: string): void {
  json(res, 404, { ok: false, error: msg });
}

async function readJsonBody<T = any>(req: http.IncomingMessage): Promise<T> {
  const chunks: Buffer[] = [];
  for await (const c of req) chunks.push(c as Buffer);
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw.trim()) return {} as T;
  try { return JSON.parse(raw) as T; }
  catch (e: any) { throw new Error('invalid json body: ' + e.message); }
}

/* ============================================================
   REST API
   ============================================================ */

interface Handler { (req: http.IncomingMessage, res: http.ServerResponse, params: Record<string, string>, query: Record<string, string>): Promise<void>; }

interface Route { method: string; pattern: RegExp; keys: string[]; handler: Handler; }

const ROUTES: Route[] = [];
function addRoute(method: string, path: string, handler: Handler): void {
  const keys: string[] = [];
  const pattern = new RegExp('^' + path.replace(/:([a-zA-Z_]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  ROUTES.push({ method, pattern, keys, handler });
}

/* --- pages --- */
addRoute('GET', '/nac3', async (_req, res) => send(res, 200, 'text/html; charset=utf-8', renderPage('nac3')));
addRoute('GET', '/raw',  async (_req, res) => send(res, 200, 'text/html; charset=utf-8', renderPage('raw')));
addRoute('GET', '/mcp',  async (_req, res) => send(res, 200, 'text/html; charset=utf-8', renderPage('mcp')));
addRoute('GET', '/forge-silent',   async (_req, res) => send(res, 200, 'text/html; charset=utf-8', renderPage('forge-silent')));
addRoute('GET', '/forge-assisted', async (_req, res) => send(res, 200, 'text/html; charset=utf-8', renderPage('forge-assisted')));
addRoute('GET', '/',     async (_req, res) => send(res, 200, 'text/html; charset=utf-8', renderIndex()));

/* --- state snapshot for the pages (initial render) --- */
addRoute('GET', '/api/state', async (_req, res) => {
  json(res, 200, snapshotForPage());
});

/* --- reset --- */
addRoute('POST', '/api/reset', async (_req, res) => {
  reset();
  json(res, 200, { ok: true, state: snapshotForPage() });
});

/* --- clients --- */
addRoute('GET', '/api/clients', async (_req, res, _p, q) => {
  const query = (q.q || '').toLowerCase();
  const cs = STATE.clients.filter(c => !query || c.name.toLowerCase().includes(query) || c.cuit.includes(query));
  json(res, 200, { ok: true, clients: cs });
});

/* --- invoices --- */
addRoute('GET', '/api/invoices', async (_req, res, _p, q) => {
  const status = q.status as InvoiceStatus | undefined;
  let list = STATE.invoices.slice();
  if (status) list = list.filter(i => i.status === status);
  const summary = list.map(i => ({
    id: i.id, date: i.date, client: i.header.client_name,
    total: invoiceTotal(i), status: i.status,
  }));
  json(res, 200, { ok: true, invoices: summary });
});

addRoute('GET', '/api/invoices/:id', async (_req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  json(res, 200, {
    ok: true,
    invoice: {
      ...inv,
      total: invoiceTotal(inv),
      lines: inv.lines.map(l => ({ ...l, line_total: lineTotal(l) })),
    },
  });
});

addRoute('POST', '/api/invoices', async (req, res) => {
  const body = await readJsonBody<{ client_id: string }>(req);
  const client = clientById(body.client_id);
  if (!client) return badRequest(res, 'unknown_client_id');
  const id = 'INV-' + String(STATE._next_invoice_idx++).padStart(4, '0');
  const inv: Invoice = {
    id, date: new Date().toISOString().slice(0, 10),
    status: 'pendiente',
    header: {
      client_id: client.id, client_name: client.name,
      cuit: client.cuit, address: client.address,
      email: client.email, phone: client.phone,
    },
    lines: [],
    conditions: { payment_method: 'contado', payment_term_days: 0, observations: '', accepted: false },
  };
  STATE.invoices.push(inv);
  STATE.open_invoice_id = id;
  STATE.wizard_step = 1;
  json(res, 200, { ok: true, invoice_id: id });
});

addRoute('PATCH', '/api/invoices/:id/header', async (req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const body = await readJsonBody<Partial<InvoiceHeader>>(req);
  Object.assign(inv.header, body);
  json(res, 200, { ok: true });
});

addRoute('PATCH', '/api/invoices/:id/conditions', async (req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const body = await readJsonBody<Partial<InvoiceConditions>>(req);
  Object.assign(inv.conditions, body);
  json(res, 200, { ok: true });
});

addRoute('POST', '/api/invoices/:id/lines', async (req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const body = await readJsonBody<Omit<InvoiceLine, 'id'>>(req);
  if (!body.description || typeof body.qty !== 'number' || typeof body.unit_price !== 'number') {
    return badRequest(res, 'missing_required_fields');
  }
  const line: InvoiceLine = {
    id: nextLineId(inv),
    description: body.description,
    qty: body.qty,
    unit_price: body.unit_price,
    discount_pct: typeof body.discount_pct === 'number' ? body.discount_pct : 0,
  };
  inv.lines.push(line);
  json(res, 200, { ok: true, line_id: line.id });
});

addRoute('PATCH', '/api/invoices/:id/lines/:line_id', async (req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const line = inv.lines.find(l => l.id === p.line_id);
  if (!line) return notFound(res, 'line_not_found');
  const body = await readJsonBody<Partial<InvoiceLine>>(req);
  if (typeof body.description === 'string') line.description = body.description;
  if (typeof body.qty === 'number') line.qty = body.qty;
  if (typeof body.unit_price === 'number') line.unit_price = body.unit_price;
  if (typeof body.discount_pct === 'number') line.discount_pct = body.discount_pct;
  json(res, 200, { ok: true });
});

addRoute('DELETE', '/api/invoices/:id/lines/:line_id', async (_req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const idx = inv.lines.findIndex(l => l.id === p.line_id);
  if (idx < 0) return notFound(res, 'line_not_found');
  inv.lines.splice(idx, 1);
  json(res, 200, { ok: true });
});

addRoute('POST', '/api/invoices/:id/submit', async (_req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  inv.status = 'pendiente';
  json(res, 200, { ok: true, new_status: inv.status });
});

addRoute('POST', '/api/invoices/:id/cancel', async (req, res, p) => {
  const inv = findInvoice(p.id);
  if (!inv) return notFound(res, 'invoice_not_found');
  await readJsonBody(req).catch(() => ({}));
  inv.status = 'cancelada';
  json(res, 200, { ok: true, new_status: inv.status });
});

/* --- modal / wizard control (used by /api/open and page rendering) --- */
addRoute('POST', '/api/open-invoice', async (req, res) => {
  const body = await readJsonBody<{ invoice_id: string | null; step?: number }>(req);
  if (body.invoice_id) {
    const inv = findInvoice(body.invoice_id);
    if (!inv) return notFound(res, 'invoice_not_found');
    STATE.open_invoice_id = inv.id;
  } else {
    STATE.open_invoice_id = null;
  }
  if (typeof body.step === 'number' && body.step >= 1 && body.step <= 3) {
    STATE.wizard_step = body.step as 1 | 2 | 3;
  }
  json(res, 200, { ok: true });
});

addRoute('POST', '/api/wizard-step', async (req, res) => {
  const body = await readJsonBody<{ step: number }>(req);
  if (typeof body.step !== 'number' || body.step < 1 || body.step > 3) {
    return badRequest(res, 'step_must_be_1_2_or_3');
  }
  STATE.wizard_step = body.step as 1 | 2 | 3;
  json(res, 200, { ok: true });
});

/* ---- Grammar fix endpoint -------------------------------------------
   Three callers route through this route:

   1. NAC3 runtime's ai_correct_syntax POSTs
        { session_id, prompt: "Fix grammar...\n\n<text>", lang, ... }
      expects { message: <fixed_text> }.
   2. Raw page button POSTs
        { invoice_id, line_id }
      applies the fix server-side, expects { ok, before, after }.
   3. MCP atomic tool correct_field_grammar POSTs the same as raw.

   All three resolve through the deterministic GRAMMAR_FIXES table. */
addRoute('POST', '/api/grammar-fix', async (req, res) => {
  const body = await readJsonBody<any>(req);
  /* Variant A: NAC3 runtime shape -- extract text from the prompt. */
  if (typeof body.prompt === 'string') {
    const m = body.prompt.match(/[\r\n]{2,}([\s\S]+?)\s*$/);
    const text = m ? m[1].trim() : body.prompt;
    const fixed = grammarFix(text);
    json(res, 200, { ok: true, message: fixed });
    return;
  }
  /* Variant B: raw / MCP -- mutate the actual invoice line. */
  if (body.invoice_id && body.line_id) {
    const inv = findInvoice(String(body.invoice_id));
    if (!inv) return notFound(res, 'invoice_not_found');
    const line = inv.lines.find(l => l.id === String(body.line_id));
    if (!line) return notFound(res, 'line_not_found');
    const before = line.description;
    const after = grammarFix(before);
    line.description = after;
    json(res, 200, { ok: true, before, after, changed: before !== after });
    return;
  }
  /* Variant C: bare text mode. */
  if (typeof body.text === 'string') {
    const before = body.text;
    const after = grammarFix(before);
    json(res, 200, { ok: true, before, after, changed: before !== after });
    return;
  }
  badRequest(res, 'expected one of { prompt } | { invoice_id, line_id } | { text }');
});

/* ---- MCP granular editor session (for the granular tool set) ---- */
addRoute('POST', '/api/editor/open', async (req, res) => {
  const body = await readJsonBody<{ invoice_id: string; line_id: string; field?: string }>(req);
  const inv = findInvoice(body.invoice_id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const line = inv.lines.find(l => l.id === body.line_id);
  if (!line) return notFound(res, 'line_not_found');
  const field = body.field || 'description';
  const value = (line as any)[field];
  if (value == null) return badRequest(res, 'unknown_field: ' + field);
  STATE.editor_session = {
    invoice_id: body.invoice_id,
    line_id: body.line_id,
    field,
    current_value: String(value),
    original_value: String(value),
  };
  json(res, 200, { ok: true, editor_open: true, current_value: STATE.editor_session.current_value });
});
addRoute('POST', '/api/editor/select-all', async (_req, res) => {
  const s = STATE.editor_session;
  if (!s) return badRequest(res, 'no_editor_session');
  s.selection = { start: 0, end: s.current_value.length };
  json(res, 200, { ok: true, selection: s.selection });
});
addRoute('POST', '/api/editor/replace', async (req, res) => {
  const body = await readJsonBody<{ new_text: string }>(req);
  const s = STATE.editor_session;
  if (!s) return badRequest(res, 'no_editor_session');
  s.current_value = String(body.new_text || '');
  s.selection = undefined;
  json(res, 200, { ok: true, new_value: s.current_value });
});
addRoute('POST', '/api/editor/correct-grammar', async (_req, res) => {
  const s = STATE.editor_session;
  if (!s) return badRequest(res, 'no_editor_session');
  const before = s.current_value;
  const after = grammarFix(before);
  s.current_value = after;
  json(res, 200, { ok: true, before, after, changed: before !== after });
});
addRoute('POST', '/api/editor/save', async (_req, res) => {
  const s = STATE.editor_session;
  if (!s) return badRequest(res, 'no_editor_session');
  const inv = findInvoice(s.invoice_id);
  if (!inv) return notFound(res, 'invoice_not_found');
  const line = inv.lines.find(l => l.id === s.line_id);
  if (!line) return notFound(res, 'line_not_found');
  (line as any)[s.field] = s.current_value;
  const saved = s.current_value;
  STATE.editor_session = null;
  json(res, 200, { ok: true, editor_closed: true, saved_value: saved });
});
addRoute('POST', '/api/editor/cancel', async (_req, res) => {
  STATE.editor_session = null;
  json(res, 200, { ok: true, editor_closed: true });
});

addRoute('POST', '/api/language', async (req, res) => {
  const body = await readJsonBody<{ language: string }>(req);
  if (!/^[a-z]{2}$/.test(body.language || '')) return badRequest(res, 'language_must_be_2_letter');
  STATE.language = body.language;
  json(res, 200, { ok: true });
});

/* ============================================================
   Page renderer
   ============================================================ */

function renderIndex(): string {
  return `<!doctype html><html><body><h1>invoice-app fixture</h1>
<ul>
  <li><a href="/nac3">/nac3 -- NAC3-decorated variant</a></li>
  <li><a href="/raw">/raw -- vanilla DOM variant</a></li>
  <li><a href="/mcp">/mcp -- visually like NAC3, agent never sees this</a></li>
  <li><a href="/api/state">/api/state -- current backend snapshot</a></li>
</ul>
</body></html>`;
}

function snapshotForPage(): any {
  return {
    open_invoice_id: STATE.open_invoice_id,
    wizard_step: STATE.wizard_step,
    language: STATE.language,
    clients: STATE.clients,
    invoices: STATE.invoices.map(i => ({
      ...i,
      total: invoiceTotal(i),
      lines: i.lines.map(l => ({ ...l, line_total: lineTotal(l) })),
    })),
  };
}

/* The three variants share a single skeleton HTML. The skeleton lives
   in pages/skeleton.html with `{{NAC_INSTRUMENTATION}}` slots that get
   replaced (or stripped) per variant. */

const SKELETON = fs.readFileSync(path.join(__dirname, 'pages', 'skeleton.html'), 'utf8');
const APP_JS   = fs.readFileSync(path.join(__dirname, 'pages', 'app.js'),       'utf8');
const APP_CSS  = fs.readFileSync(path.join(__dirname, 'pages', 'app.css'),      'utf8');
const NAC_DECORATOR = fs.readFileSync(path.join(__dirname, 'pages', 'nac_decoration.js'), 'utf8');

/* Forge-decorated variants. The decoration script in
   bench/scripts/forge_decorate.mjs runs Forge's HTML + JS walkers
   over the invoice-app fixture and emits decorated copies under
   fixtures/invoice-app-forge-{silent,assisted}/. We load those at
   boot; if absent, the variant falls back to raw + a warning. */
function tryLoad(p: string): string | null {
  try { return fs.readFileSync(p, 'utf8'); } catch { return null; }
}
const FORGE_DIRS: Record<'forge-silent' | 'forge-assisted', string> = {
  'forge-silent':  path.resolve(__dirname, '..', 'invoice-app-forge-silent',  'pages'),
  'forge-assisted': path.resolve(__dirname, '..', 'invoice-app-forge-assisted', 'pages'),
};
const FORGE_SKELETONS: Record<string, string | null> = {
  'forge-silent':   tryLoad(path.join(FORGE_DIRS['forge-silent'],   'skeleton.html')),
  'forge-assisted': tryLoad(path.join(FORGE_DIRS['forge-assisted'], 'skeleton.html')),
};
const FORGE_APP_JS: Record<string, string | null> = {
  'forge-silent':   tryLoad(path.join(FORGE_DIRS['forge-silent'],   'app.js')),
  'forge-assisted': tryLoad(path.join(FORGE_DIRS['forge-assisted'], 'app.js')),
};

export type PageVariant = 'nac3' | 'raw' | 'mcp' | 'forge-silent' | 'forge-assisted';

function renderPage(variant: PageVariant): string {
  /* Choose skeleton + app.js based on variant. Forge-decorated
     variants use their own copies; nac3/raw/mcp use the canonical
     skeleton + app.js. */
  let bodyTpl = SKELETON;
  let appJs = APP_JS;
  if (variant === 'forge-silent' || variant === 'forge-assisted') {
    const fs = FORGE_SKELETONS[variant];
    const fj = FORGE_APP_JS[variant];
    if (fs && fj) {
      bodyTpl = fs;
      appJs = fj;
    } else {
      console.warn(`[server] forge variant ${variant} not present on disk; falling back to raw`);
      variant = 'raw';
    }
  }

  let body = bodyTpl;
  if (variant === 'raw') {
    /* Strip data-nac-* attrs so the raw variant carries zero NAC3
       contract markers. Forge-decorated variants KEEP their static
       data-nac-* attrs even though the manifest is absent -- the
       point is that NAC runtime resolves verbs from those attrs
       via DOM scan. */
    body = body.replace(/\sdata-nac-[a-z-]+="[^"]*"/g, '');
  }
  body = body.replaceAll('{{VARIANT}}', variant);
  body = body.replace('{{APP_CSS}}', () => APP_CSS);
  body = body.replace('{{APP_JS}}',  () => appJs);
  body = body.replace('{{INITIAL_STATE}}', () => JSON.stringify(snapshotForPage()));
  if (variant === 'nac3' || variant === 'mcp') {
    body = body.replace('{{NAC_SCRIPTS}}', () =>
      `<script src="/vendor/nac-runtime.js"></script>` +
      `<script>${NAC_DECORATOR}</script>`);
  } else if (variant === 'forge-silent' || variant === 'forge-assisted') {
    /* Forge variants load the NAC runtime but NOT the manifest
       registration. Verbs are resolved via the data-nac-action
       fallback in click_by_verb (V24-01 contract). */
    body = body.replace('{{NAC_SCRIPTS}}', () =>
      `<script src="/vendor/nac-runtime.js"></script>` +
      `<script>window.__USES_NAC_MANIFEST = false;</script>`);
  } else {
    body = body.replace('{{NAC_SCRIPTS}}', '');
  }
  return body;
}

/* Serve the vendor nac runtime (concatenated from the cloned spec). */
let NAC_RUNTIME_SRC = '';
function loadNacRuntime(): string {
  if (NAC_RUNTIME_SRC) return NAC_RUNTIME_SRC;
  const base = path.resolve(__dirname, '..', '..', '..', 'vendor', 'nac-spec', 'js');
  const parts = [
    fs.readFileSync(path.join(base, 'nac.js'), 'utf8'),
    fs.readFileSync(path.join(base, 'nac-v2-extensions.js'), 'utf8'),
  ];
  NAC_RUNTIME_SRC = parts.join('\n\n/* ---- next file ---- */\n\n');
  return NAC_RUNTIME_SRC;
}
addRoute('GET', '/vendor/nac-runtime.js', async (_req, res) => {
  send(res, 200, 'application/javascript; charset=utf-8', loadNacRuntime());
});

/* ============================================================
   Server
   ============================================================ */

const server = http.createServer(async (req, res) => {
  const u = url.parse(req.url || '', true);
  const reqPath = u.pathname || '/';
  const method = req.method || 'GET';
  for (const r of ROUTES) {
    if (r.method !== method) continue;
    const m = r.pattern.exec(reqPath);
    if (!m) continue;
    const params: Record<string, string> = {};
    r.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1]));
    try {
      await r.handler(req, res, params, (u.query as any) || {});
    } catch (e: any) {
      console.error('[500]', method, reqPath, e.message);
      json(res, 500, { ok: false, error: 'internal: ' + e.message });
    }
    return;
  }
  notFound(res, `no route for ${method} ${reqPath}`);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`invoice-app server listening on http://127.0.0.1:${PORT}`);
  console.log('  /nac3 /raw /mcp  -- HTML variants');
  console.log('  /api/state /api/reset  -- snapshot + teardown');
});
