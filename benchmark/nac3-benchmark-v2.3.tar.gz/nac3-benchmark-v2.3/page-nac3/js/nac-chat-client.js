/* ===============================================================
   nac-chat-client.js -- self-contained NAC chat client.

   Drop-in for any NAC v2.1 page that wants to operate the UI
   via the Yujin LLM intermediary backend (Claude Sonnet primary
   / DeepSeek fallback) with text + voice.

   Provides:
     - Backend POST to /crm/api/v1/yujin/nac-demo
     - User + bot bubble rendering
     - Half-duplex TTS<->STT (fix C1)
     - STT debounce (fix C5)
     - Locale switch pre-filter (fix C7-bis)
     - Confirm-dialog YES/NO routing (fix C3)
     - Dispatcher for the 8 v2.0 kinds + 9 v2.1 data-table kinds

   Public API:
     NacChat.init({
       endpoint:  '/crm/api/v1/yujin/nac-demo',
       sessionId: 'optional-string',
       lang:      'es',
       chatLog:   HTMLElement,        // <ol> or <div> for bubbles
       input:     HTMLInputElement,   // text entry
       sendBtn:   HTMLElement,        // optional
       micBtn:    HTMLElement,        // optional, push-to-talk
       handsFreeBtn: HTMLElement,     // optional, always-on toggle
       ttsBtn:    HTMLElement,        // optional, TTS toggle
       langSelect:HTMLSelectElement   // optional
     })
     NacChat.send(text)
     NacChat.botSpeak(text)
     NacChat.setLang(code)
     NacChat.snapshotTree()        // returns the tree posted to backend
     NacChat.onAction(kind, fn)    // override or extend a kind handler

   ASCII-only.
   =============================================================== */
(function (global) {
  'use strict';

  var NacChat = {
    _endpoint:  '/crm/api/v1/yujin/nac-demo',
    _sessionId: 'sess_' + Math.random().toString(36).slice(2, 10),
    _lang:      'es',
    _ttsEnabled: true,
    _voiceAlwaysOn: false,
    _history:   [],
    _chatLog:   null,
    _input:     null,
    _langSelect:null,
    _customHandlers: Object.create(null),
    _ttsBusyUntil: 0,
    _ttsRecentBuf: [],
    _TTS_RECENT_MAX: 8,
    _TTS_RECENT_TTL_MS: 30000,
    _sttBuffer: '',
    _sttFlushTimer: null,
    _STT_SILENCE_MS: 1100,
    _recognizer: null
  };

  /* ---------- BCP47 locale map for STT/TTS ---------- */
  var TTS_BCP47 = {
    es: 'es-ES', en: 'en-US', pt: 'pt-BR', fr: 'fr-FR', it: 'it-IT',
    de: 'de-DE', ja: 'ja-JP', zh: 'zh-CN', hi: 'hi-IN', ar: 'ar-SA'
  };

  /* ---------- locale switch dictionary (fix C7-bis) ---------- */
  var LOCALE_NAMES = {
    'espanol': 'es', 'castellano': 'es', 'spanish': 'es', 'espanhol': 'es', 'espagnol': 'es', 'spanisch': 'es', 'spagnolo': 'es',
    'ingles':  'en', 'english':  'en', 'ingles_pt': 'en', 'inglese': 'en', 'englisch': 'en', 'anglais': 'en', 'ingles_pt2': 'en',
    'portugues':'pt','portuguese':'pt','portugais':'pt','portoghese':'pt','portugiesisch':'pt',
    'frances': 'fr', 'french':   'fr', 'francese': 'fr', 'franzosisch': 'fr',
    'italiano':'it', 'italian':  'it', 'italien':  'it', 'italienisch': 'it',
    'aleman':  'de', 'german':   'de', 'allemand': 'de', 'deutsch':  'de', 'tedesco':  'de', 'alemao':   'de',
    'japones': 'ja', 'japanese': 'ja', 'japonais': 'ja', 'giapponese': 'ja',
    'chino':   'zh', 'chinese':  'zh', 'chinois':  'zh', 'cinese':   'zh',
    'hindi':   'hi',
    'arabe':   'ar', 'arabic':   'ar', 'arabo':    'ar',
    'es': 'es', 'en': 'en', 'pt': 'pt', 'fr': 'fr', 'it': 'it',
    'de': 'de', 'ja': 'ja', 'zh': 'zh', 'hi': 'hi', 'ar': 'ar'
  };
  var LOCALE_SWITCH_VERB = /\b(cambia|cambiar|cambialo|cambiame|switch|change|use|using|set|pon|poner|usa|usar|wechseln|cambiare|mudar?|changer|to)\b/;
  var LOCALE_TRIGGER     = /\b(idioma|language|sprache|lingua|langue)\b/;

  function _normalizeForFilter(s) {
    return String(s || '').toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function _detectLangSwitch(text) {
    /* Bare 2-letter locale codes ('de','es','en',...) collide with
       common words/prepositions in several languages: 'de' is the
       Spanish/Portuguese preposition, 'es' is German "is", 'en' is
       Spanish "in", etc. Accept them only when an explicit
       LOCALE_TRIGGER ('idioma'/'language'/'sprache'/...) is also
       present; full names ('espanol','deutsch','english') keep
       working with just a switch verb. Fixes "cambia de pestana"
       and "cambia precio de mouse 40" being misrouted to German.
       Pablo report 2026-05-09. */
    var norm = _normalizeForFilter(text);
    if (!norm) return null;
    var hasVerb = LOCALE_SWITCH_VERB.test(norm);
    var hasTrigger = LOCALE_TRIGGER.test(norm);
    var tokens = norm.split(' ').filter(Boolean);
    var found = null;
    var foundIs2Letter = false;
    for (var i = 0; i < tokens.length; i++) {
      var tok = tokens[i];
      if (!LOCALE_NAMES[tok]) continue;
      var is2 = tok.length === 2;
      if (is2 && !hasTrigger) continue;
      found = LOCALE_NAMES[tok];
      foundIs2Letter = is2;
      break;
    }
    if (!found) return null;
    if (hasVerb || hasTrigger) return found;
    if (tokens.length <= 3 && !foundIs2Letter) return found;
    return null;
  }

  /* ---------- TTS feedback filter (fix C1) ---------- */
  function _ttsRememberUtterance(text) {
    if (!text) return;
    NacChat._ttsRecentBuf.push({
      norm: _normalizeForFilter(text),
      ts:   Date.now()
    });
    while (NacChat._ttsRecentBuf.length > NacChat._TTS_RECENT_MAX) {
      NacChat._ttsRecentBuf.shift();
    }
  }
  function _isBotEcho(text) {
    if (!text) return false;
    var norm = _normalizeForFilter(text);
    if (!norm) return false;
    var now = Date.now();
    while (NacChat._ttsRecentBuf.length
        && now - NacChat._ttsRecentBuf[0].ts > NacChat._TTS_RECENT_TTL_MS) {
      NacChat._ttsRecentBuf.shift();
    }
    for (var i = 0; i < NacChat._ttsRecentBuf.length; i++) {
      var entry = NacChat._ttsRecentBuf[i].norm;
      if (!entry) continue;
      if (entry === norm) return true;
      if (entry.length > 8 && entry.indexOf(norm) >= 0) return true;
      if (norm.length  > 8 && norm.indexOf(entry) >= 0) return true;
      var a = entry.split(' '), b = norm.split(' ');
      if (a.length >= 3 && b.length >= 3) {
        var setA = new Set(a), hit = 0;
        for (var k = 0; k < b.length; k++) if (setA.has(b[k])) hit++;
        if (hit / Math.max(a.length, b.length) >= 0.7) return true;
      }
    }
    return false;
  }

  /* ---------- DOM helpers ---------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function _bubble(role, text) {
    if (!NacChat._chatLog) return;
    var li = document.createElement('div');
    li.className = 'nac-chat-bubble ' + role;
    li.textContent = text;
    NacChat._chatLog.appendChild(li);
    NacChat._chatLog.scrollTop = NacChat._chatLog.scrollHeight;
  }

  /* ---------- TTS ---------- */
  function botSpeak(text, opts) {
    opts = opts || {};
    if (!opts.skipBubble) _bubble('bot', text);
    _ttsRememberUtterance(text);
    if (!NacChat._ttsEnabled || !('speechSynthesis' in window)) return;
    try {
      var u = new SpeechSynthesisUtterance(text);
      u.lang = TTS_BCP47[NacChat._lang] || 'en-US';
      u.rate = 1.05; u.pitch = 1.0;
      var charsPerSec = 14;
      var estMs = Math.max(800, Math.round((text.length / charsPerSec) * 1500));
      NacChat._ttsBusyUntil = Math.max(NacChat._ttsBusyUntil, Date.now()) + estMs;
      u.onend   = function () { NacChat._ttsBusyUntil = Date.now(); };
      u.onerror = function () { NacChat._ttsBusyUntil = Date.now(); };
      window.speechSynthesis.speak(u);
    } catch (e) { /* swallow; TTS best-effort */ }
  }
  NacChat.botSpeak = botSpeak;

  /* ---------- Confirm-dialog YES/NO routing (fix C3) ---------- */
  function _findPendingConfirm() {
    return document.querySelector(
      '[data-nac-role="confirm-dialog"][data-nac-state="pending"]');
  }
  function _maybeAnswerPendingConfirm(rawText) {
    var dialog = _findPendingConfirm();
    if (!dialog) return false;
    var id = dialog.getAttribute('data-nac-id');
    var norm = _normalizeForFilter(rawText);
    var tokens = norm.split(' ').filter(Boolean);
    var YES = ['si','yes','ya','oui','ja','sim','hai','ok','okay','aprobar','aprob','confirmar','confirma','confirmo','dale','adelante'];
    var NO  = ['no','nope','non','nein','nao','iie','la','cancel','cancela','cancelar','cancelo','aborta','abortar','para'];
    function hit(arr) { for (var i = 0; i < tokens.length; i++) if (arr.indexOf(tokens[i]) >= 0) return true; return false; }
    var isYes = hit(YES), isNo = hit(NO);
    if (!isYes && !isNo) return false;
    var btn = document.querySelector('[data-nac-id="' + id + (isYes ? '.confirm' : '.cancel') + '"]');
    if (!btn) return false;
    btn.click();
    botSpeak(isYes ? 'Confirmado.' : 'Cancelado.', { skipBubble: true });
    return true;
  }
  /* v2.2.1: guard browser-only listener so this bundle is importable in
     Node / SSR / test contexts without crashing. */
  if (typeof document !== 'undefined') {
    document.addEventListener('nac:confirm:requested', function (e) {
      try {
        var prompt = (e && e.detail && e.detail.prompt) || '';
        if (!prompt) return;
        var hints = {
          es: 'Decime si o no.', en: 'Say yes or no.', pt: 'Diga sim ou nao.',
          fr: 'Dites oui ou non.', it: 'Dimmi si o no.', de: 'Sag ja oder nein.',
          ja: 'はい か いいえ で答えて。', zh: '请说 是 或 否。',
          hi: 'haan ya nahin.', ar: 'قل نعم او لا.'
        };
        botSpeak(prompt + ' ' + (hints[NacChat._lang] || hints.es), { skipBubble: true });
      } catch (_) {}
    }, true);
  }

  /* ---------- Locale switch (fix C7-bis) ---------- */
  function _maybeChangeLocaleLocally(text) {
    var code = _detectLangSwitch(text);
    if (!code) return false;
    /* Caller paints the user bubble BEFORE invoking us so the
       visual order is "user said X" -> "bot replies Y". The
       previous version painted the bot bubble inside this
       function and the user bubble after it, producing the
       ack-before-prompt visual bug Pablo reported on
       2026-05-09. */
    if (code === NacChat._lang) {
      botSpeak('Ya estoy en ese idioma.');
      return true;
    }
    NacChat.setLang(code);
    var ack = {
      es: 'Cambie a espanol.', en: 'Switched to English.',
      pt: 'Mudei para portugues.', fr: 'Bascule en francais.',
      it: 'Sono passato all italiano.', de: 'Auf Deutsch umgestellt.',
      ja: '日本語に切り替えました。', zh: '已切换到中文。',
      hi: 'Hindi mein switch kar diya.', ar: 'تم التغيير الى العربية.'
    };
    botSpeak(ack[code] || ('Switched to ' + code + '.'));
    return true;
  }

  /* ---------- Snapshot ---------- */
  NacChat.snapshotTree = function () {
    if (!global.NAC || typeof global.NAC.describe !== 'function') return null;
    try {
      var snap = global.NAC.describe();
      var plugins = (snap.plugins || []).map(function (p) {
        var m = null;
        try {
          if (typeof global.NAC.manifest === 'function' && p && p.plugin) {
            m = global.NAC.manifest(p.plugin);
          }
        } catch (_) {}
        return {
          plugin:   p.plugin || '',
          state:    p.state  || '',
          elements: p.elements || [],
          manifest: m || null
        };
      });
      var out = { active: snap.active || null, plugins: plugins };
      try {
        if (typeof global.NAC.describe_v2 === 'function') {
          var v2 = global.NAC.describe_v2();
          if (v2) {
            out.v2_scope_entries = v2.v2_scope_entries || [];
            out.sitemap          = v2.sitemap || null;
            out.tenant_prefix    = v2.tenant_prefix || null;
            out.nac_version_v2   = v2.nac_version || null;
            out.data_tables      = v2.data_tables || [];
          }
        }
      } catch (_) {}
      console.log('[nac-chat] snapshot plugins (' + plugins.length + '):',
        plugins.map(function (p) { return p.plugin; }).join(', '));
      if (out.data_tables && out.data_tables.length) {
        console.log('[nac-chat] data_tables:',
          out.data_tables.map(function (t) {
            return t.table_id + ' (' + t.subkind + ')';
          }).join(', '));
      }
      return out;
    } catch (e) {
      console.warn('[nac-chat] snapshot failed:', e && e.message);
      return null;
    }
  };

  /* ---------- Direct DOM dispatch helpers ---------- */
  /* These bypass NAC.click() / NAC.fill() polling for
     nac:action:succeeded so demos and brownfield adopters that
     have not wired the ack event on every handler still work
     end-to-end. The host is still responsible for the side
     effect; we just don't wait for the conformance ack. */
  function _directClick(nacId) {
    if (!nacId) throw new Error('click: nac_id required');
    var el = document.querySelector('[data-nac-id="' + nacId + '"]');
    if (!el) throw new Error('click: element not found ' + nacId);
    try { el.click(); return { ok: true, dispatched: 'direct' }; }
    catch (e) { throw new Error('click threw: ' + (e && e.message)); }
  }
  function _directClickByVerb(plugin, verb) {
    if (!verb) throw new Error('click_by_verb: verb required');
    /* Resolve verb -> nac_id by walking the v1 manifest cache.
       NAC.manifest(plugin) returns {actions:[{verb, nac_id}]}. */
    var manifest = null;
    try { if (typeof global.NAC.manifest === 'function') manifest = global.NAC.manifest(plugin); }
    catch (_) {}
    var actions = manifest && manifest.actions || [];
    var match = actions.filter(function (a) { return a && a.verb === verb; })[0];
    var nacId = match && (match.nac_id || match.id);
    if (!nacId) {
      /* Fallback: walk the DOM looking for an element under this
         plugin whose data-nac-action matches the verb. */
      var root = plugin
        ? document.querySelector('[data-nac-plugin="' + plugin + '"]')
        : document;
      var hit = root && root.querySelector('[data-nac-action="' + verb + '"][data-nac-id]');
      if (!hit) throw new Error('click_by_verb: no nac_id for verb=' + verb + ' plugin=' + plugin);
      try { hit.click(); return { ok: true, dispatched: 'direct_dom_walk' }; }
      catch (e) { throw new Error('click_by_verb threw: ' + e.message); }
    }
    return _directClick(nacId);
  }
  function _directFill(nacId, value) {
    if (!nacId) throw new Error('fill: nac_id required');
    var el = document.querySelector('[data-nac-id="' + nacId + '"]');
    if (!el) throw new Error('fill: element not found ' + nacId);
    try {
      el.focus();
      el.value = value == null ? '' : String(value);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { ok: true };
    } catch (e) { throw new Error('fill threw: ' + e.message); }
  }
  function _directSelect(nacId, value) {
    if (!nacId) throw new Error('select: nac_id required');
    var el = document.querySelector('[data-nac-id="' + nacId + '"]');
    if (!el) throw new Error('select: element not found ' + nacId);
    try {
      if (el.tagName === 'SELECT') {
        el.value = value;
        el.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        /* radio/checkbox: find the option with matching value */
        var opt = el.querySelector('[value="' + value + '"]');
        if (opt) {
          opt.checked = true;
          opt.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
          el.value = value;
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
      return { ok: true };
    } catch (e) { throw new Error('select threw: ' + e.message); }
  }

  /* ---------- Backend dispatch ---------- */
  async function _backendCall(text) {
    var snap = NacChat.snapshotTree();
    var body = {
      session_id: NacChat._sessionId,
      prompt:     text,
      lang:       NacChat._lang,
      history:    NacChat._history.slice(-8),
      nac_tree:   snap
    };
    try {
      var resp = await fetch(NacChat._endpoint, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(body)
      });
      if (!resp.ok) {
        return { ok: false, error: 'http_' + resp.status };
      }
      var json = await resp.json();
      return json && json.ok !== false ? { ok: true, data: json } : { ok: false, error: (json && json.error) || 'backend_error' };
    } catch (e) {
      return { ok: false, error: 'fetch_' + (e && e.message || 'unknown') };
    }
  }

  /* ---------- Action dispatcher ---------- */
  async function _dispatchAction(a) {
    if (NacChat._customHandlers[a.kind]) {
      return await NacChat._customHandlers[a.kind](a);
    }
    if (!global.NAC) throw new Error('NAC runtime missing');
    switch (a.kind) {
      case 'click':
        /* 2026-05-09 fix: NAC.click() polls for nac:action:
           succeeded with a 5s timeout. Many demos / adopters
           do not wire that ack event on every handler, so the
           click visually executes (modal opens, button fires)
           but the promise rejects on timeout and the chat
           reports 'action failed'. We dispatch the DOM click
           directly here -- the side effect happens; ack is
           best-effort. Spec sec 18 requires the ack only at
           NAC-3 conformance level. */
        return _directClick(a.nac_id);
      case 'click_by_verb':
        /* Same reasoning. We resolve verb -> nac_id locally
           then dispatch the DOM click directly. */
        return _directClickByVerb(a.plugin || null, a.verb);
      case 'fill':
        return _directFill(a.nac_id, a.value);
      case 'select':
        return _directSelect(a.nac_id, a.value);
      case 'tab':             return await global.NAC.tab(a.plugin, a.tab_key);
      case 'tab_by_label':    return await global.NAC.tab_by_label(a.plugin || null, a.label);
      case 'drag_drop':       return await global.NAC.drag_drop(a.nac_id, a.target_nac_id,
                                  typeof a.to_index === 'number' ? { to_index: a.to_index } : undefined);
      case 'go_to_section':   return await global.NAC.go_to_section(a.nac_id);
      case 'say':             if (a.text) botSpeak(a.text); return { ok: true };
      case 'change_locale':
        if (typeof a.locale === 'string' && a.locale.length === 2) {
          NacChat.setLang(a.locale);
          return { ok: true };
        }
        throw new Error('change_locale: missing locale');
      /* v2.1 sec 18 */
      case 'dt_add_row': {
        if (typeof global.NAC.dt_add_row !== 'function') throw new Error('dt_add_row missing -- runtime older than v2.1');
        var r = global.NAC.dt_add_row(a.table_id, a.values || {});
        if (r && r.ok === false) throw new Error('dt_add_row: ' + r.error + (r.column ? ' (' + r.column + ')' : ''));
        return { ok: true, row_id: r && r.row_id };
      }
      case 'dt_remove_row':
        if (typeof global.NAC.dt_remove_row !== 'function') throw new Error('dt_remove_row missing');
        global.NAC.dt_remove_row(a.table_id, a.row_id); return { ok: true };
      case 'dt_edit_cell': {
        if (typeof global.NAC.dt_edit_cell !== 'function') throw new Error('dt_edit_cell missing');
        var r2 = global.NAC.dt_edit_cell(a.table_id, a.row_id, a.column, a.value);
        if (r2 && r2.ok === false) throw new Error('dt_edit_cell: ' + r2.error);
        return { ok: true };
      }
      case 'dt_set_cell': {
        if (typeof global.NAC.dt_set_cell !== 'function') throw new Error('dt_set_cell missing');
        var r3 = global.NAC.dt_set_cell(a.table_id, a.row, a.col, a.value);
        if (r3 && r3.ok === false) throw new Error('dt_set_cell: ' + r3.error);
        return { ok: true };
      }
      case 'dt_select':
        if (typeof global.NAC.dt_select !== 'function') throw new Error('dt_select missing');
        return global.NAC.dt_select(a.table_id, a.target);
      case 'dt_commit': {
        if (typeof global.NAC.dt_commit !== 'function') throw new Error('dt_commit missing');
        var rc = global.NAC.dt_commit(a.table_id);
        if (rc && rc.ok === false) {
          throw new Error('dt_commit blocked: ' +
            (rc.errors || []).map(function (e) { return e.code; }).join(', '));
        }
        return { ok: true, final_state: rc && rc.final_state };
      }
      case 'dt_discard':
        if (typeof global.NAC.dt_discard !== 'function') throw new Error('dt_discard missing');
        global.NAC.dt_discard(a.table_id); return { ok: true };
      case 'dt_read_aggregate':
        if (typeof global.NAC.dt_read_aggregate !== 'function') throw new Error('dt_read_aggregate missing');
        return { ok: true, value: global.NAC.dt_read_aggregate(a.table_id, a.agg_key, a.column) };
      default:
        throw new Error('unknown action kind: ' + a.kind);
    }
  }

  /* ---------- Send pipeline ---------- */
  NacChat.send = async function (text) {
    text = (text || '').trim();
    if (!text) return;
    /* TTS interrupt: a fresh user turn cancels pending bot speech. */
    if ('speechSynthesis' in window) {
      try { window.speechSynthesis.cancel(); } catch (_) {}
      NacChat._ttsBusyUntil = 0;
    }
    /* Paint the user bubble FIRST so visual order is always
       "user said X" -> "bot replies Y", regardless of whether
       the path is local short-circuit or backend round-trip. */
    _bubble('user', text);
    /* Short-circuits BEFORE the LLM round-trip. */
    if (_maybeAnswerPendingConfirm(text)) { return; }
    if (_maybeChangeLocaleLocally(text))  { return; }

    NacChat._history.push({ role: 'user', text: text });

    var resp = await _backendCall(text);
    if (!resp.ok) {
      botSpeak('Falla del backend: ' + resp.error);
      return;
    }
    var d = resp.data;
    /* Prefer the structured shape {message, actions[]} but be
       tolerant to legacy shapes that returned only {reply} or
       a single action. */
    var message = d.message || d.reply || '';
    var actions = Array.isArray(d.actions) ? d.actions : (d.action ? [d.action] : []);
    /* 2026-05-09 diagnostic: log EXACTLY what the backend
       returned so 'chat says X but nothing happens' is
       distinguishable from 'chat dispatched X but it failed
       silently'. If the LLM only emits a {message} with no
       actions, this log makes it obvious. */
    console.log('[nac-chat] backend response: message="' + message
      + '" actions=' + JSON.stringify(actions));
    if (message) {
      _bubble('bot', message);
      _ttsRememberUtterance(message);
      if (NacChat._ttsEnabled && 'speechSynthesis' in window) {
        try {
          var u = new SpeechSynthesisUtterance(message);
          u.lang = TTS_BCP47[NacChat._lang] || 'en-US'; u.rate = 1.05;
          window.speechSynthesis.speak(u);
        } catch (_) {}
      }
      NacChat._history.push({ role: 'assistant', text: message });
    }
    for (var i = 0; i < actions.length; i++) {
      try {
        await _dispatchAction(actions[i]);
      } catch (e) {
        console.warn('[nac-chat] action failed:', actions[i], e && e.message);
        _bubble('bot', 'No pude ejecutar: ' + (e && e.message || e));
      }
    }
  };

  /* ---------- STT ---------- */
  function _ensureRecognizer() {
    if (NacChat._recognizer) return NacChat._recognizer;
    var Cls = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Cls) return null;
    var r = new Cls();
    r.lang = TTS_BCP47[NacChat._lang] || 'en-US';
    r.continuous = false;
    r.interimResults = true;
    function flushBuffer() {
      var text = (NacChat._sttBuffer || '').trim();
      NacChat._sttBuffer = '';
      if (NacChat._sttFlushTimer) { clearTimeout(NacChat._sttFlushTimer); NacChat._sttFlushTimer = null; }
      if (!text) return;
      if (_isBotEcho(text)) {
        console.log('[nac-chat-stt] dropping bot-echo:', text);
        return;
      }
      if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
        console.log('[nac-chat-stt] dropping during TTS:', text);
        return;
      }
      NacChat.send(text);
    }
    r.onresult = function (e) {
      if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
        return;  /* half-duplex */
      }
      for (var i = e.resultIndex; i < e.results.length; i++) {
        var res = e.results[i];
        if (!res.isFinal) continue;
        var txt = (res[0] && res[0].transcript || '').trim();
        if (!txt) continue;
        NacChat._sttBuffer = NacChat._sttBuffer ? (NacChat._sttBuffer + ' ' + txt) : txt;
        if (NacChat._sttFlushTimer) clearTimeout(NacChat._sttFlushTimer);
        NacChat._sttFlushTimer = setTimeout(flushBuffer, NacChat._STT_SILENCE_MS);
      }
    };
    r.onend = function () {
      if (NacChat._voiceAlwaysOn) {
        try {
          r.lang = TTS_BCP47[NacChat._lang] || 'en-US';
          r.continuous = true;
          r.start();
          return;
        } catch (_) {}
      }
      _setMicState('idle');
    };
    r.onerror = function (e) {
      var fatal = e.error === 'not-allowed' || e.error === 'service-not-allowed';
      if (NacChat._voiceAlwaysOn && !fatal) return;
      botSpeak('Mic error: ' + e.error, { skipBubble: true });
      _setMicState('idle');
    };
    NacChat._recognizer = r;
    return r;
  }
  function _setMicState(state) {
    if (!NacChat._micBtn) return;
    NacChat._micBtn.setAttribute('data-nac-state', state);
    NacChat._micBtn.setAttribute('aria-pressed', state === 'active' ? 'true' : 'false');
  }

  function _toggleMic() {
    var r = _ensureRecognizer();
    if (!r) { botSpeak('Tu navegador no soporta speech recognition.'); return; }
    if (NacChat._micBtn && NacChat._micBtn.getAttribute('data-nac-state') === 'active') {
      try { r.stop(); } catch (_) {}
      _setMicState('idle');
    } else {
      try {
        r.lang = TTS_BCP47[NacChat._lang] || 'en-US';
        r.continuous = !!NacChat._voiceAlwaysOn;
        r.start();
        _setMicState('active');
      } catch (e) {
        console.warn('[nac-chat-stt] start failed:', e);
      }
    }
  }
  function _toggleHandsFree() {
    NacChat._voiceAlwaysOn = !NacChat._voiceAlwaysOn;
    if (NacChat._handsFreeBtn) {
      NacChat._handsFreeBtn.setAttribute('aria-pressed', NacChat._voiceAlwaysOn ? 'true' : 'false');
      NacChat._handsFreeBtn.setAttribute('data-nac-state', NacChat._voiceAlwaysOn ? 'active' : 'idle');
    }
    if (NacChat._voiceAlwaysOn) {
      _ensureRecognizer();
      try { NacChat._recognizer.continuous = true; NacChat._recognizer.start(); } catch (_) {}
      _setMicState('active');
      botSpeak('Manos libres activado.');
    } else {
      try { NacChat._recognizer && NacChat._recognizer.stop(); } catch (_) {}
      _setMicState('idle');
      botSpeak('Manos libres desactivado.');
    }
  }
  function _toggleTts() {
    NacChat._ttsEnabled = !NacChat._ttsEnabled;
    if (NacChat._ttsBtn) {
      NacChat._ttsBtn.setAttribute('aria-pressed', NacChat._ttsEnabled ? 'true' : 'false');
    }
    if (!NacChat._ttsEnabled) {
      try { window.speechSynthesis.cancel(); } catch (_) {}
    }
  }

  NacChat.setLang = function (code) {
    if (!code || !TTS_BCP47[code]) return;
    NacChat._lang = code;
    document.documentElement.setAttribute('lang', code);
    if (NacChat._langSelect && NacChat._langSelect.value !== code) {
      NacChat._langSelect.value = code;
    }
    if (NacChat._recognizer) {
      try { NacChat._recognizer.lang = TTS_BCP47[code] || 'en-US'; } catch (_) {}
    }
  };
  NacChat.onAction = function (kind, fn) {
    NacChat._customHandlers[kind] = fn;
  };

  /* ---------- init ---------- */
  NacChat.init = function (opts) {
    opts = opts || {};
    if (opts.endpoint)    NacChat._endpoint    = opts.endpoint;
    if (opts.sessionId)   NacChat._sessionId   = opts.sessionId;
    if (opts.lang)        NacChat._lang        = opts.lang;
    if (opts.chatLog)     NacChat._chatLog     = opts.chatLog;
    if (opts.input)       NacChat._input       = opts.input;
    if (opts.langSelect)  NacChat._langSelect  = opts.langSelect;
    NacChat._micBtn       = opts.micBtn       || null;
    NacChat._handsFreeBtn = opts.handsFreeBtn || null;
    NacChat._ttsBtn       = opts.ttsBtn       || null;
    if (NacChat._input) {
      NacChat._input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          var v = NacChat._input.value.trim();
          if (v) { NacChat._input.value = ''; NacChat.send(v); }
        }
      });
    }
    if (opts.sendBtn) {
      opts.sendBtn.addEventListener('click', function () {
        var v = NacChat._input && NacChat._input.value.trim();
        if (v) { NacChat._input.value = ''; NacChat.send(v); }
      });
    }
    if (NacChat._micBtn)        NacChat._micBtn.addEventListener('click', _toggleMic);
    if (NacChat._handsFreeBtn)  NacChat._handsFreeBtn.addEventListener('click', _toggleHandsFree);
    if (NacChat._ttsBtn)        NacChat._ttsBtn.addEventListener('click', _toggleTts);
    if (NacChat._langSelect) {
      NacChat._langSelect.addEventListener('change', function () {
        NacChat.setLang(NacChat._langSelect.value);
      });
    }
  };

  global.NacChat = NacChat;
})(typeof window !== 'undefined' ? window : globalThis);
