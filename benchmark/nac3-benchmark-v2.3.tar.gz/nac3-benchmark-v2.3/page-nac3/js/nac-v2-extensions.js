/* ===============================================================
   nac-v2-extensions.js -- NAC v2.0 additive extensions to v1.9
   ---------------------------------------------------------------
   Strict superset: this file LOADS AFTER nac.js v1.9.0 and ATTACHES
   the v2.0 primitives onto window.NAC without modifying the v1.9
   surface. Every v1.9 client keeps working unchanged.

   Provides:
     - NAC.scope(spec)                      hierarchical constructor
     - NAC.autoRegister(el, opts)           DOM-driven registration
     - NAC.adopt(rule)                      third-party non-compliant
     - NAC.bridgeShadowRoot(host)           Shadow DOM bridge
     - NAC.bridgeIframe(iframeEl, opts)     same-vendor iframe bridge
     - NAC.declareVirtual(spec)             virtualized lists
     - NAC.captureEphemeral(opts)           transient UI capture
     - NAC.setTenantPrefix(slug)            multi-tenant naming
     - NAC.declareSitemap(spec)             optional sitemap (sec 17)
     - NAC.attestUserGesture(opts)          isTrusted attestation
     - NAC.t(key, opts?)                    i18n resolver
     - NAC.registerCatalog(catalog)         i18n catalog registration
     - NAC.locale(code?)                    locale getter/setter
     - NAC.setSupportedLocales(arr)         extend supported list
     - NAC.setRTLLocales(arr)               extend RTL list
     - NAC.set_provenance_secret(secret)    HMAC secret registration

   And tightens (only at NAC-3):
     - check_canonical_shape: agent must sign + user_gesture_attested
     - validate_global: i18n_strict mode

   Spec: spec/NAC-v2.0.md + RFC_v2.0.0.md
   ASCII-only.
   =============================================================== */
(function (global) {
  'use strict';
  if (!global.NAC) {
    console.error('[NAC v2] requires nac.js v1.9.0+ to be loaded first');
    return;
  }
  if (global.NAC.__nac_v2_installed) return;
  global.NAC.__nac_v2_installed = true;

  var NAC = global.NAC;
  var SEPARATOR = '.';
  var MAX_DEPTH = 6;
  var WARN_DEPTH = 4;

  /* ------------------------------------------------------------- locales */

  var SUPPORTED_LOCALES_DEFAULT = ['es','en','pt','fr','it','de','ja','zh','hi','ar'];
  var RTL_LOCALES_DEFAULT       = ['ar','he','fa','ur'];
  var _supported = SUPPORTED_LOCALES_DEFAULT.slice();
  var _rtl       = RTL_LOCALES_DEFAULT.slice();
  var _currentLocale = (function () {
    try {
      var l = (document.documentElement.getAttribute('lang')
            || navigator.language
            || 'es').slice(0, 2).toLowerCase();
      return _supported.indexOf(l) >= 0 ? l : 'es';
    } catch (_) { return 'es'; }
  })();
  var _catalog = Object.create(null);

  function setSupportedLocales(arr) {
    if (!Array.isArray(arr) || !arr.length) {
      throw new Error('[NAC v2] setSupportedLocales requires non-empty array');
    }
    _supported = arr.slice();
  }
  function setRTLLocales(arr) {
    if (!Array.isArray(arr)) throw new Error('[NAC v2] setRTLLocales requires array');
    _rtl = arr.slice();
  }
  /* v2.0-rc3 (Claude T5-F4): some hosts ship multi-locale
     content in one DOM (e.g. user in 'ar' viewing untranslated
     English log lines); auto-flipping dir=rtl on documentElement
     globally breaks the LTR content's BIDI. Hosts opt out via
     setAutoRTL(false), then manage dir on a sub-tree element. */
  var _autoRTL = true;
  function setAutoRTL(enabled) { _autoRTL = !!enabled; }

  function locale(code) {
    if (code === undefined) return _currentLocale;
    if (_supported.indexOf(code) < 0) {
      console.warn('[NAC v2] locale', code, 'not in supported list');
    }
    _currentLocale = code;
    /* Auto-apply dir=rtl unless host opted out via setAutoRTL(false). */
    if (_autoRTL) {
      try {
        if (_rtl.indexOf(code) >= 0) {
          document.documentElement.setAttribute('dir', 'rtl');
        } else {
          document.documentElement.removeAttribute('dir');
        }
      } catch (_) {}
    }
    document.dispatchEvent(new CustomEvent('nac:locale_changed', {
      detail: { locale: code, autoRTL: _autoRTL }, bubbles: true
    }));
  }
  function registerCatalog(obj) {
    if (!obj || typeof obj !== 'object') {
      throw new Error('[NAC v2] registerCatalog requires object');
    }
    Object.keys(obj).forEach(function (k) { _catalog[k] = obj[k]; });
  }
  function t(key, opts) {
    opts = opts || {};
    var loc = opts.locale || _currentLocale;
    var entry = _catalog[key];
    if (!entry) return opts.fallback || key;
    if (entry[loc]) return entry[loc];
    /* Fallback chain: requested -> es -> en -> first available */
    if (entry.es) return entry.es;
    if (entry.en) return entry.en;
    var firstKey = Object.keys(entry)[0];
    return firstKey ? entry[firstKey] : (opts.fallback || key);
  }

  /* ------------------------------------------------------------- HMAC */

  var _provenanceSecrets = [];
  function set_provenance_secret(s) {
    if (typeof s === 'string') _provenanceSecrets = [s];
    else if (Array.isArray(s)) _provenanceSecrets = s.slice();
    else if (s == null) _provenanceSecrets = [];
    else throw new Error('[NAC v2] set_provenance_secret expects string|string[]');
    /* v2.0-rc3 (Claude T6-F2): warm the crypto path now that we
       have a secret registered; first agent sign won't pay the
       cold-start cost. */
    if (_provenanceSecrets[0] && typeof NAC.sign_provenance === 'function') {
      try {
        NAC.sign_provenance({ _warmup: true, ts: Date.now() }, _provenanceSecrets[0])
          .catch(function () {});
      } catch (_) {}
    }
  }
  /* sign / verify provenance helpers exist in v1.9 already; reuse them */
  function _hasSecrets() { return _provenanceSecrets.length > 0; }

  async function _verify_with_registered(detail) {
    if (!_hasSecrets()) return false;
    if (typeof NAC.verify_provenance !== 'function') return false;
    for (var i = 0; i < _provenanceSecrets.length; i++) {
      try {
        var ok = await NAC.verify_provenance(detail, _provenanceSecrets[i]);
        if (ok) return true;
      } catch (_) {}
    }
    return false;
  }

  /* ------------------------------------------------------------- isTrusted */

  /* v2.0-rc3 (Claude T4-F1 BLOCKER fix): the gesture buffer is now
     bound to the originating event's composedPath, NOT a global
     flag. _readGestureAttested(forElement) verifies that the
     element being invoked is in the captured path before honoring
     attested. Without this, any user click anywhere on the page
     leaked attested=true to ANY subsequent _invoke within the
     freshness window -- the FOURTH impersonation path Claude
     surfaced.

     Additionally: GESTURE_FRESH_MS reduced 100ms -> 16ms (one
     animation frame). Genuine click handlers run synchronously
     (or via microtask), well within 16ms. Promise-resolved-later
     handlers no longer count as user-attested -- which is the
     security-correct behaviour. */
  var _lastGestureTrusted = null;
  var _lastGestureTime = 0;
  var _lastGesturePath = null;          /* Array<EventTarget> from e.composedPath() */
  var GESTURE_FRESH_MS = 16;             /* was 100 in rc2 */

  /* v2.0-rc2 (Mistral T4-F1): mobile WebView contexts (Cordova,
     Capacitor, React Native WebView) have inconsistent isTrusted
     semantics. Hosts running in those environments register a
     custom derivation function via setMobileWebViewAttestation so
     the platform-specific signal substitutes for browser
     event.isTrusted. */
  var _mobileWebViewAttestor = null;

  function setMobileWebViewAttestation(fn) {
    if (fn != null && typeof fn !== 'function') {
      throw new Error('[NAC v2] setMobileWebViewAttestation expects function|null');
    }
    _mobileWebViewAttestor = fn;
  }

  function _captureGestureFromDom() {
    var handler = function (e) {
      /* When a custom WebView attestor is registered, its return
         value (or function call given the event) substitutes the
         raw isTrusted reading. */
      if (_mobileWebViewAttestor) {
        try {
          var attested = !!_mobileWebViewAttestor(e);
          _lastGestureTrusted = attested;
        } catch (err) {
          _lastGestureTrusted = !!e.isTrusted;
        }
      } else {
        _lastGestureTrusted = !!e.isTrusted;
      }
      _lastGestureTime = Date.now();
      /* v2.0-rc3: capture the composed path so _invoke can verify
         identity. Polyfill for ancient browsers via target ancestor
         walk (composedPath() ships in all browsers >= 2018). */
      try {
        if (typeof e.composedPath === 'function') {
          _lastGesturePath = e.composedPath();
        } else {
          _lastGesturePath = [];
          var n = e.target;
          while (n) { _lastGesturePath.push(n); n = n.parentNode; }
        }
      } catch (_) {
        _lastGesturePath = e.target ? [e.target] : [];
      }
    };
    ['click','keydown','keyup','touchstart','pointerdown'].forEach(function (n) {
      document.addEventListener(n, handler, { capture: true, passive: true });
    });
  }
  /* v2.2.1: guard browser-only DOM hookup so this bundle is
     importable in Node / SSR / test contexts. */
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', _captureGestureFromDom);
    } else {
      _captureGestureFromDom();
    }
  }

  /* v2.0-rc3: _readGestureAttested now requires the element being
     invoked. Returns the captured attested flag ONLY if:
       (a) the gesture is within GESTURE_FRESH_MS (16ms) AND
       (b) `forElement` is in the captured composedPath (or no
           element was captured -- legacy callers).
     Returns null in all other cases (matrix treats null as
     not-attested -> 'user' source rejected at NAC-3). */
  function _readGestureAttested(forElement) {
    if (Date.now() - _lastGestureTime > GESTURE_FRESH_MS) return null;
    if (!forElement) return _lastGestureTrusted; /* legacy fallback */
    if (!_lastGesturePath || !_lastGesturePath.length) return _lastGestureTrusted;
    /* Identity check: only honor attested when the target element
       is in the originating event's path. Closes Claude T4-F1. */
    if (_lastGesturePath.indexOf(forElement) >= 0) {
      return _lastGestureTrusted;
    }
    return null;
  }

  /* Buffer for validate_global_v2 to surface findings emitted
     by runtime guards (added rc6). Declared BEFORE
     attestUserGesture so the override-blocking branch can
     push into it without a temporal-dead-zone error. */
  var _validatorFindings = [];

  var _scriptOverride = null;
  function attestUserGesture(opts) {
    opts = opts || {};
    /* 2026-05-09 (Claude R6 MEDIUM): the API was previously a
       complete bypass for the identity-binding check. A page-
       level script could call
       attestUserGesture({trusted:true, type:'user'}) and the
       next invoke would inherit attested=true with NO identity
       binding to a real isTrusted gesture path. The override
       was specified as testing-only (sec 15.10) but the runtime
       accepted arbitrary opts.type values.

       Fix: opts.type may ONLY be 'script' or 'agent'. Attempts
       to claim 'user' (the only type that maps to source.type=
       'user' downstream) are blocked at runtime AND emit a
       finding code script_override_claims_user that
       validate_global_v2() reports. The override remains
       useful for headless test fixtures (testing-only as the
       spec always said) but cannot launder a script-origin
       action as a user-origin one. */
    var requestedType = (typeof opts.type === 'string' && opts.type) ? opts.type : 'script';
    if (requestedType === 'user') {
      _validatorFindings.push({
        code: 'script_override_claims_user',
        severity: 'error',
        timestamp: Date.now(),
        note: 'attestUserGesture rejected opts.type="user" -- only script/agent permitted'
      });
      console.warn('[NAC v2] attestUserGesture: opts.type="user" rejected; '
        + 'forcing type="script". Identity-binding bypass blocked.');
      requestedType = 'script';
    }
    if (requestedType !== 'script' && requestedType !== 'agent') {
      throw new Error('[NAC v2] attestUserGesture: opts.type must be '
        + '"script" or "agent" (got "' + requestedType + '")');
    }
    _scriptOverride = {
      trusted: !!opts.trusted,
      type:    requestedType,
      ts:      Date.now()
    };
  }

  /* ------------------------------------------------------------- perf tolerance */

  /* v2.0-rc2 (Grok+Mistral T6-F1): default throttle bumped 50ms ->
     100ms after concurrent reviewer feedback that 50ms drops
     events on bursty UIs. set_perf_tolerance({mutation_throttle_ms,
     describe_target_ms, etc}) lets hosts tune for their workload. */
  var _perfTolerance = {
    mutation_throttle_ms: 100,        /* was 50 in rc1 */
    describe_target_ms: 50,            /* was 30 in rc1 (Mistral T6-F2) */
    describe_hard_fail_ms: 150,        /* was 100 in rc1 */
    adopt_hard_fail_ms: 20,            /* was 15 in rc1 */
    autoregister_hard_fail_ms: 5,
    /* v2.0-rc4 (Claude T8.1 middle ground): hard-fail RATE
       tightened from 5%/5s (rc2/rc3) to 2%/5s (rc4). Same
       window width, tighter rate. Rationale: 5% over 5s = ~1
       hitched describe() per 20s on Snapdragon 6 Gen 1 = breaks
       SR reading flow; 1%/10s window too long for bursty
       stalls. 2%/5s captures sustained AND bursty correctly.
       Tunable for hosts that need looser thresholds. */
    perf_budget_fail_rate_pct: 2,      /* was implicit 5% in rc3 */
    perf_budget_window_ms: 5000        /* unchanged */
  };

  function set_perf_tolerance(opts) {
    if (!opts || typeof opts !== 'object') {
      throw new Error('[NAC v2] set_perf_tolerance expects object');
    }
    Object.keys(opts).forEach(function (k) {
      if (k in _perfTolerance && typeof opts[k] === 'number' && opts[k] > 0) {
        _perfTolerance[k] = opts[k];
      }
    });
  }
  function get_perf_tolerance() { return Object.assign({}, _perfTolerance); }

  /* ------------------------------------------------------------- validation tolerance */

  /* v2.0-rc2 (Grok T5-F1 + Mistral T5-F2): NAC-3 default i18n
     severity bumped from 'error' to 'warn' after concurrent
     reviewer feedback that mandatory at NAC-3 blocks incremental
     SaaS rollouts. Hosts that want strict 'error' behaviour opt
     in via set_validation_tolerance({i18n_strict: 'error'}). */
  var _validationTolerance = {
    i18n_strict: 'warn',  /* 'warn' (default) | 'error' | 'silent' */
    /* v2.0-rc4 (Mistral T7-F1): iframe_strict opt-in turns on
       NAC-3 fail-closed for bridgeIframe. Default 'warn' = rc3
       fail-open behaviour preserved for NAC-1/NAC-2. */
    iframe_strict: 'warn',  /* 'warn' (default) | 'error' */
    /* v2.0-rc4 (Claude T8.2): autoderived_action signals when
       autoRegister inferred the action without an explicit
       data-nac-action attribute. Default 'warn'; opt-in 'error'
       for regulated-environment audit pipelines. */
    autoderived_action: 'warn'  /* 'warn' (default) | 'error' | 'silent' */
  };

  function set_validation_tolerance(opts) {
    if (!opts || typeof opts !== 'object') {
      throw new Error('[NAC v2] set_validation_tolerance expects object');
    }
    if (opts.i18n_strict && ['warn', 'error', 'silent'].indexOf(opts.i18n_strict) >= 0) {
      _validationTolerance.i18n_strict = opts.i18n_strict;
    }
    if (opts.iframe_strict && ['warn', 'error'].indexOf(opts.iframe_strict) >= 0) {
      _validationTolerance.iframe_strict = opts.iframe_strict;
    }
    if (opts.autoderived_action && ['warn', 'error', 'silent'].indexOf(opts.autoderived_action) >= 0) {
      _validationTolerance.autoderived_action = opts.autoderived_action;
    }
  }
  function get_validation_tolerance() { return Object.assign({}, _validationTolerance); }

  /* ------------------------------------------------------------- scope */

  var _scopes = Object.create(null);

  function _validateLeaf(slug) {
    if (!slug || typeof slug !== 'string') {
      throw new Error('[NAC v2] slug required');
    }
    /* v2.0-rc3 (DeepSeek T3.1): empty string passes the typeof
       check + indexOf check, then produces malformed slugs. Reject
       it explicitly. */
    if (slug.length === 0) {
      throw new Error('[NAC v2] slug_invalid: empty string');
    }
    if (slug.indexOf(SEPARATOR) >= 0) {
      throw new Error('[NAC v2] slug_invalid: contains "' + SEPARATOR + '"');
    }
  }

  function scope(spec) {
    spec = spec || {};
    _validateLeaf(spec.slug);
    return _makeSubScope(spec.slug, [spec.slug], spec);
  }

  function _makeSubScope(currentSlug, chain, spec) {
    var depth = chain.length;
    if (depth > MAX_DEPTH) {
      throw new Error('[NAC v2] depth_exceeded: ' + chain.join(SEPARATOR));
    }
    if (depth === WARN_DEPTH + 1) {
      document.dispatchEvent(new CustomEvent('nac:depth_warn', {
        detail: { path: chain.join(SEPARATOR), depth: depth }, bubbles: true
      }));
    }

    var node = {
      id:    chain.join(SEPARATOR),
      depth: depth,
      label_i18n: spec ? spec.label_i18n || null : null,
    };
    /* v2.0-rc3 (Claude T3.1): track intermediate nodes that carry
       a label_i18n so describe_v2 can expose them. Leaf nodes go
       through register() and end up in _scopes; intermediate
       (non-leaf) nodes need a separate index. */
    if (node.label_i18n) {
      _intermediateScopes[node.id] = {
        depth: depth,
        label_i18n: node.label_i18n
      };
    }
    Object.assign(node, {

      scope: function (childSpec) {
        _validateLeaf(childSpec.slug);
        var childChain = chain.concat([childSpec.slug]);
        return _makeSubScope(childSpec.slug, childChain, childSpec);
      },

      register: function (regSpec) {
        _validateLeaf(regSpec.slug);
        var fullSlug = chain.concat([regSpec.slug]).join(SEPARATOR);

        var entry = {
          slug:        fullSlug,
          intent:      regSpec.intent || 'navigate',
          source:      regSpec.source || 'human',
          label_i18n:  regSpec.label_i18n || null,
          desc_i18n:   regSpec.desc_i18n || null,
          a11y_hint:   regSpec.a11y_hint || null,
          irreversible:!!regSpec.irreversible,
          role:        regSpec.role || null,
          element:     regSpec.element || null,
          handler:     typeof regSpec.handler === 'function' ? regSpec.handler : null,
          autoderived: false,
          parent_chain: chain.slice(),
          registered_at: Date.now()
        };

        /* Idempotent: re-register with same slug + same element silently
           updates; re-register with same slug + different element warns. */
        var prior = _scopes[fullSlug];
        if (prior) {
          if (prior.element === entry.element) {
            _scopes[fullSlug] = entry;
          } else {
            document.dispatchEvent(new CustomEvent('nac:duplicate_warn', {
              detail: { slug: fullSlug, prior: prior, next: entry }, bubbles: true
            }));
            _scopes[fullSlug] = entry; /* last-wins */
          }
        } else {
          _scopes[fullSlug] = entry;
        }

        if (entry.element) {
          entry.element.setAttribute('data-nac-id', fullSlug);
          entry.element.setAttribute('data-nac-parent', chain.join(' '));
          if (entry.role) entry.element.setAttribute('role', entry.role);
          if (entry.label_i18n) {
            var lbl = t.bind(null);
            var labelText = (function () {
              if (entry.label_i18n[_currentLocale]) return entry.label_i18n[_currentLocale];
              if (entry.label_i18n.es) return entry.label_i18n.es;
              if (entry.label_i18n.en) return entry.label_i18n.en;
              return fullSlug;
            })();
            if (!entry.element.getAttribute('aria-label')) {
              entry.element.setAttribute('aria-label', labelText);
            }
          }
          if (entry.irreversible) {
            entry.element.setAttribute('data-nac-irreversible', '1');
          }
        }

        return {
          id: fullSlug,
          invoke: function (params) { return _invoke(fullSlug, params); }
        };
      }
    });
    return node;
  }

  function _invoke(slug, params) {
    var entry = _scopes[slug];
    if (!entry) return Promise.reject(new Error('unknown_slug:' + slug));
    var src = (params && params.source) || entry.source || 'human';

    var attested;
    if (_scriptOverride && Date.now() - _scriptOverride.ts < GESTURE_FRESH_MS) {
      attested = _scriptOverride.trusted;
      _scriptOverride = null;
    } else {
      /* v2.0-rc3 (Claude T4-F1 BLOCKER fix): pass entry.element so
         _readGestureAttested can verify identity, not just freshness.
         Closes the gesture-buffer leak. */
      attested = _readGestureAttested(entry.element);
    }

    /* v2.0-rc3 (Claude T4-F3): os_level pass-through. When source is
       'agent' AND host opts in (e.g. for Computer Use telemetry),
       params.os_level is propagated into provenance for audit. */
    var osLevel = (params && params.os_level === true) ? true : null;

    var prov = {
      slug:    slug,
      intent:  entry.intent,
      source:  src,
      type:    src,
      user_gesture_attested: attested,
      ts:      Date.now(),
      params:  params || null
    };
    if (osLevel === true) prov.os_level = true;

    /* Agent + irreversible -> decline path */
    if (src === 'agent' && entry.irreversible) {
      var hint = entry.a11y_hint
        ? (entry.a11y_hint[_currentLocale] || entry.a11y_hint.es)
        : null;
      document.dispatchEvent(new CustomEvent('nac:command_rejected', {
        detail: { slug: slug, reason: 'agent_declined_irreversible', hint: hint, ts: Date.now() },
        bubbles: true
      }));
      return Promise.reject(new Error('agent_declined_irreversible'));
    }

    /* Sign if we can (agent must) */
    var signPromise;
    if (typeof NAC.sign_provenance === 'function' && _provenanceSecrets[0]) {
      signPromise = NAC.sign_provenance(prov, _provenanceSecrets[0]);
    } else {
      signPromise = Promise.resolve(null);
    }

    return signPromise.then(function (sig) {
      if (sig) prov.signature = sig;
      var detail = { provenance: prov, signature: sig, version: 'v2.0' };
      document.dispatchEvent(new CustomEvent('nac:command_pending', {
        detail: detail, bubbles: true
      }));
      var run = entry.handler
        ? Promise.resolve().then(function () { return entry.handler(params || {}, detail); })
        : Promise.resolve(null);
      return run.then(function (result) {
        document.dispatchEvent(new CustomEvent('nac:command_done', {
          detail: Object.assign({}, detail, { result: result }), bubbles: true
        }));
        return result;
      }, function (err) {
        document.dispatchEvent(new CustomEvent('nac:command_failed', {
          detail: Object.assign({}, detail, { error: String(err) }), bubbles: true
        }));
        throw err;
      });
    });
  }

  /* ------------------------------------------------------------- autoRegister */

  function _findScopeAncestor(el) {
    var anc = el.parentElement;
    while (anc) {
      if (anc.hasAttribute && anc.hasAttribute('data-nac-scope')) {
        return anc.getAttribute('data-nac-scope');
      }
      anc = anc.parentElement;
    }
    return null;
  }

  function _deriveLeafSlug(el) {
    if (el.id) return el.id;
    if (el.dataset && el.dataset.nacAction) return el.dataset.nacAction;
    /* v2.0-rc3 (Claude T3.2): the rc1 fallback hashed only
       el.outerHTML.slice(0,100) which produces identical hashes for
       400 cards rendered from the same template (template prefixes
       are byte-identical). The fix mixes in: tag name + textContent
       (more discriminating) + position-in-parent (guaranteed
       unique). Collisions still possible when two truly identical
       elements exist; idempotent register handles those by
       last-wins-same-element. */
    var src = '';
    src += el.tagName || '';
    src += '|';
    src += (el.textContent || '').trim().slice(0, 60);
    src += '|';
    if (el.parentNode) {
      try {
        var siblings = el.parentNode.children;
        for (var s = 0; s < siblings.length; s++) {
          if (siblings[s] === el) { src += '@' + s; break; }
        }
      } catch (_) {}
    }
    src += '|';
    src += (el.outerHTML || '').slice(0, 80);
    var h = 0;
    for (var i = 0; i < src.length; i++) {
      h = ((h << 5) - h) + src.charCodeAt(i);
      h |= 0;
    }
    return 'auto_' + (Math.abs(h)).toString(36);
  }

  function _deriveRole(el) {
    var tag = el.tagName.toLowerCase();
    var attrRole = el.getAttribute('role');
    if (attrRole) return attrRole;
    if (tag === 'button') return 'button';
    if (tag === 'a' && el.hasAttribute('href')) return 'link';
    if (tag === 'input') {
      var t = el.getAttribute('type') || 'text';
      if (t === 'checkbox' || t === 'radio') return 'toggle';
      return 'field';
    }
    if (tag === 'textarea') return 'field';
    if (tag === 'select') return 'select';
    return 'interactive';
  }

  function _deriveLabel(el) {
    var aria = el.getAttribute('aria-label');
    if (aria) return aria;
    return (el.textContent || '').trim().slice(0, 200);
  }

  function autoRegister(el, opts) {
    opts = opts || {};
    if (!el) throw new Error('[NAC v2] autoRegister requires element');
    var leaf = _deriveLeafSlug(el);
    var parentSlug = opts.inheritScope !== false ? _findScopeAncestor(el) : null;
    /* v2.0-rc3 (DeepSeek T3.2): warn on orphan slugs (no parent
       scope ancestor found). Easy to happen on pages with multiple
       dynamic regions; without a warn the slug ends up huerfano
       silently. */
    if (opts.inheritScope !== false && !parentSlug) {
      try {
        document.dispatchEvent(new CustomEvent('nac:autoregister_orphan_warn', {
          detail: { leaf: leaf, element: el }, bubbles: true
        }));
      } catch (_) {}
    }
    var fullSlug = parentSlug ? (parentSlug + SEPARATOR + leaf) : leaf;

    /* i18n strict check */
    var i18nKey = el.getAttribute('data-i18n-key');
    var labelI18n = null;
    var autoderived = false;
    if (i18nKey && _catalog[i18nKey]) {
      labelI18n = _catalog[i18nKey];
    } else if (i18nKey) {
      /* Key declared but catalog missing the entry */
      if (opts.i18n_strict !== false) {
        document.dispatchEvent(new CustomEvent('nac:i18n_skipped', {
          detail: { slug: fullSlug, key: i18nKey, reason: 'catalog_missing' },
          bubbles: true
        }));
        return null;
      }
    } else {
      /* No data-i18n-key. In strict (default) we skip; in permissive
         we mono-locale fallback */
      if (opts.i18n_strict !== false && opts.i18n_strict !== 'permissive') {
        document.dispatchEvent(new CustomEvent('nac:i18n_skipped', {
          detail: { slug: fullSlug, reason: 'no_data_i18n_key' },
          bubbles: true
        }));
        return null;
      }
      var derivedLabel = _deriveLabel(el);
      labelI18n = {};
      labelI18n[_currentLocale] = derivedLabel;
      autoderived = true;
    }

    var role = (opts.derive && opts.derive.role === 'auto')
      ? _deriveRole(el)
      : (opts.derive && opts.derive.role) || _deriveRole(el);

    var entry = {
      slug:        fullSlug,
      intent:      'navigate',
      source:      'human',
      label_i18n:  labelI18n,
      role:        role,
      element:     el,
      autoderived: autoderived,
      registered_at: Date.now()
    };
    _scopes[fullSlug] = entry;
    el.setAttribute('data-nac-id', fullSlug);
    if (parentSlug) {
      el.setAttribute('data-nac-parent', parentSlug.split(SEPARATOR).join(' '));
    }
    if (role && !el.getAttribute('role')) el.setAttribute('role', role);
    if (labelI18n && !el.getAttribute('aria-label')) {
      var lab = labelI18n[_currentLocale] || labelI18n.es || labelI18n.en || fullSlug;
      el.setAttribute('aria-label', lab);
    }
    return entry;
  }

  /* MutationObserver-based watch */
  var _watchObservers = [];
  autoRegister.watch = function (containerEl, opts) {
    opts = opts || {};
    /* v2.0-rc2: default throttle pulled from _perfTolerance (100ms),
       caller may still override per-watch via opts.throttleMs. */
    var throttleMs = opts.throttleMs || _perfTolerance.mutation_throttle_ms;
    var pending = false;
    var queue = [];

    /* v2.0-rc3 (Claude T6-F1): chunk batches > 50 elements via
       requestIdleCallback (or setTimeout fallback) to stay under
       the cumulative-batch perf budget. Per-element cost stays the
       same; main thread is yielded between sub-batches so the
       page stays responsive. */
    var CHUNK_SIZE = 50;
    function _yieldThen(fn) {
      if (typeof window.requestIdleCallback === 'function') {
        window.requestIdleCallback(fn, { timeout: 100 });
      } else {
        setTimeout(fn, 0);
      }
    }
    function processOne(entry) {
      if (entry.added) {
        if (entry.el.hasAttribute && entry.el.hasAttribute('data-nac-action')) {
          try { autoRegister(entry.el, opts); } catch (_) {}
        }
        /* Descend into added subtree */
        if (entry.el.querySelectorAll) {
          entry.el.querySelectorAll('[data-nac-action]').forEach(function (x) {
            try { autoRegister(x, opts); } catch (_) {}
          });
        }
      } else {
        /* Removed: clean manifest */
        if (entry.el.getAttribute) {
          var slug = entry.el.getAttribute('data-nac-id');
          if (slug && _scopes[slug]) delete _scopes[slug];
        }
      }
    }
    function flush() {
      var batch = queue.splice(0);
      pending = false;
      if (batch.length <= CHUNK_SIZE) {
        batch.forEach(processOne);
        return;
      }
      /* Chunked path: yield between sub-batches. */
      var idx = 0;
      function step() {
        var end = Math.min(idx + CHUNK_SIZE, batch.length);
        for (; idx < end; idx++) processOne(batch[idx]);
        if (idx < batch.length) _yieldThen(step);
      }
      step();
    }

    var obs = new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType === 1) queue.push({ added: true, el: n });
        });
        m.removedNodes.forEach(function (n) {
          if (n.nodeType === 1) queue.push({ added: false, el: n });
        });
      });
      if (!pending) {
        pending = true;
        setTimeout(flush, throttleMs);
      }
    });
    obs.observe(containerEl, { childList: true, subtree: true });
    _watchObservers.push(obs);
    /* Also process existing descendants */
    containerEl.querySelectorAll('[data-nac-action]').forEach(function (el) {
      try { autoRegister(el, opts); } catch (_) {}
    });
    return obs;
  };

  /* ------------------------------------------------------------- adopt */

  function adopt(rule) {
    if (!rule || !rule.selector) throw new Error('[NAC v2] adopt requires selector');
    rule.parent = rule.parent || null;
    rule.observe = rule.observe !== false;

    function process(el) {
      try {
        var leaf = (rule.derive && rule.derive.slug)
          ? rule.derive.slug(el)
          : _deriveLeafSlug(el);
        var fullSlug = rule.parent
          ? (rule.parent + SEPARATOR + leaf)
          : leaf;
        var role = (rule.derive && rule.derive.role)
          ? rule.derive.role(el)
          : _deriveRole(el);
        var labelI18n = (rule.derive && rule.derive.label_i18n)
          ? rule.derive.label_i18n(el)
          : (function () { var o={}; o[_currentLocale]=_deriveLabel(el); return o; })();
        var irreversible = (rule.derive && rule.derive.irreversible)
          ? rule.derive.irreversible(el)
          : false;
        var entry = {
          slug:         fullSlug,
          intent:       (rule.derive && rule.derive.intent && rule.derive.intent(el)) || 'navigate',
          source:       'human',
          label_i18n:   labelI18n,
          role:         role,
          element:      el,
          irreversible: irreversible,
          adopted:      true,
          registered_at: Date.now()
        };
        _scopes[fullSlug] = entry;
        el.setAttribute('data-nac-id', fullSlug);
        if (role && !el.getAttribute('role')) el.setAttribute('role', role);
        if (labelI18n && !el.getAttribute('aria-label')) {
          var lab = labelI18n[_currentLocale] || labelI18n.es || labelI18n.en || fullSlug;
          el.setAttribute('aria-label', lab);
        }
        if (irreversible) el.setAttribute('data-nac-irreversible', '1');
      } catch (e) {
        document.dispatchEvent(new CustomEvent('nac:adopt_failed', {
          detail: { rule: rule.selector, error: String(e) }, bubbles: true
        }));
      }
    }

    /* v2.0-rc3 (Claude T3.3): scope the observer to a host-supplied
       containerEl (smaller subtree) when provided, instead of always
       attaching to document.body. Reduces mutation-observer cost
       on DOM-heavy pages with N rules. */
    var scopedRoot = (rule.containerEl && rule.containerEl.nodeType === 1)
      ? rule.containerEl
      : document.body;

    /* Initial pass: query within the scoped root, not always document. */
    scopedRoot.querySelectorAll(rule.selector).forEach(process);

    /* Observer */
    if (rule.observe) {
      var obs = new MutationObserver(function (muts) {
        muts.forEach(function (m) {
          m.addedNodes.forEach(function (n) {
            if (n.nodeType !== 1) return;
            if (n.matches && n.matches(rule.selector)) process(n);
            if (n.querySelectorAll) {
              n.querySelectorAll(rule.selector).forEach(process);
            }
          });
        });
      });
      obs.observe(scopedRoot, { childList: true, subtree: true });
    }
    return rule;
  }

  /* ------------------------------------------------------------- bridges */

  /* v2.0-rc3 (DeepSeek T3.4): dedup bridged hosts via WeakSet so
     repeat calls on the same host do not produce duplicate
     registrations. */
  var _bridgedShadowHosts = new WeakSet();

  function bridgeShadowRoot(host, depth) {
    depth = depth || 0;
    if (depth > 6) {
      document.dispatchEvent(new CustomEvent('nac:shadow_depth_exceeded', {
        detail: { host: host }, bubbles: true
      }));
      return;
    }
    if (!host || !host.shadowRoot) {
      document.dispatchEvent(new CustomEvent('nac:shadow_blocked', {
        detail: { host: host, reason: 'closed_or_missing' }, bubbles: true
      }));
      return;
    }
    /* v2.0-rc3: skip if already bridged. */
    if (_bridgedShadowHosts.has(host)) return;
    _bridgedShadowHosts.add(host);
    /* Walk shadow root: any [data-nac-id] becomes operable; any
       [data-nac-action] auto-registers */
    var sr = host.shadowRoot;
    sr.querySelectorAll('[data-nac-action]').forEach(function (el) {
      try { autoRegister(el, { i18n_strict: 'permissive' }); } catch (_) {}
    });
    /* Recurse */
    sr.querySelectorAll('*').forEach(function (el) {
      if (el.shadowRoot) bridgeShadowRoot(el, depth + 1);
    });
  }

  function bridgeIframe(iframeEl, opts) {
    opts = opts || {};
    var ns = opts.postMessageNamespace || 'nac.iframe.v1';
    var trusted = opts.trusted_origins || [];
    var timeout = opts.timeout_ms || 5000;
    var iframeId = iframeEl.id || 'iframe_' + Math.random().toString(36).slice(2,8);
    /* v2.0-rc4 (Mistral T7-F1 + Claude T4-F2.1): NAC-3 enforcement
       opt-in. When opts.nac_level === 3 (or auto-detected from
       _validationTolerance.iframe_strict === 'error'), runtime
       enforces fail-closed on missing secret and verifies
       signatures on BOTH handshake_ack AND describe_result. */
    var nacLevel = opts.nac_level
      || (_validationTolerance.iframe_strict === 'error' ? 3 : 1);

    /* v2.0-rc3 (Claude T4-F2): the spec mandates HMAC chain on
       cross-origin agent-source events. We additionally require
       that handshake_ack and describe_result messages carry
       signature fields verifiable against our registered HMAC
       secret. Without this, a compromised trusted-origin (XSS in
       a vendor's CDN) can ride on the allowlist trust to inject
       manifest entries unchecked.
       v2.0-rc4: extended to describe_result + NAC-3 fail-closed. */
    return new Promise(function (resolve, reject) {
      var done = false;
      function listener(ev) {
        if (trusted.length && trusted.indexOf(ev.origin) < 0) {
          document.dispatchEvent(new CustomEvent('nac:iframe_untrusted', {
            detail: { origin: ev.origin }, bubbles: true
          }));
          return;
        }
        var d = ev.data;
        if (!d || d.ns !== ns) return;
        if (d.cmd === 'handshake_ack') {
          if (done) return;
          /* v2.0-rc4 (Mistral T7-F1): NAC-3 fail-closed. If no
             secret registered AND we are at NAC-3, reject the
             handshake. NAC-1/NAC-2 path keeps fail-open with
             warn (rc3 behaviour). */
          if (nacLevel >= 3 && !_hasSecrets()) {
            done = true;
            window.removeEventListener('message', listener);
            document.dispatchEvent(new CustomEvent('nac:iframe_no_secret_at_nac3', {
              detail: { iframeId: iframeId }, bubbles: true
            }));
            reject(new Error('iframe_no_secret_at_nac3'));
            return;
          }
          /* v2.0-rc3: verify signature on handshake_ack if HMAC
             secret registered. */
          if (_hasSecrets() && d.signature) {
            _verify_with_registered({ ns: d.ns, cmd: d.cmd, version: d.version, signature: d.signature })
              .then(function (ok) {
                if (!ok) {
                  done = true;
                  window.removeEventListener('message', listener);
                  document.dispatchEvent(new CustomEvent('nac:iframe_signature_invalid', {
                    detail: { iframeId: iframeId, message: 'handshake_ack' }, bubbles: true
                  }));
                  reject(new Error('iframe_signature_invalid'));
                  return;
                }
                _continueHandshakeAck();
              });
            return;
          }
          if (_hasSecrets() && !d.signature) {
            /* Secret registered but iframe did not sign -> at
               NAC-3 fail-closed; at lower levels emit warn and
               continue. */
            if (nacLevel >= 3) {
              done = true;
              window.removeEventListener('message', listener);
              document.dispatchEvent(new CustomEvent('nac:iframe_signature_missing', {
                detail: { iframeId: iframeId, message: 'handshake_ack' }, bubbles: true
              }));
              reject(new Error('iframe_signature_missing'));
              return;
            }
            document.dispatchEvent(new CustomEvent('nac:iframe_signature_missing', {
              detail: { iframeId: iframeId, message: 'handshake_ack' }, bubbles: true
            }));
          }
          _continueHandshakeAck();

          function _continueHandshakeAck() {
            done = true;
            if (d.version && d.version.split('.')[0] !== '2') {
              document.dispatchEvent(new CustomEvent('nac:iframe_version_mismatch', {
                detail: { theirs: d.version, ours: '2.0' }, bubbles: true
              }));
              reject(new Error('iframe_version_mismatch'));
              return;
            }
            window.removeEventListener('message', listener);
            resolve({ iframeId: iframeId, version: d.version,
              signed: !!d.signature, nac_level: nacLevel });
          }
        }
        /* v2.0-rc4 (Mistral T4-F2.1): describe_result messages
           ALSO must be HMAC-verified at NAC-3. The handshake
           promise has already resolved by this point; this
           listener stays installed for follow-up describe()
           pulls. We emit events but cannot reject the promise
           (already settled). */
        if (d.cmd === 'describe_result') {
          if (nacLevel >= 3 && !_hasSecrets()) {
            document.dispatchEvent(new CustomEvent('nac:iframe_no_secret_at_nac3', {
              detail: { iframeId: iframeId, message: 'describe_result' },
              bubbles: true
            }));
            return;
          }
          if (_hasSecrets() && d.signature) {
            _verify_with_registered({
              ns: d.ns, cmd: d.cmd, manifest: d.manifest, signature: d.signature
            }).then(function (ok) {
              if (!ok) {
                document.dispatchEvent(new CustomEvent('nac:iframe_signature_invalid', {
                  detail: { iframeId: iframeId, message: 'describe_result' },
                  bubbles: true
                }));
                return;
              }
              /* Verified: forward manifest to whoever subscribes. */
              document.dispatchEvent(new CustomEvent('nac:iframe_describe_received', {
                detail: { iframeId: iframeId, manifest: d.manifest }, bubbles: true
              }));
            });
            return;
          }
          if (_hasSecrets() && !d.signature) {
            document.dispatchEvent(new CustomEvent('nac:iframe_signature_missing', {
              detail: { iframeId: iframeId, message: 'describe_result' }, bubbles: true
            }));
            if (nacLevel >= 3) return; /* drop unsigned at NAC-3 */
          }
          /* NAC-1/NAC-2 + no secret: forward manifest as-is. */
          document.dispatchEvent(new CustomEvent('nac:iframe_describe_received', {
            detail: { iframeId: iframeId, manifest: d.manifest }, bubbles: true
          }));
        }
      }
      window.addEventListener('message', listener);
      iframeEl.contentWindow.postMessage(
        { ns: ns, cmd: 'handshake', version: '2.0' },
        trusted.length ? trusted[0] : '*'
      );
      setTimeout(function () {
        if (!done) {
          done = true;
          window.removeEventListener('message', listener);
          document.dispatchEvent(new CustomEvent('nac:iframe_handshake_timeout', {
            detail: { iframeId: iframeId }, bubbles: true
          }));
          reject(new Error('iframe_handshake_timeout'));
        }
      }, timeout);
    });
  }

  /* ------------------------------------------------------------- virtual */

  var _virtuals = [];
  function declareVirtual(spec) {
    if (!spec || !spec.slug_pattern || typeof spec.resolver !== 'function') {
      throw new Error('[NAC v2] declareVirtual requires {slug_pattern, count, resolver}');
    }
    _virtuals.push(spec);
    return spec;
  }
  /* v2.0-rc3 (Claude T3.6 / DeepSeek T3.6): escape regex
     metacharacters in the static parts of the pattern before
     substituting {i}. Without this, `pipeline.runs.row.{i}` would
     match `pipelineXrunsXrowX7` (because `.` is a regex wildcard);
     a malicious URL or DOM-injected slug could hit arbitrary
     pattern. */
  function _escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }
  function _resolveVirtual(slug) {
    for (var i = 0; i < _virtuals.length; i++) {
      var v = _virtuals[i];
      /* Split on {i} so we can escape the static parts. */
      var parts = v.slug_pattern.split('{i}');
      var pat = parts.map(_escapeRegex).join('(\\d+)');
      var m = slug.match(new RegExp('^' + pat + '$'));
      if (m) {
        var idx = parseInt(m[1], 10);
        var count = typeof v.count === 'function' ? v.count() : v.count;
        if (idx >= 0 && idx < count) {
          var t0 = performance.now();
          var entry = v.resolver(idx);
          var elapsed = performance.now() - t0;
          if (elapsed > 50) {
            document.dispatchEvent(new CustomEvent('nac:virtual_resolver_slow', {
              detail: { slug: slug, elapsed_ms: elapsed }, bubbles: true
            }));
          }
          return entry;
        }
      }
    }
    return null;
  }

  /* ------------------------------------------------------------- ephemeral */

  var _ephemeralRing = [];
  var _ephemeralOpts = null;
  function captureEphemeral(opts) {
    opts = opts || {};
    _ephemeralOpts = {
      duration_ms: opts.duration_ms || 3000,
      ring_size:   opts.ring_size   || 100,
      on_capture:  opts.on_capture  || null
    };
    var liveTimers = new Map();
    var obs = new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType === 1 && n.getAttribute && n.getAttribute('data-nac-id')) {
            var slug = n.getAttribute('data-nac-id');
            liveTimers.set(slug, { added_at: Date.now(), node: n });
          }
        });
        m.removedNodes.forEach(function (n) {
          if (n.nodeType === 1 && n.getAttribute && n.getAttribute('data-nac-id')) {
            var slug = n.getAttribute('data-nac-id');
            var live = liveTimers.get(slug);
            if (live && (Date.now() - live.added_at) <= _ephemeralOpts.duration_ms) {
              var capture = {
                slug: slug,
                role: n.getAttribute('role'),
                label: n.textContent.trim().slice(0, 200),
                added_at: live.added_at,
                removed_at: Date.now(),
                duration_ms: Date.now() - live.added_at
              };
              _ephemeralRing.push(capture);
              if (_ephemeralRing.length > _ephemeralOpts.ring_size) {
                _ephemeralRing.shift();
              }
              if (_ephemeralOpts.on_capture) _ephemeralOpts.on_capture(capture);
            }
            liveTimers.delete(slug);
          }
        });
      });
    });
    obs.observe(document.body, { childList: true, subtree: true });
    return obs;
  }

  /* ------------------------------------------------------------- tenant */

  var _tenantPrefix = null;
  function setTenantPrefix(slug) {
    if (_tenantPrefix !== null) {
      throw new Error('[NAC v2] tenant_prefix_locked: already set to ' + _tenantPrefix);
    }
    _validateLeaf(slug);
    _tenantPrefix = slug;
  }
  function getTenantPrefix() { return _tenantPrefix; }

  /* ------------------------------------------------------------- describe v2 */

  /* Augment v1.9's describe() with v2 additions when called.
     We don't replace the v1.9 function; we expose a new
     `describe_v2()` and decorate the v1 result. */
  /* v2.0-rc3 (Claude T3.1): track intermediate scope nodes so
     describe_v2 can expose their label_i18n. Without this,
     a catalog declares `shell.topbar` label but no consumer
     reads it because the intermediate node has no element.

     v2.0-rc4 (Mistral T7-F2): the index grows monotonically with
     unique scope paths created. Realistic SPA case is bounded
     (~6 levels x ~few sections = O(N small)) but an SPA that
     dynamically creates and discards scopes can leak. WeakMap
     was rejected because keys are strings (paths), not objects.
     Solution: NAC.gcIntermediateScopes(activePathSet) lets the
     host prune entries no longer in use. Default behaviour:
     no automatic GC; documented growth pattern. */
  var _intermediateScopes = Object.create(null);

  /* v2.0-rc5 (spec sec 17): optional sitemap primitive. Hosts with
     50+ logical screens declare the full path catalog so the
     intermediary can plan navigation to slugs not currently in
     the visible tree. Authority separation is CRITICAL: the
     sitemap is navigational metadata only, never a source of
     can-operate truth. The visible tree (_scopes / v1 manifest)
     remains the only authority for dispatch. */
  var _sitemap = null;        /* { paths: [...] } or null */

  function declareSitemap(spec) {
    if (spec === null || typeof spec === 'undefined') {
      _sitemap = null;
      return;
    }
    if (typeof spec !== 'object' || !Array.isArray(spec.paths)) {
      throw new Error('[NAC v2] declareSitemap: spec must be { paths: [...] }');
    }
    var seenSlugs = Object.create(null);
    var clean = [];
    for (var i = 0; i < spec.paths.length; i++) {
      var p = spec.paths[i];
      if (!p || typeof p.slug !== 'string' || p.slug === '') {
        throw new Error('[NAC v2] declareSitemap: paths[' + i + '].slug required');
      }
      if (seenSlugs[p.slug]) {
        throw new Error('[NAC v2] declareSitemap: duplicate slug "' + p.slug + '"');
      }
      seenSlugs[p.slug] = true;
      var entry = { slug: p.slug };
      if (p.label_i18n && typeof p.label_i18n === 'object') {
        entry.label_i18n = p.label_i18n;
      }
      if (Array.isArray(p.affordance_to_navigate)) {
        entry.affordance_to_navigate = p.affordance_to_navigate.slice();
      }
      if (Array.isArray(p.requires_permission)) {
        entry.requires_permission = p.requires_permission.slice();
      }
      if (Array.isArray(p.tags)) {
        entry.tags = p.tags.slice();
      }
      clean.push(entry);
    }
    _sitemap = { paths: clean };
  }

  function getSitemap() {
    if (!_sitemap) return null;
    /* return a defensive shallow copy so callers cannot mutate
       internal state */
    return { paths: _sitemap.paths.slice() };
  }

  /* Public GC API (rc4): the host passes a Set or array of path
     strings that are still considered "active". Any entry in the
     index whose path is NOT in that set gets removed. */
  function gcIntermediateScopes(activePaths) {
    if (!activePaths) {
      /* No-arg form: clear ALL intermediate scopes. Use only when
         tearing down the SPA / navigating to a totally new shell. */
      _intermediateScopes = Object.create(null);
      return 0;
    }
    var active = (typeof activePaths.has === 'function')
      ? activePaths
      : new Set(activePaths);
    var removed = 0;
    Object.keys(_intermediateScopes).forEach(function (k) {
      if (!active.has(k)) {
        delete _intermediateScopes[k];
        removed++;
      }
    });
    return removed;
  }

  function describe_v2() {
    var v1 = (typeof NAC.describe === 'function') ? NAC.describe() : { plugins: [] };
    var scopeEntries = Object.keys(_scopes).map(function (k) {
      var e = _scopes[k];
      return {
        slug: e.slug,
        role: e.role,
        intent: e.intent,
        autoderived: e.autoderived || false,
        adopted: e.adopted || false,
        irreversible: e.irreversible || false,
        parent_chain: e.parent_chain || null,
        has_element: !!e.element
      };
    });
    var intermediateScopes = Object.keys(_intermediateScopes).map(function (k) {
      return {
        slug: k,
        depth: _intermediateScopes[k].depth,
        label_i18n: _intermediateScopes[k].label_i18n,
        is_intermediate: true
      };
    });
    var virtual_summary = _virtuals.map(function (v) {
      var count = typeof v.count === 'function' ? v.count() : v.count;
      return { slug_pattern: v.slug_pattern, count: count };
    });
    /* v2.1 sec 18: surface every registered data-table so the
       chatbot intermediary, RPA bot and test runner all see the
       same snapshot. data_tables is [] when no host has called
       registerDataTable(). */
    var dataTables = (typeof NAC.__v2_dtSummariseAll === 'function')
      ? NAC.__v2_dtSummariseAll()
      : [];
    return {
      nac_version: '2.1.0-rc1',
      timestamp: Date.now(),
      tenant_prefix: _tenantPrefix,
      v1_plugins: v1.plugins || [],
      v2_scope_entries: scopeEntries,
      v2_intermediate_scopes: intermediateScopes,
      virtual: virtual_summary,
      ephemeral_log: _ephemeralRing.slice(),
      locale: _currentLocale,
      supported_locales: _supported.slice(),
      /* v2.0-rc5 (spec sec 17): null when host has not declared a
         sitemap (small SPAs / demos); otherwise the path catalog.
         Intermediaries treat this as PLANNING data, not authority. */
      sitemap: _sitemap ? { paths: _sitemap.paths.slice() } : null,
      /* v2.1 (spec sec 18): registered data-tables with their full
         state. [] when no host has registered any. */
      data_tables: dataTables
    };
  }

  /* ------------------------------------------------------------- validate v2 */

  function validate_global_v2(opts) {
    opts = opts || {};
    var findings = { errors: [], warnings: [] };
    /* 2026-05-09 (Claude R6): drain runtime guard findings
       FIRST, before any early-return, so security-relevant
       events (script_override_claims_user, etc.) ALWAYS reach
       the validator output regardless of i18n severity. */
    for (var fi = 0; fi < _validatorFindings.length; fi++) {
      var rf = _validatorFindings[fi];
      var bkt = rf.severity === 'error' ? findings.errors : findings.warnings;
      bkt.push({
        code:      rf.code,
        severity:  rf.severity,
        timestamp: rf.timestamp,
        note:      rf.note
      });
    }
    /* v2.0-rc2 (Grok T5-F1 + Mistral T5-F2): severity for missing-
       locale findings now honours the tolerance setting. Default
       at NAC-3 is 'warn'; hosts that need NAC-4-equivalent strict
       mode opt in via set_validation_tolerance({i18n_strict:'error'})
       OR pass opts.i18n_strict_severity explicitly. */
    var severity = opts.i18n_strict_severity || _validationTolerance.i18n_strict;
    if (severity === 'silent') return findings;
    var bucket = severity === 'error' ? findings.errors : findings.warnings;

    if (opts.i18n_strict) {
      Object.keys(_catalog).forEach(function (key) {
        var entry = _catalog[key];
        var missing = _supported.filter(function (loc) { return !entry[loc]; });
        if (missing.length) {
          bucket.push({
            code: 'i18n_missing_locale',
            key: key,
            missing: missing,
            severity: severity
          });
        }
        Object.keys(entry).forEach(function (loc) {
          if (_supported.indexOf(loc) < 0) {
            /* invalid_locale always error: catalog has nonsense key */
            findings.errors.push({
              code: 'i18n_invalid_locale',
              key: key,
              locale: loc
            });
          }
          /* empty_string honours severity tolerance too */
          if (typeof entry[loc] === 'string' && entry[loc].length === 0) {
            bucket.push({ code: 'i18n_string_empty', key: key, locale: loc, severity: severity });
          }
          if (typeof entry[loc] === 'string' && entry[loc].length > 1000) {
            findings.warnings.push({ code: 'i18n_string_too_long', key: key, locale: loc });
          }
        });
      });
      /* Mono-locale autoderived warn (always warn -- this is a
         drift signal, not a correctness signal). */
      Object.keys(_scopes).forEach(function (slug) {
        if (_scopes[slug].autoderived) {
          findings.warnings.push({ code: 'i18n_mono_locale_autoderived', slug: slug });
        }
      });
    }

    /* v2.0-rc4 (Claude T8.2 codification): at NAC-3, autoderived
       data-nac-action is SHOULD with REQUIRED fallback. Emit
       data_nac_action_autoderived per scope where the action was
       inferred rather than declared. Severity follows
       _validationTolerance.autoderived_action (default warn). */
    var autodSev = opts.autoderived_action_severity
      || _validationTolerance.autoderived_action;
    if (autodSev !== 'silent') {
      var autodBucket = autodSev === 'error' ? findings.errors : findings.warnings;
      Object.keys(_scopes).forEach(function (slug) {
        var entry = _scopes[slug];
        if (entry.element && !entry.element.hasAttribute('data-nac-action')) {
          /* Only emit for elements that DO have a registered
             intent but lack the explicit data-nac-action attr.
             autoRegister-only path: the slug exists in _scopes
             but the host did not declare data-nac-action. */
          if (entry.autoderived || entry.adopted) {
            autodBucket.push({
              code: 'data_nac_action_autoderived',
              slug: slug,
              severity: autodSev
            });
          }
        }
      });
    }
    return findings;
  }

  /* ------------------------------------------------------------- exports */

  /* Attach v2 surface to NAC namespace without overwriting v1.9 */
  NAC.scope                  = scope;
  NAC.autoRegister           = autoRegister;
  NAC.adopt                  = adopt;
  NAC.bridgeShadowRoot       = bridgeShadowRoot;
  NAC.bridgeIframe           = bridgeIframe;
  NAC.declareVirtual         = declareVirtual;
  NAC.captureEphemeral       = captureEphemeral;
  NAC.setTenantPrefix        = setTenantPrefix;
  NAC.getTenantPrefix        = getTenantPrefix;
  NAC.attestUserGesture      = attestUserGesture;
  NAC.setMobileWebViewAttestation = setMobileWebViewAttestation;
  NAC.t                      = t;
  NAC.registerCatalog        = registerCatalog;
  NAC.locale                 = locale;
  NAC.setSupportedLocales    = setSupportedLocales;
  NAC.setRTLLocales          = setRTLLocales;
  NAC.setAutoRTL             = setAutoRTL;
  NAC.set_provenance_secret  = set_provenance_secret;
  NAC.set_perf_tolerance     = set_perf_tolerance;
  NAC.get_perf_tolerance     = get_perf_tolerance;
  NAC.set_validation_tolerance = set_validation_tolerance;
  NAC.get_validation_tolerance = get_validation_tolerance;
  NAC.describe_v2            = describe_v2;
  NAC.validate_global_v2     = validate_global_v2;
  NAC.gcIntermediateScopes   = gcIntermediateScopes;
  NAC.declareSitemap         = declareSitemap;
  NAC.getSitemap             = getSitemap;

  /* Convenience: expose internals for tests */
  NAC.__v2 = {
    SUPPORTED_LOCALES_DEFAULT: SUPPORTED_LOCALES_DEFAULT,
    SEPARATOR: SEPARATOR,
    MAX_DEPTH: MAX_DEPTH,
    _scopes: _scopes,
    _catalog: _catalog,
    _virtuals: _virtuals,
    _ephemeralRing: _ephemeralRing
  };

  /* v2.0-rc3 (Claude T6-F2): warm SubtleCrypto's HMAC sign path
     at boot so the cold-start cost is paid once, not at first
     agent action. Best-effort: fails silently when no secret is
     registered yet (which is fine -- adopters that wire HMAC
     register the secret at boot). */
  function _warmCrypto() {
    if (typeof NAC.sign_provenance !== 'function') return;
    if (!_provenanceSecrets[0]) return;
    try {
      NAC.sign_provenance({ _warmup: true, ts: Date.now() }, _provenanceSecrets[0])
        .catch(function () {}); /* silently swallow warmup errors */
    } catch (_) {}
  }
  /* Defer warm to next tick so the secret-registration call has a
     chance to land first. Hosts that register the secret AFTER
     boot can manually call NAC.set_provenance_secret() which
     re-warms. */
  setTimeout(_warmCrypto, 0);

  /* ------------------------------------------------------------- v2.1 data-table primitive (spec sec 18) */
  /* See docs/V2_1_DATA_TABLE_GUIDE.md for the adopter walk-through.
     Authority separation: the runtime owns the in-memory state,
     the host owns persistence (commit handler does the HTTP/DB
     write). All operator classes (user, agent, bot) use the same
     dt_* API; the `by` discriminator on every emitted event lets
     audit pipelines attribute changes per source.type contract. */

  var _dataTables = Object.create(null);
  /* { table_id -> {
       schema: {...},               // immutable post-register
       current_rows: [...],         // collection: array of objects
       current_cells: [...],        // matrix: array of {row, col, value}
       initial_state: deep_copy,    // for discard()
       selected: Set<row_id>,       // collection only
       modified: bool,
       computed_fns: { col_key -> fn(row, allRows) } } } */

  function _dtDeepCopy(o) {
    /* JSON-roundtrip: cheap, preserves the primitive shapes our
       cells carry (string/number/boolean/null/array/plain object).
       If a host puts Date/Map in a cell we reject at register time. */
    return o === undefined ? undefined : JSON.parse(JSON.stringify(o));
  }

  function _dtEmit(name, detail) {
    document.dispatchEvent(new CustomEvent(name, { detail: detail, bubbles: true }));
  }

  function _dtBy() {
    /* Detect operator class. If the call originated from a recent
       attested user gesture, by='user'; otherwise by='agent'. The
       gesture buffer (rc3 T4-F1) is the source of truth. */
    try {
      if (typeof NAC.attestUserGesture === 'function') {
        var gesture = NAC._readGestureAttested
                    ? NAC._readGestureAttested()
                    : null;
        if (gesture && gesture.attested) return 'user';
      }
    } catch (_) {}
    return 'agent';
  }

  function _dtCheckColumnValue(col, value) {
    if (value === null || value === undefined) {
      if (col.required) return { ok: false, error: 'required_missing' };
      return { ok: true };
    }
    var t = col.type;
    if (t === 'number' || t === 'currency') {
      if (typeof value !== 'number' || !isFinite(value)) {
        return { ok: false, error: 'invalid_type:expected_number' };
      }
      if (typeof col.min === 'number' && value < col.min) {
        return { ok: false, error: 'below_min:' + col.min };
      }
      if (typeof col.max === 'number' && value > col.max) {
        return { ok: false, error: 'above_max:' + col.max };
      }
    } else if (t === 'boolean') {
      if (typeof value !== 'boolean') {
        return { ok: false, error: 'invalid_type:expected_boolean' };
      }
    } else if (t === 'select') {
      var opts = col.options || [];
      var ok = opts.some(function (o) { return (o.value !== undefined ? o.value : o) === value; });
      if (!ok) return { ok: false, error: 'invalid_option' };
    } else if (t === 'date') {
      if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}/.test(value)) {
        return { ok: false, error: 'invalid_type:expected_date_iso' };
      }
    } else {
      /* text and others: just require string-like */
      if (typeof value !== 'string' && typeof value !== 'number') {
        return { ok: false, error: 'invalid_type:expected_text' };
      }
    }
    return { ok: true };
  }

  function _dtRecomputeRow(table, row) {
    /* Recompute every column whose `computed:true` and a fn is
       registered. */
    var changed = false;
    table.schema.columns.forEach(function (col) {
      if (!col.computed) return;
      var fn = table.computed_fns[col.key];
      if (!fn) return;
      try {
        var newVal = fn(row, table.current_rows);
        if (row[col.key] !== newVal) {
          row[col.key] = newVal;
          changed = true;
        }
      } catch (_) { /* swallow; computed err leaves stale value */ }
    });
    return changed;
  }

  function _dtRecomputeAggregates(table, prevAggs) {
    var aggs = {};
    var defs = table.schema.aggregates || {};
    Object.keys(defs).forEach(function (aggKey) {
      var cols = defs[aggKey] || [];
      aggs[aggKey] = {};
      cols.forEach(function (colKey) {
        if (colKey === '*') {
          aggs[aggKey]['*'] = aggKey === 'count' ? table.current_rows.length : 0;
          return;
        }
        var values = table.current_rows
          .map(function (r) { return r[colKey]; })
          .filter(function (v) { return typeof v === 'number' && isFinite(v); });
        if (aggKey === 'sum') {
          aggs[aggKey][colKey] = values.reduce(function (s, v) { return s + v; }, 0);
        } else if (aggKey === 'avg') {
          aggs[aggKey][colKey] = values.length
            ? values.reduce(function (s, v) { return s + v; }, 0) / values.length
            : 0;
        } else if (aggKey === 'count') {
          aggs[aggKey][colKey] = values.length;
        } else if (aggKey === 'min') {
          aggs[aggKey][colKey] = values.length ? Math.min.apply(null, values) : null;
        } else if (aggKey === 'max') {
          aggs[aggKey][colKey] = values.length ? Math.max.apply(null, values) : null;
        }
      });
    });
    /* Emit per (agg, column) pair when changed. */
    if (prevAggs) {
      Object.keys(aggs).forEach(function (aggKey) {
        Object.keys(aggs[aggKey]).forEach(function (colKey) {
          var oldV = (prevAggs[aggKey] || {})[colKey];
          var newV = aggs[aggKey][colKey];
          if (oldV !== newV) {
            _dtEmit('nac:dt:aggregate_changed', {
              table_id: table.schema.table_id,
              agg_key: aggKey, column: colKey, old: oldV, new: newV
            });
          }
        });
      });
    }
    return aggs;
  }

  function _dtGenRowId(table) {
    var prefix = (table.schema.row_id_field || 'r').slice(0, 1).toUpperCase();
    var n = table.current_rows.length + 1;
    var candidate;
    do {
      candidate = prefix + n;
      n++;
    } while (table.current_rows.some(function (r) { return r[table.schema.row_id_field] === candidate; }));
    return candidate;
  }

  function registerDataTable(spec) {
    if (!spec || typeof spec !== 'object') {
      throw new Error('[NAC v2.1] registerDataTable: spec must be an object');
    }
    if (typeof spec.table_id !== 'string' || !spec.table_id) {
      throw new Error('[NAC v2.1] registerDataTable: table_id required');
    }
    if (_dataTables[spec.table_id]) {
      throw new Error('[NAC v2.1] registerDataTable: table_id "'
        + spec.table_id + '" already registered');
    }
    var subkind = spec.subkind || 'collection';
    if (['collection', 'matrix', 'readonly'].indexOf(subkind) < 0) {
      throw new Error('[NAC v2.1] registerDataTable: invalid subkind "' + subkind + '"');
    }
    /* Subkind-specific validation. */
    if (subkind === 'matrix') {
      if (!spec.row_axis || !spec.column_axis) {
        throw new Error('[NAC v2.1] registerDataTable: matrix requires row_axis + column_axis');
      }
    } else {
      if (!Array.isArray(spec.columns) || !spec.columns.length) {
        throw new Error('[NAC v2.1] registerDataTable: collection/readonly requires columns[]');
      }
      if (!spec.row_id_field) {
        throw new Error('[NAC v2.1] registerDataTable: row_id_field required for collection');
      }
    }
    var schema = {
      table_id: spec.table_id,
      scope_owner: spec.scope_owner || null,
      subkind: subkind,
      transactional: spec.transactional !== false,
      row_id_field: spec.row_id_field || null,
      columns: spec.columns || [],
      row_axis: spec.row_axis || null,
      column_axis: spec.column_axis || null,
      cell_type: spec.cell_type || 'boolean',
      supports: spec.supports || [],
      selection_mode: spec.selection_mode || 'none',
      aggregates: spec.aggregates || {},
      validators: spec.validators || []
    };
    var table = {
      schema: schema,
      current_rows: subkind === 'matrix' ? [] : (_dtDeepCopy(spec.initial_rows) || []),
      current_cells: subkind === 'matrix' ? (_dtDeepCopy(spec.initial_cells) || []) : [],
      initial_state: subkind === 'matrix'
        ? { cells: _dtDeepCopy(spec.initial_cells) || [] }
        : { rows: _dtDeepCopy(spec.initial_rows) || [] },
      selected: new Set(),
      modified: false,
      computed_fns: Object.create(null),
      _aggregates_cache: null
    };
    _dataTables[spec.table_id] = table;
    table._aggregates_cache = _dtRecomputeAggregates(table, null);
    _dtEmit('nac:dt:registered', { table_id: spec.table_id, schema: schema });
    return spec.table_id;
  }

  function unregisterDataTable(table_id) {
    if (_dataTables[table_id]) {
      delete _dataTables[table_id];
      _dtEmit('nac:dt:unregistered', { table_id: table_id });
    }
  }

  function registerDataTableComputed(table_id, column_key, fn) {
    var t = _dataTables[table_id];
    if (!t) throw new Error('[NAC v2.1] data-table not registered: ' + table_id);
    if (typeof fn !== 'function') {
      throw new Error('[NAC v2.1] computed fn must be a function');
    }
    t.computed_fns[column_key] = fn;
    /* Recompute now so newly-attached fns reflect on existing rows. */
    t.current_rows.forEach(function (row) { _dtRecomputeRow(t, row); });
    var prev = t._aggregates_cache;
    t._aggregates_cache = _dtRecomputeAggregates(t, prev);
  }

  function dt_state(table_id) {
    var t = _dataTables[table_id];
    if (!t) return null;
    if (t.schema.subkind === 'matrix') {
      return {
        cells: _dtDeepCopy(t.current_cells),
        modified: t.modified,
        valid: dt_validate(table_id).valid
      };
    }
    return {
      rows: _dtDeepCopy(t.current_rows),
      aggregates: _dtDeepCopy(t._aggregates_cache),
      modified: t.modified,
      valid: dt_validate(table_id).valid,
      selected_count: t.selected.size,
      selected_ids: Array.from(t.selected)
    };
  }

  function dt_add_row(table_id, valuesByColumn) {
    var t = _dataTables[table_id];
    if (!t) throw new Error('[NAC v2.1] data-table not registered: ' + table_id);
    if (t.schema.subkind === 'matrix') {
      throw new Error('[NAC v2.1] add_row not applicable to matrix');
    }
    if (t.schema.subkind === 'readonly') {
      throw new Error('[NAC v2.1] add_row not allowed on readonly');
    }
    var values = valuesByColumn || {};
    var row = {};
    t.schema.columns.forEach(function (col) {
      if (col.key === t.schema.row_id_field) return;
      if (Object.prototype.hasOwnProperty.call(values, col.key)) {
        row[col.key] = values[col.key];
      } else if (col.required && !col.computed) {
        /* required but missing -- caller must provide */
      }
    });
    /* Row id: caller-provided OR auto-generated. */
    var rowId = values[t.schema.row_id_field];
    if (!rowId) rowId = _dtGenRowId(t);
    row[t.schema.row_id_field] = rowId;
    /* Validate every provided column. */
    var fail = null;
    t.schema.columns.forEach(function (col) {
      if (fail) return;
      if (col.computed) return;
      var v = row[col.key];
      var check = _dtCheckColumnValue(col, v);
      if (!check.ok) fail = { column: col.key, error: check.error };
    });
    if (fail) {
      _dtEmit('nac:dt:validation_failed', {
        table_id: t.schema.table_id,
        errors: [{ code: 'add_row_invalid', column: fail.column, message_i18n: { en: fail.error } }]
      });
      return { row_id: null, ok: false, error: fail.error, column: fail.column };
    }
    t.current_rows.push(row);
    _dtRecomputeRow(t, row);
    var prev = t._aggregates_cache;
    t._aggregates_cache = _dtRecomputeAggregates(t, prev);
    t.modified = true;
    _dtEmit('nac:dt:row_added', {
      table_id: t.schema.table_id, row: _dtDeepCopy(row), by: _dtBy()
    });
    return { row_id: rowId, ok: true };
  }

  function dt_remove_row(table_id, row_id) {
    var t = _dataTables[table_id];
    if (!t || t.schema.subkind === 'matrix' || t.schema.subkind === 'readonly') return;
    var idx = -1;
    for (var i = 0; i < t.current_rows.length; i++) {
      if (t.current_rows[i][t.schema.row_id_field] === row_id) { idx = i; break; }
    }
    if (idx < 0) return;
    t.current_rows.splice(idx, 1);
    t.selected.delete(row_id);
    var prev = t._aggregates_cache;
    t._aggregates_cache = _dtRecomputeAggregates(t, prev);
    t.modified = true;
    _dtEmit('nac:dt:row_removed', {
      table_id: t.schema.table_id, row_id: row_id, by: _dtBy()
    });
  }

  function dt_edit_cell(table_id, row_id, column_key, value) {
    var t = _dataTables[table_id];
    if (!t) return { ok: false, error: 'table_not_registered' };
    if (t.schema.subkind === 'matrix') {
      return { ok: false, error: 'use_dt_set_cell_for_matrix' };
    }
    if (t.schema.subkind === 'readonly') return { ok: false, error: 'readonly' };
    var col = t.schema.columns.filter(function (c) { return c.key === column_key; })[0];
    if (!col) return { ok: false, error: 'column_not_found' };
    /* computed wins over editable -- a column declared
       `computed:true` is implicitly non-editable even if the
       host forgets to set editable:false. Spec sec 18.4 ordering. */
    if (col.computed) return { ok: false, error: 'computed_column' };
    if (!col.editable) return { ok: false, error: 'column_not_editable' };
    var check = _dtCheckColumnValue(col, value);
    if (!check.ok) {
      _dtEmit('nac:dt:validation_failed', {
        table_id: t.schema.table_id,
        errors: [{ code: 'edit_cell_invalid', row_id: row_id, column: column_key,
                   message_i18n: { en: check.error } }]
      });
      return { ok: false, error: check.error };
    }
    var row = t.current_rows.filter(function (r) {
      return r[t.schema.row_id_field] === row_id;
    })[0];
    if (!row) return { ok: false, error: 'row_not_found' };
    var oldVal = row[column_key];
    if (oldVal === value) return { ok: true, unchanged: true };
    row[column_key] = value;
    _dtRecomputeRow(t, row);
    var prev = t._aggregates_cache;
    t._aggregates_cache = _dtRecomputeAggregates(t, prev);
    t.modified = true;
    _dtEmit('nac:dt:cell_edited', {
      table_id: t.schema.table_id,
      row_id: row_id, column: column_key,
      old: oldVal, new: value, by: _dtBy()
    });
    return { ok: true };
  }

  function dt_read_aggregate(table_id, agg_key, column_key) {
    var t = _dataTables[table_id];
    if (!t) return null;
    if (!t._aggregates_cache || !t._aggregates_cache[agg_key]) return null;
    var v = t._aggregates_cache[agg_key][column_key];
    return v === undefined ? null : v;
  }

  function dt_validate(table_id) {
    var t = _dataTables[table_id];
    if (!t) return { valid: false, errors: [{ code: 'table_not_registered' }] };
    var errors = [];
    /* Per-row validators. */
    (t.schema.validators || []).forEach(function (v) {
      if (v.kind !== 'row') return;
      t.current_rows.forEach(function (row) {
        var cellVal = row[v.column];
        var ok = _dtCheckOp(cellVal, v.op, v.value);
        if (!ok) errors.push({
          code: v.code, row_id: row[t.schema.row_id_field],
          column: v.column, message_i18n: v.message_i18n || null
        });
      });
    });
    /* Table-level validators. */
    (t.schema.validators || []).forEach(function (v) {
      if (v.kind !== 'table') return;
      if (v.unique_columns) {
        var seen = Object.create(null);
        t.current_rows.forEach(function (row) {
          var key = v.unique_columns.map(function (c) { return row[c]; }).join('|');
          if (seen[key]) {
            errors.push({
              code: v.code, row_id: row[t.schema.row_id_field],
              message_i18n: v.message_i18n || null
            });
          }
          seen[key] = true;
        });
      }
      if (typeof v.min_rows === 'number' && t.current_rows.length < v.min_rows) {
        errors.push({ code: v.code, message_i18n: v.message_i18n || null });
      }
      if (typeof v.max_rows === 'number' && t.current_rows.length > v.max_rows) {
        errors.push({ code: v.code, message_i18n: v.message_i18n || null });
      }
    });
    /* Required-column validator (implicit). */
    t.schema.columns.forEach(function (col) {
      if (!col.required || col.computed) return;
      t.current_rows.forEach(function (row) {
        var v = row[col.key];
        if (v === null || v === undefined || v === '') {
          errors.push({
            code: 'required_missing', row_id: row[t.schema.row_id_field],
            column: col.key, message_i18n: { en: 'Required column missing' }
          });
        }
      });
    });
    return { valid: errors.length === 0, errors: errors };
  }

  function _dtCheckOp(cellVal, op, value) {
    switch (op) {
      case 'gt':       return typeof cellVal === 'number' && cellVal > value;
      case 'gte':      return typeof cellVal === 'number' && cellVal >= value;
      case 'lt':       return typeof cellVal === 'number' && cellVal < value;
      case 'lte':      return typeof cellVal === 'number' && cellVal <= value;
      case 'eq':       return cellVal === value;
      case 'neq':      return cellVal !== value;
      case 'in':       return Array.isArray(value) && value.indexOf(cellVal) >= 0;
      case 'matches':  return typeof cellVal === 'string' && new RegExp(value).test(cellVal);
      default:         return true;
    }
  }

  function dt_select(table_id, target) {
    var t = _dataTables[table_id];
    if (!t || t.schema.subkind === 'matrix') return { selected_count: 0 };
    var ids = [];
    if (target === null || target === 'none') {
      ids = [];
    } else if (target === 'all' || target === 'visible') {
      ids = t.current_rows.map(function (r) { return r[t.schema.row_id_field]; });
    } else if (Array.isArray(target)) {
      ids = target.slice();
    } else if (target && target.column && target.op) {
      ids = t.current_rows
        .filter(function (r) { return _dtCheckOp(r[target.column], target.op, target.value); })
        .map(function (r) { return r[t.schema.row_id_field]; });
    } else if (typeof target === 'string') {
      ids = [target];
    }
    t.selected = new Set(ids);
    _dtEmit('nac:dt:selection_changed', {
      table_id: t.schema.table_id,
      selected_count: t.selected.size,
      selected_ids: Array.from(t.selected)
    });
    return { selected_count: t.selected.size };
  }

  function dt_set_cell(table_id, row_slug, col_slug, value) {
    var t = _dataTables[table_id];
    if (!t) return { ok: false, error: 'table_not_registered' };
    if (t.schema.subkind !== 'matrix') {
      return { ok: false, error: 'use_dt_edit_cell_for_collection' };
    }
    /* Validate row/col exist on the axes. */
    var rowKnown = (t.schema.row_axis.values || [])
      .some(function (r) { return r.slug === row_slug; });
    var colKnown = (t.schema.column_axis.values || [])
      .some(function (c) { return c.slug === col_slug; });
    if (!rowKnown) return { ok: false, error: 'row_not_in_axis' };
    if (!colKnown) return { ok: false, error: 'col_not_in_axis' };
    var existing = null;
    for (var i = 0; i < t.current_cells.length; i++) {
      if (t.current_cells[i].row === row_slug && t.current_cells[i].col === col_slug) {
        existing = t.current_cells[i]; break;
      }
    }
    var oldVal = existing ? existing.value : undefined;
    if (oldVal === value) return { ok: true, unchanged: true };
    if (existing) {
      existing.value = value;
    } else {
      t.current_cells.push({ row: row_slug, col: col_slug, value: value });
    }
    t.modified = true;
    _dtEmit('nac:dt:matrix_cell_set', {
      table_id: t.schema.table_id,
      row: row_slug, col: col_slug, old: oldVal, new: value, by: _dtBy()
    });
    return { ok: true };
  }

  function dt_get_cell(table_id, row_slug, col_slug) {
    var t = _dataTables[table_id];
    if (!t || t.schema.subkind !== 'matrix') return undefined;
    for (var i = 0; i < t.current_cells.length; i++) {
      if (t.current_cells[i].row === row_slug && t.current_cells[i].col === col_slug) {
        return t.current_cells[i].value;
      }
    }
    return undefined;
  }

  function dt_commit(table_id) {
    var t = _dataTables[table_id];
    if (!t) return { ok: false, error: 'table_not_registered' };
    var v = dt_validate(table_id);
    if (!v.valid) {
      _dtEmit('nac:dt:validation_failed', {
        table_id: t.schema.table_id, errors: v.errors
      });
      return { ok: false, errors: v.errors };
    }
    /* Build audit diff vs initial_state. */
    var initial = t.initial_state;
    var finalState = t.schema.subkind === 'matrix'
      ? { cells: _dtDeepCopy(t.current_cells) }
      : { rows: _dtDeepCopy(t.current_rows) };
    /* Reset modified + replace initial_state so a subsequent
       discard would revert to THIS state, not the original. */
    t.initial_state = _dtDeepCopy(finalState);
    t.modified = false;
    _dtEmit('nac:dt:committed', {
      table_id: t.schema.table_id,
      final_state: finalState,
      audit_diff: { initial: initial, final: finalState }
    });
    return { ok: true, final_state: finalState };
  }

  function dt_discard(table_id) {
    var t = _dataTables[table_id];
    if (!t) return;
    if (t.schema.subkind === 'matrix') {
      t.current_cells = _dtDeepCopy(t.initial_state.cells) || [];
    } else {
      t.current_rows = _dtDeepCopy(t.initial_state.rows) || [];
    }
    t.selected.clear();
    var prev = t._aggregates_cache;
    t._aggregates_cache = _dtRecomputeAggregates(t, prev);
    t.modified = false;
    _dtEmit('nac:dt:discarded', { table_id: t.schema.table_id });
  }

  /* describe_v2() extension: surface every registered data-table. */
  function _dtSummariseAll() {
    var out = [];
    Object.keys(_dataTables).forEach(function (id) {
      var t = _dataTables[id];
      out.push({
        table_id: id,
        scope_owner: t.schema.scope_owner,
        subkind: t.schema.subkind,
        schema: {
          columns: t.schema.columns,
          row_axis: t.schema.row_axis,
          column_axis: t.schema.column_axis,
          supports: t.schema.supports,
          aggregates: t.schema.aggregates,
          selection_mode: t.schema.selection_mode,
          row_id_field: t.schema.row_id_field
        },
        current_state: dt_state(id)
      });
    });
    return out;
  }

  /* Exports for v2.1 data-table primitive. */
  NAC.registerDataTable           = registerDataTable;
  NAC.unregisterDataTable         = unregisterDataTable;
  NAC.registerDataTableComputed   = registerDataTableComputed;
  NAC.dt_state                    = dt_state;
  NAC.dt_add_row                  = dt_add_row;
  NAC.dt_remove_row               = dt_remove_row;
  NAC.dt_edit_cell                = dt_edit_cell;
  NAC.dt_read_aggregate           = dt_read_aggregate;
  NAC.dt_validate                 = dt_validate;
  NAC.dt_select                   = dt_select;
  NAC.dt_set_cell                 = dt_set_cell;
  NAC.dt_get_cell                 = dt_get_cell;
  NAC.dt_commit                   = dt_commit;
  NAC.dt_discard                  = dt_discard;
  /* Exposed for tests + describe_v2 extension. */
  NAC.__v2_dataTables             = _dataTables;
  NAC.__v2_dtSummariseAll         = _dtSummariseAll;

  /* Bump version constants */
  NAC.version_v2      = '2.1.0-rc1';
  NAC.spec_version_v2 = '2.1';

  /* v2.2.1: guard browser-only dispatch so this bundle is importable
     in Node / SSR / test contexts. */
  if (typeof document !== 'undefined') {
    document.dispatchEvent(new CustomEvent('nac:v2_installed', {
      detail: { version: '2.0.0' }, bubbles: true
    }));
  }
})(typeof window !== 'undefined' ? window : globalThis);
