import { chromium } from 'playwright';
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.request.post('http://127.0.0.1:8080/api/reset');
  await page.request.post('http://127.0.0.1:8080/api/open-invoice', { data: { invoice_id: 'INV-0001', step: 2 } });
  await page.goto('http://127.0.0.1:8080/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const data = await page.evaluate(() => {
    const d = (window as any).NAC.describe();
    const inv = d.plugins.find((p: any) => p.plugin === 'invoice_edit_modal');
    return { sample: (inv?.elements || []).slice(0, 3), keys: Object.keys((inv?.elements || [])[0] || {}) };
  });
  console.log(JSON.stringify(data, null, 2));
  await browser.close();
})();
