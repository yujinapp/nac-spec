import { chromium } from 'playwright';
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.request.post('http://127.0.0.1:8080/api/reset');
  await page.request.post('http://127.0.0.1:8080/api/open-invoice',
    { data: { invoice_id: 'INV-0001', step: 2 } });
  await page.goto('http://127.0.0.1:8080/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);

  /* Probe rows before */
  const before = await page.request.get('http://127.0.0.1:8080/api/invoices/INV-0001').then(r => r.json());
  console.log('rows before:', before.invoice.lines.length);

  /* Trigger dt_add_row via NAC */
  const dispatchRes = await page.evaluate(async () => {
    const w = window as any;
    try {
      const r = await w.NAC.dt_add_row('invoice.lines', { description: 'TestMonitor', qty: 1, unit_price: 250, discount_pct: 0 });
      return { ok: true, r };
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  });
  console.log('dispatch:', JSON.stringify(dispatchRes));

  /* Wait for the bridge fetch to complete */
  await page.waitForFunction(() => (window as any).__pendingMutations === 0, { timeout: 5000 });
  await page.waitForTimeout(300);

  const after = await page.request.get('http://127.0.0.1:8080/api/invoices/INV-0001').then(r => r.json());
  console.log('rows after:', after.invoice.lines.length);
  console.log('last row:', JSON.stringify(after.invoice.lines[after.invoice.lines.length-1]));

  await browser.close();
})();
