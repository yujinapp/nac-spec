/**
 * Probe: after clicking new_invoice, does invoice_edit_modal.lines
 * appear in NAC.__v2_dataTables? And how long does it take?
 */
import { chromium } from 'playwright';

(async () => {
  const url = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await fetch(url + '/api/reset', { method: 'POST' });
  await page.goto(url + '/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);

  const before = await page.evaluate(() => ({
    has_awaitDataTable: typeof (window as any).NAC?.awaitDataTable === 'function',
    spec_version: (window as any).NAC?.spec_version_v2,
    version_v2: (window as any).NAC?.version_v2,
    dt_keys: Object.keys((window as any).NAC?.__v2_dataTables || {}),
    has_state: typeof (window as any).__state === 'function',
    open_invoice_id: (window as any).__state ? (window as any).__state().open_invoice_id : null,
  }));
  console.log('BEFORE click:', JSON.stringify(before, null, 2));

  // Select a client. The new_invoice_client field is a <select>.
  await page.evaluate(async () => {
    const w = window as any;
    const sel = document.querySelector('[data-nac-id="invoice_app.new_invoice_client"]') as HTMLSelectElement;
    if (!sel) throw new Error('client select not in DOM');
    // pick first non-empty option whose text includes Acme
    let matched = false;
    for (let i = 0; i < sel.options.length; i++) {
      if (/acme/i.test(sel.options[i].text)) { sel.selectedIndex = i; matched = true; break; }
    }
    if (!matched) throw new Error('no Acme option found; options=' +
      Array.from(sel.options).map(o => o.text).join(','));
    sel.dispatchEvent(new Event('input',  { bubbles: true }));
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  });
  console.log('Selected client.');

  const t0 = Date.now();
  await page.evaluate(async () => {
    const w = window as any;
    await w.NAC.click('invoice_app.new_invoice');
  });
  const t1 = Date.now();
  console.log(`NAC.click resolved in ${t1 - t0}ms`);

  for (let i = 0; i < 20; i++) {
    const snap = await page.evaluate(() => ({
      dt_keys: Object.keys((window as any).NAC?.__v2_dataTables || {}),
      open_invoice_id: (window as any).__state ? (window as any).__state().open_invoice_id : null,
      pending: (window as any).__pendingMutations,
    }));
    console.log(`  t+${(i+1)*50}ms`, snap);
    if (snap.dt_keys.includes('invoice_edit_modal.lines')) {
      console.log('=> invoice_edit_modal.lines is REGISTERED');
      break;
    }
    await page.waitForTimeout(50);
  }

  // Test awaitDataTable directly
  const probe = await page.evaluate(async () => {
    const w = window as any;
    const t = Date.now();
    const ok = await w.NAC.awaitDataTable('invoice_edit_modal.lines', 1200);
    return { ok, elapsed: Date.now() - t };
  });
  console.log('awaitDataTable result:', probe);

  await ctx.close();
  await browser.close();
})();
