import { scanJsTemplates } from '../../../yujin-forge/src/migrate/js-template-walker.js';
import { readFile } from 'node:fs/promises';
const src = await readFile('fixtures/invoice-app/pages/app.js', 'utf-8');
console.log('source length:', src.length);
const r = scanJsTemplates('app.js', src);
console.log('candidates:', r.candidates.length);
for (const c of r.candidates.slice(0, 10)) {
  console.log('  tag=' + c.tag + ' role=' + c.role + ' verb=' + c.verb + ' conf=' + c.confidence.toFixed(2));
  console.log('    proposed=' + c.proposed_id_template);
  console.log('    dynamic=' + c.dynamic_id_expr);
  console.log('    line=' + c.line + ' already=' + c.already_decorated);
}
