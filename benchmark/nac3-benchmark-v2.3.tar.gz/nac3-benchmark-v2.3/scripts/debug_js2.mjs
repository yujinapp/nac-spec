import { scanJsTemplates } from '../../../yujin-forge/src/migrate/js-template-walker.js';
import { readFile } from 'node:fs/promises';
const src = await readFile('fixtures/invoice-app/pages/app.js', 'utf-8');
console.log('first 200 chars:', JSON.stringify(src.slice(0, 200)));
console.log('len:', src.length, 'first <:', src.indexOf('<'), 'first <button:', src.indexOf('<button'));
const tagRe = /<([a-zA-Z][a-zA-Z0-9]*)(\s[^>]*?)?(\/?)\s*>/gs;
let m;
let count = 0;
while ((m = tagRe.exec(src)) !== null) {
  count++;
  if (count <= 5) {
    console.log('  match:', JSON.stringify(m[0].slice(0, 80)) + (m[0].length > 80 ? '...' : ''));
    console.log('    tag:', m[1], ' at offset:', m.index);
  }
}
console.log('total regex hits:', count);
