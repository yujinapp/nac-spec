import { readFile } from 'node:fs/promises';
const src = await readFile('fixtures/invoice-app/pages/app.js', 'utf-8');
const tagRe = /<([a-zA-Z][a-zA-Z0-9]*)(\s[^>]*?)?(\/?)\s*>/gs;
let m;
const tags = {};
while ((m = tagRe.exec(src)) !== null) {
  const t = m[1].toLowerCase();
  tags[t] = (tags[t] || 0) + 1;
}
console.log('tag counts:', JSON.stringify(tags, null, 2));
