import { readFile } from 'node:fs/promises';
const src = await readFile('fixtures/invoice-app/pages/app.js', 'utf-8');

/* Manually run computeStringScopes inline */
function computeStringScopes(source) {
  const len = source.length;
  const inStr = new Uint8Array(len);
  let i = 0;
  while (i < len) {
    const c = source.charCodeAt(i);
    if (c === 47 && i + 1 < len && source.charCodeAt(i + 1) === 47) {
      while (i < len && source.charCodeAt(i) !== 10) i++;
      continue;
    }
    if (c === 47 && i + 1 < len && source.charCodeAt(i + 1) === 42) {
      i += 2;
      while (i < len - 1 && !(source.charCodeAt(i) === 42 && source.charCodeAt(i + 1) === 47)) i++;
      i += 2;
      continue;
    }
    if (c === 34 || c === 39 || c === 96) {
      const quote = c;
      const start = i;
      i++;
      while (i < len) {
        const cc = source.charCodeAt(i);
        if (cc === 92) { i += 2; continue; }
        if (cc === quote) { i++; break; }
        if (quote === 96 && cc === 36 && i + 1 < len && source.charCodeAt(i + 1) === 123) {
          let depth = 1; i += 2;
          while (i < len && depth > 0) {
            const cd = source.charCodeAt(i);
            if (cd === 123) depth++;
            else if (cd === 125) depth--;
            i++;
          }
          continue;
        }
        i++;
      }
      for (let k = start; k < i; k++) inStr[k] = 1;
      continue;
    }
    i++;
  }
  return inStr;
}

const inString = computeStringScopes(src);
const tagRe = /<([a-zA-Z][a-zA-Z0-9]*)(\s[^>]*?)?(\/?)\s*>/gs;
let m;
while ((m = tagRe.exec(src)) !== null) {
  const t = m[1].toLowerCase();
  if (t !== 'button' && t !== 'input' && t !== 'textarea') continue;
  const offset = m.index;
  console.log(`tag=${t} offset=${offset} inString=${inString[offset]}`);
  console.log('  full match:', JSON.stringify(m[0].slice(0, 100)));
  console.log('  context:', JSON.stringify(src.slice(Math.max(0,offset-10), offset+30)));
}
