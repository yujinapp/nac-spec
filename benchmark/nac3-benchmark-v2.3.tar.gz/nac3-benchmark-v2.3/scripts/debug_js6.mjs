import { readFile } from 'node:fs/promises';
const src = await readFile('fixtures/invoice-app/pages/app.js', 'utf-8');

/* Same as computeStringScopes but logging transitions */
const len = src.length;
const inStr = new Uint8Array(len);
let i = 0;
let stringOpens = 0;
let stringCloses = 0;
while (i < len) {
  const c = src.charCodeAt(i);
  if (c === 47 && i + 1 < len && src.charCodeAt(i + 1) === 47) {
    while (i < len && src.charCodeAt(i) !== 10) i++;
    continue;
  }
  if (c === 47 && i + 1 < len && src.charCodeAt(i + 1) === 42) {
    i += 2;
    while (i < len - 1 && !(src.charCodeAt(i) === 42 && src.charCodeAt(i + 1) === 47)) i++;
    i += 2;
    continue;
  }
  if (c === 34 || c === 39 || c === 96) {
    const quote = c;
    const start = i;
    i++;
    while (i < len) {
      const cc = src.charCodeAt(i);
      if (cc === 92) { i += 2; continue; }
      if (cc === quote) { i++; break; }
      if (quote === 96 && cc === 36 && i + 1 < len && src.charCodeAt(i + 1) === 123) {
        let depth = 1; i += 2;
        while (i < len && depth > 0) {
          const cd = src.charCodeAt(i);
          if (cd === 123) depth++;
          else if (cd === 125) depth--;
          i++;
        }
        continue;
      }
      i++;
    }
    for (let k = start; k < i; k++) inStr[k] = 1;
    if (start < 7000) {
      const qchar = String.fromCharCode(quote);
      console.log(`  str scope ${start}..${i-1} (quote=${qchar}, len=${i-start}, snippet=${JSON.stringify(src.slice(start, Math.min(start+40, i)))})`);
    }
    continue;
  }
  i++;
}
console.log('--- result for 6122 .. 6125 ---');
for (let k = 6120; k <= 6128; k++) console.log(`  ${k}: ${JSON.stringify(src[k])} inStr=${inStr[k]}`);
