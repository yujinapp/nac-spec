import { readFile } from 'node:fs/promises';
const src = await readFile('fixtures/invoice-app/pages/app.js', 'utf-8');
const len = src.length;
const inStr = new Uint8Array(len);
let i = 0;
const scopes = [];
while (i < len) {
  const c = src.charCodeAt(i);
  if (c === 47 && i + 1 < len && src.charCodeAt(i + 1) === 47) {
    while (i < len && src.charCodeAt(i) !== 10) i++;
    continue;
  }
  if (c === 47 && i + 1 < len && src.charCodeAt(i + 1) === 42) {
    i += 2;
    while (i < len - 1 && !(src.charCodeAt(i) === 42 && src.charCodeAt(i + 1) === 47)) i++;
    i += 2;
    continue;
  }
  if (c === 34 || c === 39 || c === 96) {
    const quote = c;
    const start = i;
    i++;
    while (i < len) {
      const cc = src.charCodeAt(i);
      if (cc === 92) { i += 2; continue; }
      if (cc === quote) { i++; break; }
      i++;
    }
    scopes.push({ start, end: i, len: i - start, quote: String.fromCharCode(quote), snippet: src.slice(start, Math.min(start + 30, i)) });
    continue;
  }
  i++;
}
/* Show scopes from offset 5800 onwards */
for (const s of scopes) {
  if (s.start < 4700) continue;
  if (s.start > 5550) break;
  console.log(`  ${s.start}..${s.end-1} (q=${s.quote}, len=${s.len}, snip=${JSON.stringify(s.snippet)})`);
}
