import { chromium } from 'playwright';
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.request.post('http://127.0.0.1:8080/api/reset');
  await page.request.post('http://127.0.0.1:8080/api/open-invoice',
    { data: { invoice_id: 'INV-0001', step: 2 } });
  await page.goto('http://127.0.0.1:8080/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);

  const probe = await page.evaluate(() => {
    const w = window as any;
    const d  = w.NAC.describe();
    const v2 = w.NAC.describe_v2();
    return {
      plugins: (d.plugins || []).map((p: any) => ({
        plugin: p.plugin,
        n_elements: (p.elements || []).length,
        sample_ids: (p.elements || []).slice(0, 3).map((e: any) => e.id),
      })),
      data_tables: (v2.data_tables || []).map((dt: any) => ({
        table_id: dt.table_id,
        subkind: dt.schema?.subkind,
        n_rows: (dt.current_state?.rows || []).length,
        supports: dt.schema?.supports,
        sample_row: (dt.current_state?.rows || [])[0],
      })),
    };
  });
  console.log(JSON.stringify(probe, null, 2));
  await browser.close();
})();
