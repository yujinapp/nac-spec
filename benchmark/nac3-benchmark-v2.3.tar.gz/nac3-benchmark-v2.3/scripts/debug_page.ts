import { chromium } from 'playwright';
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  page.on('pageerror', e => console.log('PAGE_ERROR:', e.message));
  page.on('console', m => console.log(m.type().toUpperCase() + ':', m.text()));
  const v = process.argv[2] || 'raw';
  await page.goto(`http://127.0.0.1:8080/${v}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(700);
  const probe = await page.evaluate(() => {
    const w = window as any;
    return {
      has_state_fn: typeof w.__state === 'function',
      has_initial: typeof w.__INITIAL_STATE__,
      has_push: typeof w.__pushState,
      has_helpers: typeof w.__benchHelpers,
      logText: (document.getElementById('log')?.textContent || '').slice(0, 200),
      listRows: document.querySelectorAll('#invoice-list-body tr').length,
    };
  });
  console.log('PROBE', JSON.stringify(probe, null, 2));
  await browser.close();
})();
