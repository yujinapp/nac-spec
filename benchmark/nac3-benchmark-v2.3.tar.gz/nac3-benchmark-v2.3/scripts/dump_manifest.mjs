import { chromium } from 'playwright';
const browser = await chromium.launch();
const ctx = await browser.newContext();
const page = await ctx.newPage();
await page.goto('http://127.0.0.1:8080/nac3', { waitUntil: 'networkidle' });
await page.waitForTimeout(200);
const snapshot = await page.evaluate(() => {
  const w = window;
  return w.NAC.describe();
});
console.log(JSON.stringify(snapshot, null, 2));
await browser.close();
