/**
 * dump_t_mcp4.ts -- capture the EXACT system prompt + user prompt + NAC
 * snapshot that the harness sends for T_MCP4 NAC3, plus run it once
 * and dump the model's response. Used to populate the failure-analysis
 * doc with real artifacts.
 *
 * Run: tsx scripts/dump_t_mcp4.ts > docs/T_MCP4_DUMP.txt
 */
import 'dotenv/config';
import { chromium } from 'playwright';
import { snapshotNac3, callModelNac3, parseOutput } from '../src/conditions/nac3.js';
import { PILOT_TASKS } from '../src/tasks_invoice.js';

const task = PILOT_TASKS.find(t => t.id === 'T_MCP4_create_invoice_full')!;
const BASE = 'http://127.0.0.1:8080';

async function main() {
  await fetch(BASE + '/api/reset', { method: 'POST' });
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto(BASE + '/nac3', { waitUntil: 'networkidle' });
  await task.setup(ctx, page);
  await page.waitForTimeout(400);

  const snapshot = await snapshotNac3(page);
  console.log('==============================');
  console.log('FULL NAC SNAPSHOT (as sent to model)');
  console.log('==============================');
  console.log(JSON.stringify(snapshot, null, 2));
  console.log();
  console.log('==============================');
  console.log('USER PROMPT TEXT');
  console.log('==============================');
  console.log(`Task: ${task.prompt}`);
  console.log();
  console.log('NAC tree snapshot (JSON):');
  console.log(JSON.stringify(snapshot));
  console.log();
  console.log('Respond with the JSON object only.');
  console.log();
  console.log('==============================');
  console.log('MODEL OUTPUT (claude-sonnet-4-6)');
  console.log('==============================');
  const r = await callModelNac3({ snapshot, task: task.prompt, lang: 'es' });
  if (r.ok) {
    console.log('Tokens in:', r.usage.input_tokens, 'out:', r.usage.output_tokens);
    console.log('Latency:', r.latency_ms, 'ms');
    console.log();
    console.log(r.raw_text);
  } else {
    console.log('API error:', r.error);
  }

  await ctx.close();
  await browser.close();
}

main();
