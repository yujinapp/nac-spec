/**
 * Run Forge's HTML + JS walkers over the invoice-app fixture and
 * produce a Forge-decorated variant. Output goes to:
 *
 *   fixtures/invoice-app-forge-silent/   (auto-applied)
 *   fixtures/invoice-app-forge-assisted/ (proposed list, manual review)
 *
 * Invoked manually:
 *   tsx scripts/forge_decorate.mjs silent
 *   tsx scripts/forge_decorate.mjs assisted
 *
 * The assisted variant prints the queue but for the benchmark we
 * accept all proposed values (-y equivalent) so the resulting
 * fixture is deterministic; in real-world use the assisted CLI
 * runs interactively.
 */
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { walkHtmlSource, applyDecisionsToSource } from '../../../yujin-forge/src/migrate/html-walker.js';
import { scanJsTemplates, applyJsDecisions } from '../../../yujin-forge/src/migrate/js-template-walker.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const mode = (process.argv[2] || 'silent');
if (mode !== 'silent' && mode !== 'assisted') {
  console.error('usage: tsx scripts/forge_decorate.mjs <silent|assisted>');
  process.exit(1);
}

const srcDir = path.resolve(ROOT, 'fixtures', 'invoice-app', 'pages');
const dstDir = path.resolve(ROOT, 'fixtures', `invoice-app-forge-${mode}`, 'pages');
await fs.mkdir(dstDir, { recursive: true });

console.log(`Forge decorate (mode=${mode})`);
console.log(`  src: ${srcDir}`);
console.log(`  dst: ${dstDir}`);

/* Copy untouched assets first */
for (const f of ['app.css']) {
  const src = path.join(srcDir, f);
  const dst = path.join(dstDir, f);
  await fs.copyFile(src, dst);
  console.log(`  cp ${f}`);
}

/* HTML walker on skeleton.html.
   The skeleton.html has many statically-rendered elements (the modal,
   the wizard panels, etc.). Forge walker decorates these. */
const skeletonPath = path.join(srcDir, 'skeleton.html');
const skeletonSrc = await fs.readFile(skeletonPath, 'utf-8');
const htmlResult = walkHtmlSource(skeletonSrc, 'skeleton.html');
/* silent vs assisted threshold semantics:
   - silent: auto-apply only high-confidence (>= 0.85). Below threshold
     candidates stay un-decorated -- this is the realistic "Forge ran
     unattended on my project" outcome.
   - assisted: human reviewed every candidate and approved all (in
     bench mode we --yes everything). Threshold 0 = full coverage.
   The contrast lets the bench measure how much "no manual review"
   costs the agent in success rate / hallucinations. */
const htmlThreshold = mode === 'silent' ? 0.85 : 0.0;
const htmlDecisions = htmlResult.candidates
  .filter(c => !c.existing_nac_id && c.confidence >= htmlThreshold)
  .map(c => ({
    fingerprint: c.fingerprint,
    nac_id: c.proposed_id,
    role: c.role,
    verb: c.proposed_verb,
    plugin: c.proposed_plugin,
  }));
const patchedSkeleton = applyDecisionsToSource(skeletonSrc, htmlResult, htmlDecisions);
await fs.writeFile(path.join(dstDir, 'skeleton.html'), patchedSkeleton, 'utf-8');
console.log(`  decorated skeleton.html: +${htmlDecisions.length} attrs / ${htmlResult.candidates.length} candidates`);

/* JS template walker on app.js. */
const appJsPath = path.join(srcDir, 'app.js');
const appJsSrc = await fs.readFile(appJsPath, 'utf-8');
const jsResult = scanJsTemplates('app.js', appJsSrc);
const jsThreshold = mode === 'silent' ? 0.85 : 0.0;
const jsDecisions = jsResult.candidates
  .filter(c => !c.already_decorated && c.confidence >= jsThreshold)
  .map(c => ({
    fingerprint: c.fingerprint,
    nac_id_template: c.proposed_id_template,
    role: c.role,
    verb: c.verb,
    plugin: c.plugin,
    offset: c.offset,
    opening_tag_text: c.opening_tag_text,
  }));
const patchedAppJs = applyJsDecisions(appJsSrc, jsDecisions);
await fs.writeFile(path.join(dstDir, 'app.js'), patchedAppJs, 'utf-8');
console.log(`  decorated app.js: +${jsDecisions.length} injections / ${jsResult.candidates.length} candidates`);

/* nac_decoration.js: Forge variant DOES NOT use a manifest. The
   decorated HTML + decorated app.js carry data-nac-* attrs directly.
   We emit a stub nac_decoration.js that does NOTHING -- the
   server includes the file unconditionally per the variant. */
const stubDecoration = `
/* Forge-decorated variant -- NO MANIFEST REGISTRATION.
 *
 * The page is decorated statically by Forge's walker. The NAC
 * runtime auto-discovers verbs + roles from data-nac-* attributes
 * on the DOM via click_by_verb's fallback path. The manifest is
 * intentionally absent so the bench measures "what an agent can
 * do with walker-decorated UI alone, without manual manifest
 * authoring".
 */
(function () {
  if (typeof window === 'undefined' || !window.NAC) return;
  /* No-op. */
})();
`;
await fs.writeFile(path.join(dstDir, 'nac_decoration.js'), stubDecoration, 'utf-8');
console.log(`  emitted nac_decoration.js stub`);

/* Sidecar report */
const report = {
  mode,
  generated_at: new Date().toISOString(),
  html: {
    candidates: htmlResult.candidates.length,
    decisions: htmlDecisions.length,
    skipped_existing: htmlResult.candidates.filter(c => c.existing_nac_id).length,
    skipped_low_conf: htmlResult.candidates.filter(c => !c.existing_nac_id && c.confidence < htmlThreshold).length,
    confidence_histogram: bucket(htmlResult.candidates.map(c => c.confidence)),
  },
  js: {
    candidates: jsResult.candidates.length,
    decisions: jsDecisions.length,
    skipped_existing: jsResult.candidates.filter(c => c.already_decorated).length,
    dynamic_ids_detected: jsResult.candidates.filter(c => c.dynamic_id_expr).length,
    confidence_histogram: bucket(jsResult.candidates.map(c => c.confidence)),
  },
};
await fs.writeFile(path.join(dstDir, '_forge_report.json'), JSON.stringify(report, null, 2), 'utf-8');
console.log(`  wrote _forge_report.json`);

function bucket(arr) {
  const b = { '0.0-0.5': 0, '0.5-0.7': 0, '0.7-0.85': 0, '0.85-1.0': 0 };
  for (const v of arr) {
    if (v < 0.5) b['0.0-0.5']++;
    else if (v < 0.7) b['0.5-0.7']++;
    else if (v < 0.85) b['0.7-0.85']++;
    else b['0.85-1.0']++;
  }
  return b;
}

console.log('\nDONE');
