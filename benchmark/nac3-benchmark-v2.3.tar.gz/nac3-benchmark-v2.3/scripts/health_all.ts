import 'dotenv/config';
import { modelHealthCheck } from '../src/conditions/llm.js';

const MODELS = [
  'claude-sonnet-4-6',
  'claude-haiku-4-5',
  'gemini-3.1-flash-lite',
  'deepseek-chat',
  'llama-3.3-70b-versatile',
  'meta-llama/llama-4-scout-17b-16e-instruct',
];

for (const m of MODELS) {
  const r = await modelHealthCheck(m);
  if (r.ok) {
    console.log(`OK    ${m.padEnd(50)} ${r.latency_ms}ms`);
  } else {
    console.log(`SKIP  ${m.padEnd(50)} ${r.latency_ms}ms  reason=${r.reason}`);
  }
}
