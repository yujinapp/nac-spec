import { chromium } from 'playwright';
import { snapshotNac3 } from '../src/conditions/nac3.js';

const browser = await chromium.launch({ headless: true });
const ctx = await browser.newContext();
const page = await ctx.newPage();
await page.goto('http://127.0.0.1:8080/nac3', { waitUntil: 'networkidle' });
await page.waitForTimeout(200);
const snap = await snapshotNac3(page, { lang: 'es' });

// Find the INV-0001.cancel element to verify it has actions[] with args_schema
function find(snap, predicate) {
  if (Array.isArray(snap)) for (const x of snap) { const r = find(x, predicate); if (r) return r; }
  else if (snap && typeof snap === 'object') {
    if (predicate(snap)) return snap;
    for (const k in snap) { const r = find(snap[k], predicate); if (r) return r; }
  }
  return null;
}
const cancelEl = find(snap, (n) => n && n.nac_id === 'invoice_app.invoice.INV-0001.cancel');
console.log('=== invoice_app.invoice.INV-0001.cancel element in snapshot ===');
console.log(JSON.stringify(cancelEl, null, 2));

console.log();
console.log('=== Full snapshot top-level keys ===');
console.log(Object.keys(snap));

console.log();
console.log('=== Snapshot serialized length (chars) ===');
console.log(JSON.stringify(snap).length);

await browser.close();
