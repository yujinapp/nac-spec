import 'dotenv/config';
const apiKey = process.env.GEMINI_API_KEY!;
const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models?key=' + apiKey);
const data = await r.json();
const models = (data.models || []) as any[];
for (const m of models) {
  if (m.name.includes('gemini')) {
    console.log(m.name, '|', (m.supportedGenerationMethods || []).join(','));
  }
}
