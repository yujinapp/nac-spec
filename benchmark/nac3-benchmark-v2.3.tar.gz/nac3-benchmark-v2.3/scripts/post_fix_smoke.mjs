#!/usr/bin/env node
/**
 * Post-fix smoke tests (Fix A/B/C/D validation, 1 iter per cell).
 *
 * Spawns the harness per cell with env vars MODEL + PILOT_CONDITIONS +
 * PILOT_TASK_IDS + PILOT_ITER=1 + PILOT_OUT_DIR=<temp>. Reads the
 * resulting jsonl and runs assertions.
 *
 * Output: per-cell PASS / FAIL with reason. Exit non-zero if any FAIL.
 * Cost target: under US$1 total.
 *
 * Usage:
 *   node scripts/post_fix_smoke.mjs
 */
import { spawnSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BENCH_ROOT = path.resolve(__dirname, '..');

/* The cells we validate. */
const CELLS = [
  {
    name: 'Fix A reasoner cap -- gpt-5.5 on T_MCP4',
    model: 'gpt-5.5',
    conditions: 'nac3',
    tasks: 'T_MCP4_create_invoice_full',
    fix: 'A',
    assertFn: (r) => {
      if (r.error_class === 'parse_error') return { ok: false, why: 'still parse_error post-fix' };
      if (r.truncated_by_cap === true) return { ok: false, why: 'truncated_by_cap=true; cap insufficient' };
      if (!r.output_tokens || r.output_tokens === 0) return { ok: false, why: 'output_tokens=0' };
      return { ok: true, why: `tok_out=${r.output_tokens}, cap_ok` };
    },
  },
  {
    name: 'Fix A reasoner cap -- o4-mini on T_MCP4',
    model: 'o4-mini',
    conditions: 'nac3',
    tasks: 'T_MCP4_create_invoice_full',
    fix: 'A',
    assertFn: (r) => {
      if (r.error_class === 'parse_error') return { ok: false, why: 'still parse_error post-fix' };
      if (r.truncated_by_cap === true) return { ok: false, why: 'truncated_by_cap=true; cap insufficient' };
      if (!r.output_tokens || r.output_tokens === 0) return { ok: false, why: 'output_tokens=0' };
      return { ok: true, why: `tok_out=${r.output_tokens}, cap_ok` };
    },
  },
  {
    name: 'Fix B V23 async tolerance -- opus on V23_EDITOR',
    model: 'claude-opus-4-7',
    conditions: 'nac3',
    tasks: 'T_V23_EDITOR_fix_monitor',
    fix: 'B',
    assertFn: (r) => {
      if (r.success === true) return { ok: true, why: 'V23 success post async-poll fix' };
      /* Acceptable fallback: failure reason changed away from
         "no line description changed". The previous failure mode was
         the timing artifact; any OTHER failure reason still validates
         that the fix removed the artifact (real model issue exposed). */
      const det = (r.postcondition_detail || '').toLowerCase();
      if (/no line description changed/.test(det)) {
        return { ok: false, why: 'still failing with "no line description changed" -- async fix did not catch it' };
      }
      return { ok: true, why: `failed but with different reason: "${det.slice(0, 80)}" (fix B removed the timing artifact)` };
    },
  },
  {
    name: 'Fix C anti-halt MCP -- gpt-4o-mini T1',
    model: 'gpt-4o-mini',
    conditions: 'mcp',
    tasks: 'T1_add_monitor',
    fix: 'C',
    assertFn: (r) => {
      if (r.success === true && r.asked_human === false) {
        return { ok: true, why: 'success + did not halt for human' };
      }
      if (r.asked_human === true) {
        return { ok: false, why: `still halted for human: "${(r.parsed_message || '').slice(0, 80)}"` };
      }
      /* asked_human=false but success=false is a real failure (not the halt
         pattern). Acceptable for the smoke -- the fix removed the halt path,
         the remaining failure is signal not artefact. */
      return { ok: true, why: 'no halt; failed for other reasons (genuine task failure, not halt artifact)' };
    },
  },
  {
    name: 'Fix C anti-halt MCP -- Haiku T_MCP1',
    model: 'claude-haiku-4-5',
    conditions: 'mcp',
    tasks: 'T_MCP1_cancel_oldest_pending',
    fix: 'C',
    assertFn: (r) => {
      if (r.success === true && r.asked_human === false) {
        return { ok: true, why: 'success + did not halt for confirmation' };
      }
      if (r.asked_human === true) {
        return { ok: false, why: `still halted for human: "${(r.parsed_message || '').slice(0, 80)}"` };
      }
      return { ok: true, why: 'no halt; non-halt failure mode' };
    },
  },
];

/* Universal Fix D check (every cell). */
function fixDCheck(r) {
  const allowed = ['none', 'filtered', 'reached_failed', 'reached_succeeded'];
  if (!allowed.includes(r.hallucination_category)) {
    return { ok: false, why: `hallucination_category="${r.hallucination_category}" (not in enum)` };
  }
  if (r.hallucinated_target === true && r.hallucination_category === 'none') {
    return { ok: false, why: 'hallucinated_target=true but category=none (classify bug)' };
  }
  if (r.hallucinated_target === false && r.hallucination_category !== 'none') {
    return { ok: false, why: 'no halluc but category != none (classify bug)' };
  }
  return { ok: true, why: `cat=${r.hallucination_category}` };
}

function runCell(cell) {
  const out = mkdtempSync(path.join(tmpdir(), 'nac3smoke-'));
  const env = {
    ...process.env,
    MODEL: cell.model,
    PILOT_CONDITIONS: cell.conditions,
    PILOT_TASK_IDS: cell.tasks,
    PILOT_ITER: '1',
    PILOT_OUT_DIR: out,
  };
  const res = spawnSync('npx', ['tsx', 'src/harness_3way.ts'], {
    cwd: BENCH_ROOT,
    env,
    stdio: ['ignore', 'pipe', 'pipe'],
    encoding: 'utf-8',
    shell: true,
  });
  if (res.status !== 0) {
    return { error: `harness exit ${res.status}: ${(res.stderr || '').slice(-400)}`, tmp: out };
  }
  /* harness drops the jsonl directly inside PILOT_OUT_DIR */
  let files = [];
  try { files = readdirSync(out).filter(f => f.endsWith('.jsonl')); } catch (_) {}
  if (files.length === 0) {
    return { error: 'no jsonl produced', tmp: out, stdout: (res.stdout || '').slice(-400) };
  }
  const fp = path.join(out, files[0]);
  const lines = readFileSync(fp, 'utf-8').split('\n').filter(Boolean);
  const records = lines.map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  return { records, tmp: out };
}

let pass = 0, fail = 0;
const report = [];

for (const cell of CELLS) {
  process.stdout.write(`\n>> ${cell.name} ... `);
  const t0 = Date.now();
  const { records, error, tmp } = runCell(cell);
  const ms = Date.now() - t0;
  if (error) {
    fail++;
    report.push({ cell: cell.name, status: 'FAIL', why: `harness error: ${error}`, ms });
    process.stdout.write(`FAIL (${ms}ms)\n   ${error}\n`);
    continue;
  }
  if (!records || records.length === 0) {
    fail++;
    report.push({ cell: cell.name, status: 'FAIL', why: 'no records', ms });
    process.stdout.write(`FAIL (${ms}ms)\n   no records produced\n`);
    continue;
  }
  const r = records[records.length - 1];
  const fixAssert = cell.assertFn(r);
  const dAssert = fixDCheck(r);
  if (fixAssert.ok && dAssert.ok) {
    pass++;
    report.push({ cell: cell.name, status: 'PASS', why: `${fixAssert.why} | ${dAssert.why}`, ms });
    process.stdout.write(`PASS (${ms}ms)\n   fix${cell.fix}: ${fixAssert.why}\n   fixD: ${dAssert.why}\n`);
  } else {
    fail++;
    const reasons = [];
    if (!fixAssert.ok) reasons.push(`fix${cell.fix} FAIL: ${fixAssert.why}`);
    if (!dAssert.ok) reasons.push(`fixD FAIL: ${dAssert.why}`);
    report.push({ cell: cell.name, status: 'FAIL', why: reasons.join(' | '), ms });
    process.stdout.write(`FAIL (${ms}ms)\n   ${reasons.join('\n   ')}\n`);
    /* dump useful payload */
    process.stdout.write(`   model=${r.model_id} cond=${r.condition} task=${r.task_id}\n`);
    process.stdout.write(`   success=${r.success} error_class=${r.error_class} tok_out=${r.output_tokens} truncated_by_cap=${r.truncated_by_cap}\n`);
    process.stdout.write(`   asked_human=${r.asked_human} halluc_cat=${r.hallucination_category} parsed_message="${(r.parsed_message || '').slice(0, 120)}"\n`);
    process.stdout.write(`   postcondition_detail="${(r.postcondition_detail || '').slice(0, 120)}"\n`);
  }
  /* clean up temp dir */
  try { rmSync(tmp, { recursive: true, force: true }); } catch (_) {}
}

console.log('\n=================================================');
console.log(`SMOKE RESULT: ${pass} pass / ${fail} fail / ${CELLS.length} total`);
console.log('=================================================');
process.exit(fail === 0 ? 0 : 1);
