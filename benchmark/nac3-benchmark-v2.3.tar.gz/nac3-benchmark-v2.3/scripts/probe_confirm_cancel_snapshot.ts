/**
 * Probe: what does the agent see for confirm_cancel in the T_MCP1 setup
 * state? Reproduces what nac3.ts::snapshotNac3() returns to the agent --
 * the exact JSON Sonnet reads -- WITHOUT calling any LLM.
 */
import { chromium } from 'playwright';
import { snapshotNac3 } from '../src/conditions/nac3.js';

(async () => {
  const url = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';
  await fetch(url + '/api/reset', { method: 'POST' });
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto(url + '/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);

  const snap = await snapshotNac3(page, { lang: 'es' });

  // Extract the confirm_cancel plugin entries.
  const cc = (snap.plugins || []).find((p: any) => p.plugin_slug === 'confirm_cancel');
  console.log('=== confirm_cancel plugin block in snapshot ===');
  console.log(JSON.stringify(cc, null, 2));
  console.log();

  // Also pick the invoice_app cancel buttons (per-invoice).
  const ia = (snap.plugins || []).find((p: any) => p.plugin_slug === 'invoice_app');
  const cancelEls = ((ia && ia.elements) || []).filter((e: any) =>
    /\.cancel($|\b)/.test(e.nac_id || '')
  );
  console.log('=== invoice_app cancel elements (first 3) ===');
  console.log(JSON.stringify(cancelEls.slice(0, 3), null, 2));
  console.log();

  // Look for any "args" / "confirm" hints on cancel verbs.
  const allEls = (snap.plugins || []).flatMap((p: any) => p.elements || []);
  const verbsMentioningConfirm = allEls.filter((e: any) => {
    const s = JSON.stringify(e || {});
    return /confirm/i.test(s) && /cancel/i.test(s);
  });
  console.log('=== elements whose JSON mentions both cancel + confirm ===');
  console.log(`  count: ${verbsMentioningConfirm.length}`);
  if (verbsMentioningConfirm.length) {
    console.log(JSON.stringify(verbsMentioningConfirm.slice(0, 4), null, 2));
  }

  // Top-level shape: what plugins exist and their visibility?
  console.log();
  console.log('=== plugins present in snapshot ===');
  for (const p of (snap.plugins || [])) {
    const slug = p.plugin_slug || p.slug || p.plugin || '(no-slug)';
    const els = p.elements || [];
    const vis = els.filter((e: any) => e.visible !== false).length;
    const hidden = els.length - vis;
    console.log(`  ${String(slug).padEnd(30)} elements=${els.length}  visible=${vis}  hidden=${hidden}`);
    // dump first 2 element nac_ids of each plugin for quick eyeballing
    const sample = els.slice(0, 3).map((e: any) => `${e.nac_id}(vis=${e.visible !== false})`);
    if (sample.length) console.log(`     samples: ${sample.join(', ')}`);
  }

  await ctx.close();
  await browser.close();
})();
