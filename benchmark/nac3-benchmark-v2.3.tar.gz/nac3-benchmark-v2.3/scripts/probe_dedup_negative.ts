/* Negative test: inject a third invoice_app root without instance-id
   and verify the runtime catches it.  */
import { chromium } from 'playwright';
(async () => {
  const b = await chromium.launch({ headless: true });
  const p = await b.newPage();
  const fatals: any[] = [];
  p.on('pageerror', (e) => fatals.push({ kind: 'pageerror', msg: e.message }));
  await p.goto('http://127.0.0.1:8080/nac3');
  await p.waitForTimeout(500);
  const r = await p.evaluate(() => {
    const w: any = window;
    /* Inject a third root with the same slug, no instance-id. */
    const evil = document.createElement('div');
    evil.setAttribute('data-nac-plugin', 'invoice_app');
    document.body.appendChild(evil);
    /* Then call register() to trigger the synchronous gate. */
    try {
      w.NAC.register({
        plugin_slug: 'invoice_app',
        version: '1.0.0',
        elements: [],
      });
      return { register_threw: false };
    } catch (e: any) {
      return {
        register_threw: true,
        code: e.code,
        message: (e.message || '').slice(0, 200),
      };
    }
  });
  console.log(JSON.stringify({ register_result: r, fatals }, null, 2));
  await b.close();
})();
