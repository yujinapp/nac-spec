/* Dump the full plugin list with element counts + check if the same
   plugin_slug appears twice in NAC.describe(). Also check for any
   verb declaration that takes args:{confirm:true} on the cancel
   buttons (the H.3 atomic alternative). */
import { chromium } from 'playwright';

(async () => {
  const url = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';
  await fetch(url + '/api/reset', { method: 'POST' });
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto(url + '/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);

  const raw = await page.evaluate(() => {
    const w = window as any;
    const base = w.NAC.describe();
    return base;
  });

  console.log('=== NAC.describe().plugins[*].plugin_slug counts ===');
  const counts: Record<string, number> = {};
  for (const p of (raw.plugins || [])) {
    const slug = p.plugin_slug || p.slug || p.plugin || '(unknown)';
    counts[slug] = (counts[slug] || 0) + 1;
  }
  for (const k of Object.keys(counts).sort()) console.log(`  ${k.padEnd(30)} x${counts[k]}`);

  // Look at all invoice_app entries side-by-side.
  console.log();
  console.log('=== invoice_app entries side by side ===');
  const all_ia = (raw.plugins || []).filter((p: any) =>
    (p.plugin_slug || p.slug || p.plugin) === 'invoice_app');
  all_ia.forEach((p: any, i: number) => {
    const els = p.elements || [];
    console.log(`-- entry #${i}: version=${p.version}  els=${els.length}  visible=${els.filter((e: any)=>e.visible!==false).length}  hidden=${els.filter((e: any)=>e.visible===false).length}`);
    const cancelEls = els.filter((e: any) => /\.cancel$/.test(e.nac_id || ''));
    cancelEls.slice(0, 4).forEach((e: any) => console.log(`     ${e.nac_id}  visible=${e.visible}`));
  });

  // Look for any registered verb that takes args:{confirm:true} on cancel buttons.
  console.log();
  console.log('=== H.3 atomic alternative -- any cancel verb declaring args.confirm? ===');
  const allEls = (raw.plugins || []).flatMap((p: any) => (p.elements || []).map((e: any) => ({...e, _plugin: p.plugin_slug || p.slug || p.plugin})));
  const verbsWithArgs = allEls.filter((e: any) =>
    e.nac_id && /\.cancel$/.test(e.nac_id) &&
    (JSON.stringify(e.actions || []).includes('confirm') ||
     JSON.stringify(e.actions || []).includes('args')));
  console.log('  count:', verbsWithArgs.length);
  if (verbsWithArgs.length) console.log(JSON.stringify(verbsWithArgs.slice(0, 2), null, 2));
  else console.log('  -> NO atomic cancel_with_confirm verb in manifest. H.3 alternative is NOT WIRED.');

  await ctx.close();
  await browser.close();
})();
