import 'dotenv/config';
import { GoogleGenerativeAI } from '@google/generative-ai';
const g = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
const candidates = ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-flash-latest', 'gemini-1.5-flash', 'gemini-1.5-pro'];
for (const m of candidates) {
  try {
    const r = await g.getGenerativeModel({ model: m }).generateContent('say hi');
    console.log(m, 'OK', r.response.text().slice(0,30));
  } catch (e: any) {
    console.log(m, 'FAIL', (e.message || '').slice(0, 80));
  }
}
