import 'dotenv/config';
import { GoogleGenerativeAI } from '@google/generative-ai';
const g = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
const candidates = ['gemini-3.1-flash', 'gemini-3.0-flash', 'gemini-3-flash', 'gemini-3.1-pro', 'gemini-3.0-pro', 'gemini-3-pro'];
for (const m of candidates) {
  try {
    const r = await g.getGenerativeModel({ model: m }).generateContent('say hi');
    console.log(m, 'OK', r.response.text().slice(0,30));
  } catch (e: any) {
    console.log(m, 'FAIL', (e.message || '').slice(0, 80));
  }
}
