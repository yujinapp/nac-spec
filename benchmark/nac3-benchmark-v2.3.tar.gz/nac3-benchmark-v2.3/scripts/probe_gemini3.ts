import 'dotenv/config';
import { GoogleGenerativeAI } from '@google/generative-ai';
const g = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
const candidates = ['gemini-3-flash-preview', 'gemini-3.1-flash-lite', 'gemini-3.1-flash-lite-preview', 'gemini-3.1-pro-preview'];
for (const m of candidates) {
  try {
    const r = await g.getGenerativeModel({ model: m }).generateContent('say hi in 5 words');
    console.log(m, 'OK', r.response.text().slice(0,40));
  } catch (e: any) {
    console.log(m, 'FAIL', (e.message || '').slice(0, 80));
  }
}
