import 'dotenv/config';

async function probe(model: string) {
  const t0 = Date.now();
  try {
    const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + process.env.GROK_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: 'reply with the single character K' }],
        max_tokens: 4,
        temperature: 0,
      }),
    });
    const ms = Date.now() - t0;
    const text = await r.text();
    if (!r.ok) {
      console.log(`[groq] ${model}: HTTP ${r.status}  (${ms}ms)  ${text.slice(0, 160)}`);
      return;
    }
    const body: any = JSON.parse(text);
    const reply = body?.choices?.[0]?.message?.content || '';
    const usage = body?.usage || {};
    console.log(`[groq] ${model}: OK (${ms}ms)  reply="${reply.slice(0, 30)}"  in=${usage.prompt_tokens} out=${usage.completion_tokens}`);
  } catch (e: any) {
    console.log(`[groq] ${model}: NET_ERROR  ${e.message || e.code}`);
  }
}

// Top Groq free models (popular ones, well-known)
const models = [
  'llama-3.3-70b-versatile',
  'llama-3.1-8b-instant',
  'meta-llama/llama-4-maverick-17b-128e-instruct',
  'meta-llama/llama-4-scout-17b-16e-instruct',
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'moonshotai/kimi-k2-instruct-0905',
  'qwen/qwen3-32b',
  'deepseek-r1-distill-llama-70b',
];

for (const m of models) await probe(m);
