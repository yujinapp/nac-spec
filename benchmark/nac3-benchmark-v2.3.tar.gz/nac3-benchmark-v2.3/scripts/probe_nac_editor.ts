import { chromium } from 'playwright';

(async () => {
  const b = await chromium.launch({ headless: true });
  const p = await b.newPage();
  await p.goto('http://127.0.0.1:8080/nac3');
  await p.waitForTimeout(800);
  const r = await p.evaluate(() => {
    const w: any = window;
    if (!w.NAC || typeof w.NAC.describe !== 'function') return { error: 'NAC not loaded' };
    const d = w.NAC.describe();
    const out: any = { n_plugins: (d.plugins||[]).length, plugins: [] };
    out.plugins = (d.plugins || []).map((p: any) => ({
      plugin: p.plugin,
      n_elements: (p.elements || []).length,
      element_ids: (p.elements || []).map((e: any) => e.nac_id || e.id).slice(0, 30),
    }));
    for (const pl of (d.plugins || [])) {
      if (pl.plugin !== 'invoice_edit_modal') continue;
      for (const e of (pl.elements || [])) {
        if ((e.nac_id || e.id) === 'invoice_edit_modal.edit_description') {
          out.target_lookup = e;
        }
      }
    }
    for (const pl of (d.plugins || [])) {
      if (pl.plugin !== 'nac_editor') continue;
      for (const e of (pl.elements || [])) {
        if ((e.nac_id || e.id) === 'nac_editor.ai_correct_syntax') {
          out.ai_lookup = e;
        }
      }
    }
    return out;
  });
  console.log(JSON.stringify(r, null, 2));
  await b.close();
})();
