import { chromium } from 'playwright';
(async () => {
  const b = await chromium.launch({ headless: true });
  const p = await b.newPage();
  await p.goto('http://127.0.0.1:8080/nac3');
  await p.waitForTimeout(800);
  const r = await p.evaluate(() => {
    const w: any = window;
    if (!w.NAC) return { error: 'NAC not loaded' };
    /* Count roots per slug. */
    const roots: any = {};
    document.querySelectorAll('[data-nac-plugin]').forEach((el) => {
      const slug = el.getAttribute('data-nac-plugin');
      if (!slug) return;
      if (!roots[slug]) roots[slug] = [];
      roots[slug].push(el.getAttribute('data-nac-plugin-id') || '<none>');
    });
    let validation: any = { skipped: 'no validate_global' };
    if (typeof w.NAC.validate_global === 'function') {
      try {
        const v = w.NAC.validate_global();
        const findings = (v.findings || []).filter((f: any) =>
          f.code === 'duplicate_plugin_no_instance_id');
        validation = { has_errors: v.has_errors, our_finding_count: findings.length, sample: findings[0] };
      } catch (e: any) { validation = { error: e.message }; }
    }
    return { roots_per_slug: roots, validation };
  });
  console.log(JSON.stringify(r, null, 2));
  await b.close();
})();
