import { chromium } from 'playwright';
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.request.post('http://127.0.0.1:8080/api/reset');
  // Don't open modal: T_MCP1 setup
  await page.goto('http://127.0.0.1:8080/nac3', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const data = await page.evaluate(() => {
    const d = (window as any).NAC.describe();
    const inv = d.plugins.find((p: any) => p.plugin === 'invoice_edit_modal');
    return {
      modal_state: document.querySelector('#invoice-modal')?.getAttribute('data-state'),
      elements_total: (inv?.elements || []).length,
      visible_true: (inv?.elements || []).filter((e: any) => e.visible).length,
      visible_false: (inv?.elements || []).filter((e: any) => e.visible === false).length,
      sample_hidden: (inv?.elements || []).find((e: any) => e.visible === false),
      sample_visible: (inv?.elements || []).find((e: any) => e.visible === true),
    };
  });
  console.log(JSON.stringify(data, null, 2));
  await browser.close();
})();
