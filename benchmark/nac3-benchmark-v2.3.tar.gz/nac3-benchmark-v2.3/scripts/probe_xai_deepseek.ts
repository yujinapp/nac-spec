import 'dotenv/config';

async function probe(name: string, baseURL: string, apiKey: string, candidates: string[]) {
  for (const model of candidates) {
    const t0 = Date.now();
    try {
      const r = await fetch(baseURL + '/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: 'reply with the single character K' }],
          max_tokens: 4,
          temperature: 0,
        }),
      });
      const ms = Date.now() - t0;
      const text = await r.text();
      if (!r.ok) {
        console.log(`[${name}] ${model}: HTTP ${r.status}  (${ms}ms)  ${text.slice(0, 160)}`);
        continue;
      }
      let body: any = {};
      try { body = JSON.parse(text); } catch (_) {}
      const reply = body?.choices?.[0]?.message?.content || '';
      const usage = body?.usage || {};
      console.log(`[${name}] ${model}: OK (${ms}ms)  reply="${reply.slice(0, 30)}"  in=${usage.prompt_tokens} out=${usage.completion_tokens}`);
    } catch (e: any) {
      console.log(`[${name}] ${model}: NET_ERROR (${Date.now()-t0}ms)  ${(e.message || e.code || '').slice(0, 120)}`);
    }
  }
}

await probe('xai', 'https://api.x.ai/v1', process.env.GROK_API_KEY!,
  ['grok-3', 'grok-4', 'grok-3-mini', 'grok-code-fast', 'grok-beta']);

await probe('deepseek', 'https://api.deepseek.com/v1', process.env.DEEPSEEK_API_KEY!,
  ['deepseek-chat', 'deepseek-reasoner']);
