#!/bin/bash
# Targeted re-run de los 36 cells faltantes/api_error en N10_final
# (post recarga Anthropic 2026-05-20).
# Output: results/N10_final/ (mismo dir, jsonl nuevos con timestamp distinto).
# unified_report dedupea por (model, iter, cond, task) preferring non-api_error.
set -e
OUT="${OUT:-results/N10_final}"

# (model, iter, conds, tasks)
declare -a JOBS=(
  "claude-haiku-4-5|8|nac3,raw|T1_add_monitor,T_MCP1_cancel_oldest_pending,T_MCP4_create_invoice_full,T_V23_EDITOR_fix_monitor"
  "claude-haiku-4-5|9|nac3,raw|T1_add_monitor,T_MCP1_cancel_oldest_pending,T_MCP4_create_invoice_full,T_V23_EDITOR_fix_monitor"
  "claude-sonnet-4-6|8|nac3,raw|T_V23_EDITOR_fix_monitor"
  "claude-sonnet-4-6|9|nac3,raw|T1_add_monitor,T_MCP1_cancel_oldest_pending,T_MCP4_create_invoice_full,T_V23_EDITOR_fix_monitor"
  "gpt-4o-mini|9|nac3,raw,mcp|T1_add_monitor,T_MCP1_cancel_oldest_pending,T_MCP4_create_invoice_full,T_V23_EDITOR_fix_monitor"
)

for spec in "${JOBS[@]}"; do
  IFS='|' read -r M ITER CONDS TASKS <<< "$spec"
  echo "=================================================================="
  echo "RERUN  model=$M  iter=$ITER  conds=$CONDS  tasks=$TASKS"
  echo "=================================================================="
  PILOT_CONDITIONS="$CONDS" \
    PILOT_TASK_IDS="$TASKS" \
    PILOT_ITER=1 \
    PILOT_ITER_OFFSET="$ITER" \
    PILOT_OUT_DIR="$OUT" \
    MODEL="$M" \
    npx tsx src/harness_3way.ts || true
  echo
done

echo "RERUN DONE -- $(ls $OUT/*.jsonl 2>/dev/null | wc -l) jsonl files total"
