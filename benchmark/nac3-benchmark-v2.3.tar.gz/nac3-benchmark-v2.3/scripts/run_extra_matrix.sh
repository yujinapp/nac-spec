#!/bin/bash
# Second corrida: 4 extra models (Haiku, DeepSeek, Gemini Flash Lite,
# o4-mini). Same 5 conditions x 4 tasks x N iter.
#
# Usage:
#   ITER=1  bash scripts/run_extra_matrix.sh   (paso 9 extra)

set -e
ITER="${ITER:-1}"
CONDITIONS="${CONDITIONS:-nac3,raw,mcp}"  # Forge variants excluded for this corrida (per user 2026-05-19)

MODELS=(
  "claude-haiku-4-5"
  "deepseek-chat"
  "gemini-3.1-flash-lite"
  "o4-mini"
)

for M in "${MODELS[@]}"; do
  echo "=================================================================="
  echo "RUN model=$M  conditions=$CONDITIONS  iter=$ITER"
  echo "=================================================================="
  PILOT_CONDITIONS="$CONDITIONS" PILOT_ITER="$ITER" MODEL="$M" \
    npx tsx src/harness_3way.ts || true
  echo
done

echo "ALL EXTRA DONE -- results in results/pilot_3way/raw/"
