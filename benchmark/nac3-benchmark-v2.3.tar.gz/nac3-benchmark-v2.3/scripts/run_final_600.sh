#!/bin/bash
# Final corrida 600 runs (2026-05-19): publication-ready dataset.
# 5 models x 3 cond x 4 task x 10 iter = 600 runs.
# Roster per benchmark_final_consolidated.md sec 4.1.
# Order per iteration cross-model (anti-sesgo temporal).
# Output: results/N10_final/
set -e
CONDITIONS="${CONDITIONS:-nac3,raw,mcp}"
FINAL_OUT="${FINAL_OUT:-results/N10_final}"
mkdir -p "$FINAL_OUT"

MODELS=(
  "claude-sonnet-4-6"
  "claude-haiku-4-5"
  "deepseek-chat"
  "gemini-3.1-flash-lite"
  "gpt-4o-mini"
)

NUM_ITER="${NUM_ITER:-10}"

for ((k=0; k<NUM_ITER; k++)); do
  for M in "${MODELS[@]}"; do
    echo "=================================================================="
    echo "N10_FINAL -- iter=$k  model=$M  conditions=$CONDITIONS"
    echo "=================================================================="
    PILOT_CONDITIONS="$CONDITIONS" PILOT_ITER=1 PILOT_ITER_OFFSET="$k" \
      PILOT_OUT_DIR="$FINAL_OUT" MODEL="$M" \
      npx tsx src/harness_3way.ts || true
    echo
  done
done

echo "N10_FINAL DONE -- $(ls $FINAL_OUT/*.jsonl 2>/dev/null | wc -l) jsonl files"
