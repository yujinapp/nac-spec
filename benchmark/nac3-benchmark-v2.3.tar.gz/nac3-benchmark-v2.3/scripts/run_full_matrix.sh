#!/bin/bash
# Paso 9/10: full matrix over 5 conditions x 4 models x N iter.
# Usage:
#   ITER=1  bash scripts/run_full_matrix.sh   (paso 9)
#   ITER=10 bash scripts/run_full_matrix.sh   (paso 10)

set -e
ITER="${ITER:-1}"
CONDITIONS="${CONDITIONS:-nac3,raw,mcp,nac3-walker-silent,nac3-walker-assisted}"

MODELS=(
  "claude-sonnet-4-6"
  "claude-opus-4-7"
  "gpt-5.5"
  "gpt-4o-mini"
)

mkdir -p results/full_matrix

for M in "${MODELS[@]}"; do
  echo "=================================================================="
  echo "RUN model=$M  conditions=$CONDITIONS  iter=$ITER"
  echo "=================================================================="
  PILOT_CONDITIONS="$CONDITIONS" PILOT_ITER="$ITER" MODEL="$M" \
    npx tsx src/harness_3way.ts || true
  echo
done

echo "ALL DONE -- results in results/pilot_3way/raw/"
