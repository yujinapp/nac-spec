/**
 * Overnight runner: launch N=3 over the 4 reliable models, evaluate
 * whether NAC3 hit 100% across every (task, condition=nac3, model)
 * cell, and if so auto-launch N=15. Both runs land in their own
 * directories (results/pilot_v23_n3, results/pilot_v23_n15) so the
 * aggregator never mixes Ns.
 *
 * Usage:
 *   tsx scripts/run_overnight.ts
 *
 * The pilot orchestrator (run_pilot_v23.ts) handles per-model
 * spawning + aggregation. This script just plumbs the env vars and
 * the auto-fire gate.
 */
import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const RELIABLE_MODELS = [
  'claude-sonnet-4-6',
  'claude-haiku-4-5',
  'gemini-3.1-flash-lite',
  'deepseek-chat',
].join(',');

const N3_DIR  = path.join(ROOT, 'results', 'pilot_v23_n3');
const N15_DIR = path.join(ROOT, 'results', 'pilot_v23_n15');

function spawnPilot(env: NodeJS.ProcessEnv, label: string): Promise<number> {
  return new Promise((resolve) => {
    console.log(`\n========== ${label} ==========`);
    const child = spawn('npx', ['tsx', 'scripts/run_pilot_v23.ts'], {
      cwd: ROOT, env, stdio: 'inherit',
      shell: process.platform === 'win32',
    });
    child.on('exit', (code) => resolve(code || 0));
  });
}

function readAllRuns(rawDir: string): any[] {
  if (!fs.existsSync(rawDir)) return [];
  const runs: any[] = [];
  for (const f of fs.readdirSync(rawDir)) {
    if (!f.endsWith('.jsonl')) continue;
    for (const line of fs.readFileSync(path.join(rawDir, f), 'utf8').split('\n')) {
      if (!line.trim()) continue;
      try { runs.push(JSON.parse(line)); } catch { /* skip */ }
    }
  }
  return runs;
}

function nac3GateClean(runs: any[], expectedIterPerCell: number): {
  clean: boolean;
  cells: Array<{ task: string; model: string; succ: number; n: number }>;
} {
  const reliable = RELIABLE_MODELS.split(',');
  const tasks = Array.from(new Set(runs.map(r => r.task_id))).sort();
  const cells: Array<{ task: string; model: string; succ: number; n: number }> = [];
  let clean = true;
  for (const task of tasks) {
    for (const m of reliable) {
      const rs = runs.filter(r =>
        r.task_id === task &&
        r.condition === 'nac3' &&
        r.model_id === m);
      const succ = rs.filter(r => r.success).length;
      cells.push({ task, model: m, succ, n: rs.length });
      if (rs.length < expectedIterPerCell || succ < rs.length) clean = false;
    }
  }
  return { clean, cells };
}

async function main() {
  /* --- Stage 1: N=3 --- */
  if (fs.existsSync(N3_DIR)) {
    console.log(`Wiping ${N3_DIR} so the aggregator starts clean.`);
    fs.rmSync(N3_DIR, { recursive: true, force: true });
  }
  const t0 = Date.now();
  await spawnPilot({
    ...process.env,
    PILOT_MODELS: RELIABLE_MODELS,
    PILOT_ITER: '3',
    PILOT_V23_DIR: N3_DIR,
  }, 'STAGE 1: N=3 on 4 reliable models');
  const n3Runs = readAllRuns(path.join(N3_DIR, 'raw'));
  const gate3 = nac3GateClean(n3Runs, 3);
  console.log(`\n=== N=3 gate evaluation ===`);
  console.log(`Total runs: ${n3Runs.length}`);
  for (const c of gate3.cells) {
    console.log(`  nac3 | ${c.task.padEnd(36)} | ${c.model.padEnd(22)} | ${c.succ}/${c.n}`);
  }
  console.log(`Gate clean: ${gate3.clean}`);
  console.log(`Stage 1 elapsed: ${((Date.now() - t0) / 1000).toFixed(0)}s`);

  /* Persist gate result so a human can see it later. */
  fs.writeFileSync(path.join(N3_DIR, 'gate_decision.json'), JSON.stringify({
    gate_passed: gate3.clean,
    cells: gate3.cells,
    decided_at: new Date().toISOString(),
    next_stage: gate3.clean ? 'N=15 auto-fired' : 'N=15 SKIPPED (gate failed)',
  }, null, 2));

  if (!gate3.clean) {
    console.log(`\nGate FAILED -- not auto-firing N=15. See ${N3_DIR}/summary.md for drop detail.`);
    return;
  }

  /* --- Stage 2: N=15 --- */
  if (fs.existsSync(N15_DIR)) {
    console.log(`Wiping ${N15_DIR} so the aggregator starts clean.`);
    fs.rmSync(N15_DIR, { recursive: true, force: true });
  }
  const t1 = Date.now();
  await spawnPilot({
    ...process.env,
    PILOT_MODELS: RELIABLE_MODELS,
    PILOT_ITER: '15',
    PILOT_V23_DIR: N15_DIR,
  }, 'STAGE 2: N=15 on 4 reliable models (auto-fired)');
  const n15Runs = readAllRuns(path.join(N15_DIR, 'raw'));
  const gate15 = nac3GateClean(n15Runs, 15);
  console.log(`\n=== N=15 final summary ===`);
  console.log(`Total runs: ${n15Runs.length}`);
  for (const c of gate15.cells) {
    console.log(`  nac3 | ${c.task.padEnd(36)} | ${c.model.padEnd(22)} | ${c.succ}/${c.n}`);
  }
  console.log(`All-clean: ${gate15.clean}`);
  console.log(`Stage 2 elapsed: ${((Date.now() - t1) / 1000).toFixed(0)}s`);
  console.log(`\nTotal overnight elapsed: ${((Date.now() - t0) / 1000).toFixed(0)}s`);

  fs.writeFileSync(path.join(N15_DIR, 'gate_decision.json'), JSON.stringify({
    gate_passed: gate15.clean,
    cells: gate15.cells,
    decided_at: new Date().toISOString(),
  }, null, 2));
}

main().catch((e) => {
  console.error('overnight runner fatal:', e);
  process.exit(1);
});
