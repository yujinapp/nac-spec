#!/bin/bash
# Paso 9 v2 (2026-05-19): re-baseline post-fix A/B/C/D.
# Mirror del paso 9 v1 (8 modelos x 3 cond x 4 task), ITER=1.
# Forge walker conditions excluidas (decisión paso 9 v1, sigue).
#
# Usage:
#   bash scripts/run_paso9_v2.sh
#
# NO escalar a ITER>1 sin OK explícito del operador.
set -e
ITER="${ITER:-1}"
CONDITIONS="${CONDITIONS:-nac3,raw,mcp}"

MODELS=(
  "claude-sonnet-4-6"
  "claude-opus-4-7"
  "claude-haiku-4-5"
  "deepseek-chat"
  "gemini-3.1-flash-lite"
  "gpt-4o-mini"
  "gpt-5.5"
  "o4-mini"
)

for M in "${MODELS[@]}"; do
  echo "=================================================================="
  echo "RUN model=$M  conditions=$CONDITIONS  iter=$ITER"
  echo "=================================================================="
  PILOT_CONDITIONS="$CONDITIONS" PILOT_ITER="$ITER" MODEL="$M" \
    npx tsx src/harness_3way.ts || true
  echo
done

echo "PASO 9 v2 DONE -- results in results/pilot_3way/raw/"
