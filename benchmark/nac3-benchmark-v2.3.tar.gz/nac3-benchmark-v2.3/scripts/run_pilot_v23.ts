/**
 * Pilot v23 multi-model orchestrator.
 *
 * Pipeline:
 *   1. Health check every model via modelHealthCheck(). Classify failures
 *      (auth / billing / rate_limit / network / model_unavailable / unknown).
 *   2. Skip unhealthy models -- log to skipped_models.json but DO NOT emit
 *      empty rows into aggregated.csv. summary.md adds a footnote at the
 *      bottom: "model X skipped: reason=Y".
 *   3. For each healthy model, spawn `tsx src/harness_3way.ts` with
 *      MODEL=<id> env. Each subprocess writes one JSONL into
 *      results/pilot_v23/raw/.
 *   4. After all subprocesses finish, aggregate the JSONLs into
 *      aggregated.csv + mcp_tool_choice.csv. Render summary.md +
 *      sample_run.md. Copy system_prompts.md from the harness output.
 *
 * Usage:
 *   tsx scripts/run_pilot_v23.ts
 *
 * Env honoured:
 *   PILOT_ITER=1   (forwarded to each subprocess)
 *   INVOICE_APP_URL=http://127.0.0.1:8080
 *   PILOT_MODELS=comma,separated   (override the default 6-model list)
 */
import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { modelHealthCheck } from '../src/conditions/llm.js';
import { pricingFor, costUsd } from '../src/pricing.js';
import { includeInAggregate } from '../src/pricing.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const DEFAULT_MODELS = [
  'claude-sonnet-4-6',
  'claude-haiku-4-5',
  'gemini-3.1-flash-lite',
  'deepseek-chat',
  'llama-3.3-70b-versatile',
  'meta-llama/llama-4-scout-17b-16e-instruct',
];

const MODELS = process.env.PILOT_MODELS
  ? process.env.PILOT_MODELS.split(',').map(s => s.trim()).filter(Boolean)
  : DEFAULT_MODELS;

/* PILOT_V23_DIR lets the caller separate runs across different N
   into their own output trees (so the aggregator never mixes N=3
   with N=15). Defaults to results/pilot_v23 for back-compat. */
const OUT_DIR = process.env.PILOT_V23_DIR
  ? path.resolve(process.env.PILOT_V23_DIR)
  : path.join(ROOT, 'results', 'pilot_v23');
const RAW_DIR = path.join(OUT_DIR, 'raw');
const PILOT_ITER = Number(process.env.PILOT_ITER || 1);

function ensureDir(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

interface HealthRow {
  model: string;
  ok: boolean;
  reason?: string;
  latency_ms: number;
}

async function probeAll(): Promise<HealthRow[]> {
  console.log('=== Pre-pilot health check ===');
  const rows: HealthRow[] = [];
  for (const m of MODELS) {
    const r = await modelHealthCheck(m);
    rows.push({ model: m, ok: r.ok, reason: r.reason, latency_ms: r.latency_ms });
    if (r.ok) console.log(`  OK   ${m.padEnd(50)} ${r.latency_ms}ms`);
    else      console.log(`  SKIP ${m.padEnd(50)} ${r.latency_ms}ms  reason=${r.reason}`);
  }
  return rows;
}

function runHarnessForModel(model: string): Promise<{ code: number; jsonlPath: string | null }> {
  return new Promise((resolve) => {
    const env = {
      ...process.env,
      MODEL: model,
      /* harness writes to results/pilot_3way/raw -- we want pilot_v23. */
      PILOT_OUT_DIR: RAW_DIR,
    };
    const child = spawn('npx', ['tsx', 'src/harness_3way.ts'], {
      cwd: ROOT, env, stdio: 'inherit', shell: process.platform === 'win32',
    });
    child.on('exit', (code) => {
      /* The harness writes its file to PILOT_OUT_DIR if respected, or
         to results/pilot_3way/raw/. Find the most recent JSONL touching
         the model id. */
      const modelSlug = model.replace(/[\\/]/g, '_');
      const candidates = [RAW_DIR, path.join(ROOT, 'results', 'pilot_3way', 'raw')]
        .filter(p => fs.existsSync(p))
        .flatMap(d => fs.readdirSync(d).map(f => ({ d, f })))
        .filter(({ f }) => f.endsWith('.jsonl') && f.includes(modelSlug));
      if (candidates.length === 0) {
        resolve({ code: code || 0, jsonlPath: null });
        return;
      }
      candidates.sort((a, b) => {
        const sa = fs.statSync(path.join(a.d, a.f)).mtimeMs;
        const sb = fs.statSync(path.join(b.d, b.f)).mtimeMs;
        return sb - sa;
      });
      const top = candidates[0];
      const want = path.join(RAW_DIR, top.f);
      if (path.resolve(top.d) !== path.resolve(RAW_DIR)) {
        fs.copyFileSync(path.join(top.d, top.f), want);
      }
      resolve({ code: code || 0, jsonlPath: want });
    });
  });
}

/* ---- aggregation ---- */

interface RawRun {
  run_id: string;
  task_id: string;
  task_complexity: string;
  condition: 'nac3' | 'raw' | 'mcp';
  model_id: string;
  iteration: number;
  input_tokens: number;
  output_tokens: number;
  total_cost_usd: number;
  llm_latency_ms: number;
  end_to_end_ms: number;
  n_actions_emitted: number;
  success: boolean;
  hallucinated_target: boolean;
  error_class: string;
  /* MCP-only */
  n_model_turns?: number;
  n_tool_calls?: number;
  hit_max_turns?: boolean;
  /* The harness stores per-call records as tool_calls in BaseRunRecord
     (see harness_3way.ts line 88). The shape depends on the trial
     implementation -- we accept any[] and read .name/.ok defensively. */
  tool_calls?: Array<any>;
}

function readAllRawRuns(): RawRun[] {
  if (!fs.existsSync(RAW_DIR)) return [];
  const runs: RawRun[] = [];
  for (const f of fs.readdirSync(RAW_DIR)) {
    if (!f.endsWith('.jsonl')) continue;
    const full = path.join(RAW_DIR, f);
    for (const line of fs.readFileSync(full, 'utf8').split('\n')) {
      if (!line.trim()) continue;
      try { runs.push(JSON.parse(line)); } catch { /* skip malformed */ }
    }
  }
  return runs;
}

function writeAggregatedCsv(runs: RawRun[], healthRows: HealthRow[]) {
  const out = path.join(OUT_DIR, 'aggregated.csv');
  /* Only include rows whose model was healthy. Skipped models do NOT
     contribute empty rows; their absence is documented in summary.md. */
  const healthy = new Set(healthRows.filter(h => h.ok).map(h => h.model));
  const cols = [
    'model_id', 'task_id', 'condition', 'iteration', 'success',
    'hallucinated_target', 'n_actions_emitted', 'input_tokens',
    'output_tokens', 'total_cost_usd', 'llm_latency_ms', 'end_to_end_ms',
    'n_model_turns', 'n_tool_calls', 'hit_max_turns', 'error_class',
  ];
  const lines = [cols.join(',')];
  for (const r of runs) {
    if (!healthy.has(r.model_id)) continue;
    const row = cols.map(c => {
      const v = (r as any)[c];
      if (v == null) return '';
      if (typeof v === 'string') {
        if (v.includes(',') || v.includes('"')) return `"${v.replace(/"/g, '""')}"`;
        return v;
      }
      return String(v);
    });
    lines.push(row.join(','));
  }
  fs.writeFileSync(out, lines.join('\n') + '\n');
  console.log(`  wrote ${out} (${lines.length - 1} rows)`);
}

function writeMcpToolChoiceCsv(runs: RawRun[]) {
  const out = path.join(OUT_DIR, 'mcp_tool_choice.csv');
  const cols = ['model_id', 'task_id', 'iteration', 'tool_name', 'ok'];
  const lines = [cols.join(',')];
  for (const r of runs) {
    if (r.condition !== 'mcp') continue;
    const log = Array.isArray(r.tool_calls) ? r.tool_calls : [];
    for (const t of log) {
      const name = String(t?.name || t?.tool || '');
      const ok = t?.ok != null ? Boolean(t.ok) : (t?.error == null);
      const row = [r.model_id, r.task_id, String(r.iteration), name, String(ok)];
      lines.push(row.map(c => /[,"]/.test(c) ? `"${c.replace(/"/g, '""')}"` : c).join(','));
    }
  }
  fs.writeFileSync(out, lines.join('\n') + '\n');
  console.log(`  wrote ${out} (${lines.length - 1} rows)`);
}

function writeSummaryMd(runs: RawRun[], healthRows: HealthRow[]) {
  const out = path.join(OUT_DIR, 'summary.md');
  const healthy = new Set(healthRows.filter(h => h.ok).map(h => h.model));
  /* v2.4 (2026-05-19): filter Llamas (excluded_from_aggregate) out of
     the aggregate tables. They still appear in the per-model table
     below with a note, so the report keeps the "we tried, the
     provider rate-limited us" trace without contaminating averages. */
  const inAggregate = (m: string) => healthy.has(m) && includeInAggregate(m);
  const filtered = runs.filter(r => inAggregate(r.model_id));

  const tasks = Array.from(new Set(filtered.map(r => r.task_id))).sort();
  const conds: Array<'nac3' | 'raw' | 'mcp'> = ['nac3', 'raw', 'mcp'];
  const models = Array.from(new Set(filtered.map(r => r.model_id))).sort();
  const excludedModels = Array.from(new Set(runs.map(r => r.model_id)))
    .filter(m => healthy.has(m) && !includeInAggregate(m))
    .sort();

  function bucket(taskId: string, model: string, cond: 'nac3' | 'raw' | 'mcp') {
    return filtered.filter(r => r.task_id === taskId && r.model_id === model && r.condition === cond);
  }

  const md: string[] = [];
  md.push('# NAC3 pilot v23 -- 4 tasks x 3 conditions x N models');
  md.push(`N (iterations per cell): ${PILOT_ITER}`);
  md.push('');
  md.push('## Design decisions (T-V23-EDITOR)');
  md.push('');
  md.push('Two judgement calls baked into the v2.3 field-editor scenario:');
  md.push('');
  md.push('1. **Parameterised verb for NAC3.** The manifest exposes a single');
  md.push('   `invoice_edit_modal.edit_description` action that takes');
  md.push('   `{row_id}` instead of pre-registering N per-row stamps.');
  md.push('   At 50 lines an enumerated manifest would balloon the snapshot');
  md.push('   (~50 extra elements, ~3 kB tokens) for no semantic gain. The');
  md.push('   v2.3 parameterised-verb path keeps the manifest flat and lets');
  md.push('   the agent address any row with one verb + payload. The host');
  md.push('   handler resolves the row at click time and calls');
  md.push('   `NAC.edit_field` on the just-stamped input.');
  md.push('');
  md.push('2. **Raw with inline editing.** The raw variant ships a textarea');
  md.push('   per row + a "Corregir gramatica" button next to it. No modal');
  md.push('   wrapper. POST /api/grammar-fix with `{invoice_id, line_id}`');
  md.push('   shares the same deterministic GRAMMAR_FIXES stub the NAC3');
  md.push('   path uses. This keeps the raw baseline as the minimum');
  md.push('   credible UI rather than a strawman modal that nobody would');
  md.push('   actually build for inline corrections.');
  md.push('');
  md.push('## Pre-pilot health check');
  md.push('');
  md.push('| Model | Status | Latency | Reason (if skipped) |');
  md.push('|---|---|---:|---|');
  for (const h of healthRows) {
    md.push(`| ${h.model} | ${h.ok ? 'OK' : 'SKIP'} | ${h.latency_ms}ms | ${h.reason || ''} |`);
  }
  md.push('');
  const skipped = healthRows.filter(h => !h.ok);
  if (skipped.length) {
    md.push('Skipped models do not appear in aggregated.csv. Their absence');
    md.push('is intentional -- excluding partial rows avoids muddying the');
    md.push('per-condition averages with noise from unreachable backends.');
    md.push('');
  }

  md.push('## Per-task x per-condition success rate (all healthy models combined)');
  md.push('');
  md.push('| Task | Condition | Success | Hallucination | Mean tok_in | Mean tok_out | Mean n_act | Sum cost USD |');
  md.push('|---|---|---:|---:|---:|---:|---:|---:|');
  for (const taskId of tasks) {
    for (const cond of conds) {
      const rs = filtered.filter(r => r.task_id === taskId && r.condition === cond);
      if (rs.length === 0) continue;
      const succ = rs.filter(r => r.success).length;
      const hall = rs.filter(r => r.hallucinated_target).length;
      const ti = Math.round(rs.reduce((s, r) => s + r.input_tokens, 0) / rs.length);
      const to = Math.round(rs.reduce((s, r) => s + r.output_tokens, 0) / rs.length);
      const na = (rs.reduce((s, r) => s + r.n_actions_emitted, 0) / rs.length).toFixed(1);
      const cost = rs.reduce((s, r) => s + r.total_cost_usd, 0).toFixed(4);
      md.push(`| ${taskId} | ${cond} | ${succ}/${rs.length} | ${hall}/${rs.length} | ${ti} | ${to} | ${na} | ${cost} |`);
    }
  }
  md.push('');

  md.push('## Per-model x per-condition success rate');
  md.push('');
  md.push('| Model | Condition | Success | Hallucination | Mean tok_in | Mean tok_out | Sum cost USD |');
  md.push('|---|---|---:|---:|---:|---:|---:|');
  for (const m of models) {
    for (const cond of conds) {
      const rs = filtered.filter(r => r.model_id === m && r.condition === cond);
      if (rs.length === 0) continue;
      const succ = rs.filter(r => r.success).length;
      const hall = rs.filter(r => r.hallucinated_target).length;
      const ti = Math.round(rs.reduce((s, r) => s + r.input_tokens, 0) / rs.length);
      const to = Math.round(rs.reduce((s, r) => s + r.output_tokens, 0) / rs.length);
      const cost = rs.reduce((s, r) => s + r.total_cost_usd, 0).toFixed(4);
      md.push(`| ${m} | ${cond} | ${succ}/${rs.length} | ${hall}/${rs.length} | ${ti} | ${to} | ${cost} |`);
    }
  }
  md.push('');

  /* v2.4: per-cell breakdown (task x condition x model) with mean +
     observed-variance. Variance for 0/1 outcomes is just
     p*(1-p) where p = succ/N. We surface "N_success/N" + the variance
     so the eye picks up flakiness immediately. */
  md.push('## Per-cell breakdown (task x condition x model)');
  md.push('');
  md.push('| Task | Condition | Model | Success | Variance | Mean tok_in | Mean cost |');
  md.push('|---|---|---|---:|---:|---:|---:|');
  for (const taskId of tasks) {
    for (const cond of conds) {
      for (const m of models) {
        const rs = bucket(taskId, m, cond);
        if (rs.length === 0) continue;
        const succ = rs.filter(r => r.success).length;
        const p = succ / rs.length;
        const variance = (p * (1 - p)).toFixed(3);
        const ti = Math.round(rs.reduce((s, r) => s + r.input_tokens, 0) / rs.length);
        const cost = (rs.reduce((s, r) => s + r.total_cost_usd, 0) / rs.length).toFixed(4);
        md.push(`| ${taskId} | ${cond} | ${m} | ${succ}/${rs.length} | ${variance} | ${ti} | ${cost} |`);
      }
    }
  }
  md.push('');

  /* Drop detail: for every cell whose success rate < 1.0, surface the
     iteration index + the postcondition detail + the first failing
     dispatch. This is what we actually look at when investigating
     flakiness; the table above tells you WHICH cells dropped, this
     section tells you WHY. */
  const dropCells: Array<{ task: string; cond: string; model: string; failing: RawRun[] }> = [];
  for (const taskId of tasks) {
    for (const cond of conds) {
      for (const m of models) {
        const rs = bucket(taskId, m, cond);
        if (rs.length === 0) continue;
        const failing = rs.filter(r => !r.success);
        if (failing.length === 0) continue;
        dropCells.push({ task: taskId, cond, model: m, failing });
      }
    }
  }
  if (dropCells.length > 0) {
    md.push('## Drop detail (cells that fell short of full success)');
    md.push('');
    for (const cell of dropCells) {
      md.push(`### ${cell.task} | ${cell.cond} | ${cell.model}`);
      md.push('');
      md.push('| iter | error_class | postcondition_detail | first_dispatch_fail |');
      md.push('|---:|---|---|---|');
      for (const r of cell.failing) {
        const drs = (r as any).dispatch_results || [];
        const firstFail = drs.find((d: any) => !d.ok);
        const ff = firstFail
          ? `${firstFail.kind}: ${String(firstFail.error || '').slice(0, 80)}`
          : '(no dispatch fail; check error_message)';
        const detail = String((r as any).postcondition_detail || (r as any).error_detail || '').slice(0, 120);
        md.push(`| ${r.iteration} | ${(r as any).error_class || ''} | ${detail} | ${ff} |`);
      }
      md.push('');
    }
  }

  if (excludedModels.length > 0) {
    md.push('## Excluded from aggregate (free-tier rate-limited)');
    md.push('');
    md.push('These models passed the pre-pilot health check but are');
    md.push('flagged `excluded_from_aggregate=true` in `src/pricing.ts`.');
    md.push('Their per-model rows in the table above are informational --');
    md.push('they do NOT contribute to the per-condition averages or to');
    md.push('the cost totals. Provider rate-limit (Groq TPM cap) drops');
    md.push('them mid-pilot; the runs that completed are kept for the');
    md.push('"we tried, the provider rate-limited us" note in the report.');
    md.push('');
    for (const m of excludedModels) {
      const rs = runs.filter(r => r.model_id === m);
      const errs = rs.filter(r => (r as any).error_class === 'api_error').length;
      md.push(`- \`${m}\`: ${rs.length} runs, ${errs} api_error (rate-limit).`);
    }
    md.push('');
  }

  md.push('## MCP tool-choice profile (T-V23-EDITOR)');
  md.push('');
  md.push('For T_V23_EDITOR the MCP server exposes BOTH a granular tool set');
  md.push('(open_field_editor + editor_select_all + editor_replace +');
  md.push('editor_correct_grammar + editor_save + editor_cancel) AND an');
  md.push('atomic shortcut (correct_field_grammar). See mcp_tool_choice.csv');
  md.push('for per-call breakdown.');
  md.push('');
  fs.writeFileSync(out, md.join('\n') + '\n');
  console.log(`  wrote ${out}`);
}

function writeSampleRunMd(runs: RawRun[]) {
  const out = path.join(OUT_DIR, 'sample_run.md');
  /* Pick the first successful T_V23_EDITOR run from each condition. */
  const md: string[] = [];
  md.push('# Sample runs -- T-V23-EDITOR');
  md.push('');
  for (const cond of ['nac3', 'raw', 'mcp'] as const) {
    const sample = runs.find(r => r.task_id === 'T_V23_EDITOR_fix_monitor' && r.condition === cond && r.success);
    md.push(`## ${cond}`);
    if (!sample) {
      md.push('No successful sample available for this condition.');
      md.push('');
      continue;
    }
    md.push('');
    md.push(`- model: \`${sample.model_id}\``);
    md.push(`- iteration: ${sample.iteration}`);
    md.push(`- tokens in/out: ${sample.input_tokens} / ${sample.output_tokens}`);
    md.push(`- n_actions emitted: ${sample.n_actions_emitted}`);
    md.push(`- cost: \$${sample.total_cost_usd.toFixed(4)}`);
    if (cond === 'mcp') {
      md.push(`- model turns: ${sample.n_model_turns}`);
      md.push(`- tool calls: ${sample.n_tool_calls}`);
      const tools = (sample.tool_calls || [])
        .map(t => String(t?.name || t?.tool || ''))
        .filter(Boolean)
        .join(' -> ');
      md.push(`- tool chain: ${tools || '(empty)'}`);
    }
    md.push('');
  }
  fs.writeFileSync(out, md.join('\n') + '\n');
  console.log(`  wrote ${out}`);
}

function writeSkippedJson(healthRows: HealthRow[]) {
  const out = path.join(OUT_DIR, 'skipped_models.json');
  const skipped = healthRows.filter(h => !h.ok);
  fs.writeFileSync(out, JSON.stringify({
    skipped_count: skipped.length,
    skipped: skipped.map(h => ({ model: h.model, reason: h.reason, latency_ms: h.latency_ms })),
    healthy_count: healthRows.filter(h => h.ok).length,
    healthy: healthRows.filter(h => h.ok).map(h => ({ model: h.model, latency_ms: h.latency_ms })),
  }, null, 2));
  console.log(`  wrote ${out}`);
}

/* ---- main ---- */

async function main() {
  ensureDir(RAW_DIR);
  const health = await probeAll();
  writeSkippedJson(health);
  const healthy = health.filter(h => h.ok).map(h => h.model);

  if (healthy.length === 0) {
    console.error('All models skipped. Nothing to run.');
    return;
  }
  console.log(`\n=== Pilot run (${healthy.length}/${MODELS.length} models healthy) ===`);
  for (const m of healthy) {
    console.log(`\n--- ${m} ---`);
    const r = await runHarnessForModel(m);
    if (r.code !== 0) {
      console.error(`  harness exited with code ${r.code} for model ${m}`);
    }
  }

  console.log('\n=== Aggregation ===');
  const runs = readAllRawRuns();
  writeAggregatedCsv(runs, health);
  writeMcpToolChoiceCsv(runs);
  writeSummaryMd(runs, health);
  writeSampleRunMd(runs);

  /* Copy system_prompts.md if the harness emitted it. */
  const sp = path.join(ROOT, 'results', 'pilot_3way', 'system_prompts.md');
  if (fs.existsSync(sp)) {
    fs.copyFileSync(sp, path.join(OUT_DIR, 'system_prompts.md'));
    console.log(`  copied system_prompts.md`);
  }
  console.log(`\nDone. See ${OUT_DIR}`);
}

main().catch((e) => {
  console.error('fatal:', e);
  process.exit(1);
});
