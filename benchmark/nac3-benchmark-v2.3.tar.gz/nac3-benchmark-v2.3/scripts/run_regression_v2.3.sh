#!/bin/bash
# Bench regression for v2.3 release: NAC3 only, 5 models, 1 iter, 4 tasks = 20 runs.
# Quick smoke that the released runtime + harness still produce the same shape
# of results as the published 600-run benchmark.
# Expected wall-clock: ~2-3 min. Cost: ~US$0.10.
set -e
OUT="${OUT:-results/regression_v2.3}"
mkdir -p "$OUT"

MODELS=(
  "claude-sonnet-4-6"
  "claude-haiku-4-5"
  "deepseek-chat"
  "gemini-3.1-flash-lite"
  "gpt-4o-mini"
)

for M in "${MODELS[@]}"; do
  echo "=================================================================="
  echo "REGRESSION  model=$M  nac3 only  iter=1"
  echo "=================================================================="
  PILOT_CONDITIONS=nac3 PILOT_ITER=1 \
    PILOT_OUT_DIR="$OUT" MODEL="$M" \
    npx tsx src/harness_3way.ts || true
  echo
done

echo "REGRESSION DONE -- $(ls $OUT/*.jsonl 2>/dev/null | wc -l) jsonl files"
