#!/bin/bash
# Tier 1 N=10 (paso 10, 2026-05-19): 4 modelos × 3 cond × 4 task × 10 iter = 480 runs.
# Por addendum sec 6.1: orden por iteración cross-model.
# Cada modelo se llama 10 veces con PILOT_ITER=1, PILOT_ITER_OFFSET=k (k=0..9).
# Eso distribuye el efecto temporal sobre proveedores API.
#
# Roster: Gemini 3.1 Flash Lite, DeepSeek, Haiku 4.5, gpt-4o-mini.
# Conditions: nac3, raw, mcp.
# Estimado: ~6-8h serial, ~US$3-5.
set -e
CONDITIONS="${CONDITIONS:-nac3,raw,mcp}"
TIER1_OUT="${TIER1_OUT:-results/tier1_n10}"
mkdir -p "$TIER1_OUT"

MODELS=(
  "gemini-3.1-flash-lite"
  "deepseek-chat"
  "claude-haiku-4-5"
  "gpt-4o-mini"
)

NUM_ITER="${NUM_ITER:-10}"

for ((k=0; k<NUM_ITER; k++)); do
  for M in "${MODELS[@]}"; do
    echo "=================================================================="
    echo "TIER 1 -- iter=$k  model=$M  conditions=$CONDITIONS"
    echo "=================================================================="
    PILOT_CONDITIONS="$CONDITIONS" PILOT_ITER=1 PILOT_ITER_OFFSET="$k" \
      PILOT_OUT_DIR="$TIER1_OUT" MODEL="$M" \
      npx tsx src/harness_3way.ts || true
    echo
  done
done

echo "TIER 1 DONE -- $(ls $TIER1_OUT/*.jsonl 2>/dev/null | wc -l) jsonl files"
