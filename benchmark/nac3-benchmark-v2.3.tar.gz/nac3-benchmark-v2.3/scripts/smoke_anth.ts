import 'dotenv/config';
import { modelHealthCheck } from '../src/conditions/llm.js';
for (const m of ['claude-sonnet-4-6', 'claude-opus-4-7']) {
  const r = await modelHealthCheck(m);
  console.log(`${m}: ok=${r.ok} latency=${r.latency_ms}ms reason=${r.reason||'-'}`);
}
