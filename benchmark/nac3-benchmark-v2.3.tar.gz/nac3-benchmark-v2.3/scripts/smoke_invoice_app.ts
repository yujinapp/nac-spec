/**
 * smoke_invoice_app.ts -- Playwright smoke test that boots all three
 * variants, verifies they render, and (for nac3/mcp) that the NAC
 * manifest registered without errors.
 */
import { chromium } from 'playwright';

const BASE = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';

async function smoke(variant: 'nac3' | 'raw' | 'mcp') {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const errs: string[] = [];
  page.on('pageerror', e => errs.push('PAGE_ERROR ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE_ERROR ' + m.text()); });
  /* Reset server state so each variant starts from the seed. */
  await page.request.post(`${BASE}/api/reset`);
  await page.goto(`${BASE}/${variant}`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);

  /* Common assertions: list view shows 15 rows. */
  const rowCount = await page.$$eval('#invoice-list-body tr', els => els.length);
  if (rowCount === 0) {
    const bodyText = await page.$eval('body', b => b.outerHTML.length);
    const logText = await page.$eval('#log', el => el.textContent || '');
    const stateProbe = await page.evaluate(() => {
      const w = window as any;
      const s = w.__state ? w.__state() : null;
      return { has_state: !!s, invoices: s ? (s.invoices || []).length : -1, open_id: s ? s.open_invoice_id : null };
    });
    console.log(`[${variant}] DEBUG bodyLen=${bodyText}  log="${logText.slice(0, 200)}"  stateProbe=${JSON.stringify(stateProbe)}`);
  }
  /* For nac3/mcp, NAC.describe() should return at least 3 plugins. */
  let pluginCount = 0;
  if (variant !== 'raw') {
    pluginCount = await page.evaluate(() => {
      const w = window as any;
      if (!w.NAC || typeof w.NAC.describe !== 'function') return -1;
      const d = w.NAC.describe();
      return (d && d.plugins && d.plugins.length) || 0;
    });
  }

  /* Check the modal opens on click. */
  await page.click('button.invoice-edit-btn[data-invoice-id="INV-0001"]');
  await page.waitForTimeout(300);
  const modalOpen = await page.$eval('#invoice-modal', m => m.getAttribute('data-state'));

  console.log(`[${variant}] rows=${rowCount}  plugins=${pluginCount}  modal=${modalOpen}  errs=${errs.length}`);
  if (errs.length) {
    for (const e of errs) console.log('   ', e);
  }

  await browser.close();
}

(async () => {
  for (const v of ['nac3', 'raw', 'mcp'] as const) {
    await smoke(v);
  }
})();
