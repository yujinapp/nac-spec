/**
 * smoke_mcp.ts -- spawn the MCP server, list tools, call a few.
 * Requires the invoice-app server running on :8080.
 */
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import path from 'node:path';

async function main() {
  const transport = new StdioClientTransport({
    command: 'npx',
    args: ['tsx', path.resolve('src/mcp_server/index.ts')],
    env: { ...process.env, INVOICE_APP_URL: 'http://127.0.0.1:8080' },
  });
  const client = new Client({ name: 'smoke', version: '0.1.0' });
  await client.connect(transport);

  const toolsRes = await client.listTools();
  const tools = toolsRes.tools || [];
  console.log(`tools listed: ${tools.length}`);
  for (const t of tools.slice(0, 5)) {
    console.log(`  - ${t.name}: ${t.description?.slice(0, 60)}`);
  }

  /* Reset state for a deterministic test */
  await fetch('http://127.0.0.1:8080/api/reset', { method: 'POST' });

  const list = await client.callTool({ name: 'list_invoices', arguments: { filter: { status: 'pendiente' } } });
  const listText = (list.content as any[])[0].text;
  console.log('\nlist_invoices(pendiente) result:');
  console.log(listText.slice(0, 300));

  const total = await client.callTool({ name: 'get_total', arguments: { invoice_id: 'INV-0001' } });
  console.log('\nget_total(INV-0001):', (total.content as any[])[0].text);

  await client.close();
}

main().catch(e => { console.error('smoke_mcp failed:', e); process.exit(1); });
