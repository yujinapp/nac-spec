import 'dotenv/config';
import { modelHealthCheck, callLlm } from '../src/conditions/llm.js';

const MODELS = ['gpt-4o-mini', 'gpt-5.5'];

for (const m of MODELS) {
  console.log(`--- ${m} ---`);
  process.env.MODEL = m;
  const h = await modelHealthCheck(m);
  console.log(`health: ok=${h.ok} latency=${h.latency_ms}ms reason=${h.reason||'-'}`);
  if (!h.ok) continue;
  const r = await callLlm({
    system: 'Output JSON only: {"answer": <single integer>}',
    messages: [{ role: 'user', content: 'What is 7 + 5?' }],
    max_tokens: 60,
  });
  if (r.ok) {
    console.log(`call: text=${JSON.stringify(r.text).slice(0,160)} latency=${r.latency_ms}ms tokens_in=${r.usage.input_tokens} out=${r.usage.output_tokens}`);
  } else {
    console.log(`call: FAIL ${r.error.slice(0,200)}`);
  }
}
