/**
 * Browser smoke for V24-04 runtime. Loads /nac3 in headless chromium,
 * verifies that the new APIs exist and basic behaviour is correct.
 */
import { chromium } from 'playwright';

const BASE = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';

const browser = await chromium.launch({ headless: true });
const ctx = await browser.newContext();
const page = await ctx.newPage();
page.on('pageerror', (e) => console.log('[pageerror]', e.message));
page.on('console', (m) => {
  if (m.type() === 'error') console.log('[console.error]', m.text());
});

console.log('--- loading /nac3 ---');
await page.goto(`${BASE}/nac3`, { waitUntil: 'networkidle' });

console.log('--- waiting for NAC + hydration_complete ---');
const hydrated = await page.evaluate(async () => {
  if (typeof window.NAC === 'undefined') return { error: 'NAC not loaded' };
  // Wait for the hydration_complete event OR fallback (100ms)
  return new Promise((resolve) => {
    const fallback = setTimeout(() => resolve({
      trigger: 'timeout', conformance_tier: window.NAC.conformance_tier
    }), 1500);
    document.addEventListener('nac:tree:invalidated', function once(ev) {
      if (ev.detail.trigger === 'hydration_complete') {
        clearTimeout(fallback);
        document.removeEventListener('nac:tree:invalidated', once);
        resolve({
          trigger: ev.detail.trigger,
          to_version: ev.detail.to_version,
          conformance_tier: window.NAC.conformance_tier,
        });
      }
    });
  });
});
console.log('hydration:', JSON.stringify(hydrated));

console.log('--- API surface ---');
const surf = await page.evaluate(() => {
  const keys = ['conformance_tier', 'STRICT_VERSIONING', 'eager_hashing',
                'markHydrationComplete', 'versionHistory',
                'scan_plugin_instances'];
  const out = {};
  for (const k of keys) {
    const v = window.NAC[k];
    out[k] = (typeof v === 'function') ? 'function' : v;
  }
  return out;
});
console.log('NAC surface:', JSON.stringify(surf, null, 2));

console.log('--- describe() shape ---');
const snap = await page.evaluate(() => {
  const d = window.NAC.describe();
  return {
    has_tree_version: typeof d.tree_version === 'string',
    tree_version: d.tree_version,
    plugin_count: d.plugins.length,
    plugin0_has_version: d.plugins[0] && typeof d.plugins[0].plugin_version === 'string',
    plugin0: d.plugins[0] && {
      plugin: d.plugins[0].plugin,
      plugin_instance_id: d.plugins[0].plugin_instance_id,
      plugin_version: d.plugins[0].plugin_version,
      first_element_has_hash: d.plugins[0].elements[0] &&
                              typeof d.plugins[0].elements[0].element_state_hash === 'string',
      first_element_hash_prefix: d.plugins[0].elements[0] &&
                                  d.plugins[0].elements[0].element_state_hash &&
                                  d.plugins[0].elements[0].element_state_hash.slice(0, 8),
    },
  };
});
console.log('describe:', JSON.stringify(snap, null, 2));

console.log('--- snapshot_stale rejection test ---');
const stale = await page.evaluate(async () => {
  // Get current plugin_version
  const d = window.NAC.describe();
  const target = d.plugins[0];
  if (!target || !target.plugin_version) return { error: 'no plugin found' };
  // Try a click with an obviously stale expected_plugin_version
  const firstAction = target.elements.find(e => e.role === 'action');
  if (!firstAction) return { error: 'no action element in plugin' };
  try {
    await window.NAC.click(firstAction.nac_id, {
      expected_plugin_version: 'v_999999',
    });
    return { error: 'should have thrown snapshot_stale' };
  } catch (e) {
    return {
      ok: true,
      code: e.code,
      reason: e.detail && e.detail.reason,
      expected: e.detail && e.detail.expected_plugin_version,
      current: e.detail && e.detail.current_plugin_version,
    };
  }
});
console.log('snapshot_stale test:', JSON.stringify(stale, null, 2));

console.log('--- versionHistory ---');
const hist = await page.evaluate(() => window.NAC.versionHistory(5));
console.log('versionHistory (last 5):', JSON.stringify(hist, null, 2));

await browser.close();
console.log('--- DONE ---');
