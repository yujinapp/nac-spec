/**
 * strip_nac3.ts
 *
 * Deterministic check that page-raw/index.html is a fair counterpart of
 * page-nac3/index.php: same DOM-observable surface, same ARIA, same IDs
 * and labels, but with the NAC3 contract layer removed (no data-nac-*
 * attributes, no NAC.* globals, no manifest registration).
 *
 * This script does NOT auto-generate page-raw -- writing a vanilla
 * data-table impl from scratch is more reliable than mechanical AST
 * surgery on the demo's inline JS. Instead we hand-craft page-raw and
 * use this script to sanity-check the audit invariants below.
 *
 * If any check fails the script exits non-zero so CI can catch
 * accidental drift between the two pages.
 *
 * Invariants verified:
 *   1. page-raw contains zero `data-nac-` attributes.
 *   2. page-raw does not reference js/nac.js, js/nac-v2-*, js/nac-chat-*.
 *   3. page-raw exposes the same visible UI affordances as page-nac3:
 *      - "Edit invoice #INV-001" button (open modal)
 *      - Modal with Save + Cancel
 *      - Lines tab + Permissions tab
 *      - 8 initial rows (Mouse/Teclado/Monitor/Silla/Auriculares/Webcam/Cable USB/Lampara)
 *      - Add line button
 *      - Chat panel + language selector
 *   4. page-raw uses ARIA roles and labels so a vision-less agent has
 *      a fair shot.
 *
 * Run: pnpm tsx scripts/strip_nac3.ts
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const PAGE_NAC3 = path.join(ROOT, 'page-nac3', 'index.php');
const PAGE_RAW  = path.join(ROOT, 'page-raw',  'index.html');

interface Check {
  name: string;
  ok: boolean;
  detail?: string;
}

function read(p: string): string {
  return fs.readFileSync(p, 'utf8');
}

function check(name: string, predicate: () => boolean | string): Check {
  try {
    const r = predicate();
    if (r === true) return { name, ok: true };
    if (r === false) return { name, ok: false };
    return { name, ok: false, detail: r };
  } catch (e: any) {
    return { name, ok: false, detail: e.message };
  }
}

function main() {
  const nacSource = read(PAGE_NAC3);
  const rawSource = read(PAGE_RAW);

  const checks: Check[] = [];

  /* 1. No data-nac-* in raw. */
  checks.push(check('raw: no data-nac-* attributes', () => {
    const m = rawSource.match(/data-nac-[a-z][a-z-]*/gi);
    return m ? `found ${m.length} occurrences: ${m.slice(0, 3).join(', ')}...` : true;
  }));

  /* 2. No NAC scripts referenced in raw. */
  checks.push(check('raw: does not load js/nac*.js', () => {
    const m = rawSource.match(/js\/nac[^"']*\.js/gi);
    return m ? `found script refs: ${m.join(', ')}` : true;
  }));

  /* 3. No NAC.* or NacChat call sites (parens). Comments mentioning the
        names by way of explaining their absence are allowed. */
  checks.push(check('raw: no NAC.* / NacChat call sites', () => {
    const m = rawSource.match(/\b(NAC|NacChat)\.\w+\s*\(/g);
    return !m ? true : `found call sites: ${m.slice(0, 5).join(', ')}`;
  }));

  /* 4. Same visible affordances. */
  const affordances: { label: string; pattern: RegExp }[] = [
    { label: 'Edit invoice button',  pattern: /Edit invoice #INV-001/ },
    { label: 'Save button',          pattern: />Save</ },
    { label: 'Cancel button',        pattern: />Cancel</ },
    { label: 'Lines tab',            pattern: /Lines.*\(collection\)/i },
    { label: 'Permissions tab',      pattern: /Permissions.*\(matrix\)/i },
    { label: 'Add line button',      pattern: /\+ Add line/ },
    { label: 'Chat language select', pattern: /id=["']chat-lang["']/ },
    { label: 'Chat send button',     pattern: /id=["']chat-send["']/ },
    { label: 'Chat mic button',      pattern: /id=["']chat-mic["']/ },
  ];
  for (const a of affordances) {
    checks.push(check(`raw: contains ${a.label}`, () => {
      return a.pattern.test(rawSource) || `pattern ${a.pattern} not found`;
    }));
    checks.push(check(`nac3: contains ${a.label}`, () => {
      return a.pattern.test(nacSource) || `pattern ${a.pattern} not found`;
    }));
  }

  /* 5. Initial product names appear in raw. */
  const initialProducts = ['Mouse', 'Teclado', 'Monitor', 'Silla',
    'Auriculares', 'Webcam', 'Cable USB', 'Lampara'];
  for (const product of initialProducts) {
    checks.push(check(`raw: seeds product "${product}"`, () => {
      return rawSource.includes(`'${product}'`) || rawSource.includes(`"${product}"`) ||
             `product not in initial rows`;
    }));
  }

  /* 6. ARIA presence in raw. */
  const ariaSamples = [
    /aria-label="Save invoice"/,
    /aria-label="Cancel"/,
    /role="tab"/,
    /role="dialog"/,
    /role="tabpanel"/,
    /aria-current="page"/,
    /aria-modal="true"/,
  ];
  for (const a of ariaSamples) {
    checks.push(check(`raw: has ${a}`, () => {
      return a.test(rawSource) || `aria pattern ${a} missing`;
    }));
  }

  /* Render report. */
  const passed = checks.filter(c => c.ok).length;
  const failed = checks.filter(c => !c.ok);

  for (const c of checks) {
    const tag = c.ok ? 'OK  ' : 'FAIL';
    console.log(`[${tag}] ${c.name}` + (c.detail ? `  -- ${c.detail}` : ''));
  }
  console.log(`\n${passed}/${checks.length} checks passed`);

  if (failed.length > 0) {
    console.error(`\n${failed.length} check(s) failed -- page-raw is not equivalent to page-nac3`);
    process.exit(1);
  }
}

main();
