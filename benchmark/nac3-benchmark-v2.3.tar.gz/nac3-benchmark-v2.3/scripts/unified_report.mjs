/**
 * Load every results/pilot_3way/raw/*.jsonl produced today and emit
 * unified tables: model x condition x task plus a per-condition
 * aggregate per model. Output: markdown tables to stdout AND a CSV
 * dump for spreadsheet ingest.
 *
 * Usage:
 *   tsx scripts/unified_report.mjs [--since=YYYY-MM-DD] > docs/PASO9_REPORT.md
 *   tsx scripts/unified_report.mjs --csv > docs/PASO9_REPORT.csv
 */
import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RESULTS_DIR = process.env.RESULTS_DIR
  ? path.resolve(process.env.RESULTS_DIR)
  : path.resolve(__dirname, '..', 'results', 'pilot_3way', 'raw');

const args = process.argv.slice(2);
const csv = args.includes('--csv');
const includeWalker = args.includes('--with-walker');
/* Default: paso 9 corrida (starts 2026-05-19T17:00). Override with
   --since=PREFIX to widen (e.g. --since=2026-05-19 for the whole
   day, or --since=2026-05 for the month). */
const since = (args.find(a => a.startsWith('--since=')) || '').split('=')[1] || '2026-05-19T17';

const files = (await readdir(RESULTS_DIR)).filter(f => f.endsWith('.jsonl') && f >= since).sort();
const rawRows = [];
for (const f of files) {
  const fp = path.join(RESULTS_DIR, f);
  const txt = await readFile(fp, 'utf-8');
  for (const line of txt.split('\n')) {
    if (!line.trim()) continue;
    try { rawRows.push(JSON.parse(line)); } catch (_) {}
  }
}

/* Dedupe by logical cell (model, iter, cond, task). If the same cell has
   multiple records (e.g. a re-run after api_error), prefer the latest
   non-api_error record. Falls back to the latest record overall. */
const cellMap = new Map();
for (const r of rawRows) {
  const k = `${r.model_id}__${r.iteration}__${r.condition}__${r.task_id}`;
  const prev = cellMap.get(k);
  if (!prev) { cellMap.set(k, r); continue; }
  const prevApi = prev.error_class === 'api_error';
  const curApi = r.error_class === 'api_error';
  /* Prefer non-api_error. Among same-status, prefer latest started_at. */
  if (prevApi && !curApi) { cellMap.set(k, r); continue; }
  if (!prevApi && curApi) continue;
  if ((r.started_at || '') > (prev.started_at || '')) cellMap.set(k, r);
}
const allRows = [...cellMap.values()];

/* Per user 2026-05-19: Forge walker conditions are excluded from the
   unified report. Their data remains in the raw jsonls for later
   analysis if needed. */
const WALKER_CONDS = new Set(['nac3-walker-silent', 'nac3-walker-assisted']);
const rows = includeWalker
  ? allRows
  : allRows.filter(r => !WALKER_CONDS.has(r.condition));

if (csv) {
  /* Full CSV dump -- every column from every row. */
  const allCols = new Set();
  for (const r of rows) for (const k of Object.keys(r)) allCols.add(k);
  const cols = [...allCols].sort();
  console.log(cols.join(','));
  for (const r of rows) {
    console.log(cols.map(c => {
      const v = r[c];
      if (v == null) return '';
      if (typeof v === 'object') return JSON.stringify(v).replace(/,/g, ';');
      const s = String(v).replace(/"/g, '""');
      return /[,"\n]/.test(s) ? `"${s}"` : s;
    }).join(','));
  }
  process.exit(0);
}

/* Markdown report. */
const MODELS = [...new Set(rows.map(r => r.model_id))].sort();
const CONDITIONS = [...new Set(rows.map(r => r.condition))].sort();
const TASKS = [...new Set(rows.map(r => r.task_id))].sort();

console.log('# Paso 9 unified report');
console.log('');
console.log(`Generated: ${new Date().toISOString()}`);
console.log(`Total runs: ${rows.length}`);
console.log(`Models: ${MODELS.length} -- ${MODELS.join(', ')}`);
console.log(`Conditions: ${CONDITIONS.length} -- ${CONDITIONS.join(', ')}`);
console.log(`Tasks: ${TASKS.length} -- ${TASKS.join(', ')}`);
console.log('');

/* ---- Table 1: success rate matrix (model x condition) ---- */
console.log('## Success rate (model x condition)');
console.log('');
console.log('| Model | ' + CONDITIONS.join(' | ') + ' | total |');
console.log('|---' + CONDITIONS.map(() => '---').join('|') + '|---|');
for (const m of MODELS) {
  const cells = [m];
  let totalN = 0, totalS = 0;
  for (const c of CONDITIONS) {
    const subset = rows.filter(r => r.model_id === m && r.condition === c);
    const succ = subset.filter(r => r.success).length;
    cells.push(`${succ}/${subset.length}`);
    totalN += subset.length;
    totalS += succ;
  }
  cells.push(`${totalS}/${totalN}`);
  console.log('| ' + cells.join(' | ') + ' |');
}
console.log('');

/* ---- Table 2: cost / tokens / latency aggregate per (model, condition) ---- */
console.log('## Aggregate metrics per (model, condition)');
console.log('');
console.log('| Model | Cond | n | succ | halluc | tok_in | tok_out | n_acts | turns | llm_ms | e2e_ms | cost |');
console.log('|---|---|---|---|---|---|---|---|---|---|---|---|');
for (const m of MODELS) {
  for (const c of CONDITIONS) {
    const ss = rows.filter(r => r.model_id === m && r.condition === c);
    if (ss.length === 0) continue;
    const n = ss.length;
    const succ = ss.filter(r => r.success).length;
    const halluc = ss.filter(r => r.hallucinated_target).length;
    const mean = (k) => ss.reduce((a, r) => a + (r[k] || 0), 0) / n;
    const sum = (k) => ss.reduce((a, r) => a + (r[k] || 0), 0);
    console.log(`| ${m} | ${c} | ${n} | ${succ}/${n} | ${halluc}/${n} | ${Math.round(mean('input_tokens'))} | ${Math.round(mean('output_tokens'))} | ${mean('n_actions_emitted').toFixed(1)} | ${mean('n_model_turns').toFixed(1)} | ${Math.round(mean('llm_latency_ms'))} | ${Math.round(mean('end_to_end_ms'))} | $${sum('total_cost_usd').toFixed(4)} |`);
  }
}
console.log('');

/* ---- Table 3: per-task drill-down ---- */
console.log('## Success per (model, condition, task)');
console.log('');
console.log('| Model | Cond | ' + TASKS.map(t => t.replace('T_', '').replace('_', '_').slice(0, 18)).join(' | ') + ' |');
console.log('|---|---' + TASKS.map(() => '|---').join('') + '|');
for (const m of MODELS) {
  for (const c of CONDITIONS) {
    const cells = [m, c];
    for (const t of TASKS) {
      const ss = rows.filter(r => r.model_id === m && r.condition === c && r.task_id === t);
      if (ss.length === 0) { cells.push(''); continue; }
      const succ = ss.filter(r => r.success).length;
      cells.push(`${succ}/${ss.length}`);
    }
    console.log('| ' + cells.join(' | ') + ' |');
  }
}
console.log('');

/* ---- Table 3.5 (v2.4 fix D): hallucination category breakdown per condition ---- */
/* none | filtered (validator caught) | reached_failed (selector inventado, side effect erro) |
   reached_succeeded (selector inventado pero postcondition paso = silent damage). */
console.log('## Hallucination category per (model, condition)');
console.log('');
console.log('| Model | Cond | n | none | filtered | reached_failed | reached_succeeded (silent damage) |');
console.log('|---|---|---|---|---|---|---|');
for (const m of MODELS) {
  for (const c of CONDITIONS) {
    const ss = rows.filter(r => r.model_id === m && r.condition === c);
    if (ss.length === 0) continue;
    const cats = { none: 0, filtered: 0, reached_failed: 0, reached_succeeded: 0 };
    for (const r of ss) {
      const k = r.hallucination_category || 'none';
      if (cats[k] != null) cats[k]++;
      else cats.none++;
    }
    console.log(`| ${m} | ${c} | ${ss.length} | ${cats.none} | ${cats.filtered} | ${cats.reached_failed} | ${cats.reached_succeeded} |`);
  }
}
console.log('');

console.log('## Hallucination category (all models, per condition)');
console.log('');
console.log('| Cond | n | none | filtered | reached_failed | reached_succeeded (silent damage) |');
console.log('|---|---|---|---|---|---|');
for (const c of CONDITIONS) {
  const ss = rows.filter(r => r.condition === c);
  if (ss.length === 0) continue;
  const cats = { none: 0, filtered: 0, reached_failed: 0, reached_succeeded: 0 };
  for (const r of ss) {
    const k = r.hallucination_category || 'none';
    if (cats[k] != null) cats[k]++;
    else cats.none++;
  }
  console.log(`| ${c} | ${ss.length} | ${cats.none} | ${cats.filtered} | ${cats.reached_failed} | ${cats.reached_succeeded} |`);
}
console.log('');

/* ---- Table 3.6 (v2.4 fix A+C): truncated_by_cap + asked_human per (model, condition) ---- */
console.log('## Truncation + asked_human per (model, condition)');
console.log('');
console.log('| Model | Cond | n | truncated_by_cap | asked_human |');
console.log('|---|---|---|---|---|');
for (const m of MODELS) {
  for (const c of CONDITIONS) {
    const ss = rows.filter(r => r.model_id === m && r.condition === c);
    if (ss.length === 0) continue;
    const tc = ss.filter(r => r.truncated_by_cap === true).length;
    const ah = ss.filter(r => r.asked_human === true).length;
    console.log(`| ${m} | ${c} | ${ss.length} | ${tc} | ${ah} |`);
  }
}
console.log('');

/* ---- Table 4: hallucinations + error_class breakdown ---- */
console.log('## Hallucination + error classes');
console.log('');
console.log('| Model | Cond | n | halluc | hit_max_turns | parse_err | not_found | timeout | api_err | post_fail | other |');
console.log('|---|---|---|---|---|---|---|---|---|---|---|');
for (const m of MODELS) {
  for (const c of CONDITIONS) {
    const ss = rows.filter(r => r.model_id === m && r.condition === c);
    if (ss.length === 0) continue;
    const n = ss.length;
    const halluc = ss.filter(r => r.hallucinated_target).length;
    const hitMax = ss.filter(r => r.hit_max_turns).length;
    const errs = {};
    for (const r of ss) {
      const k = (r.error_class || 'ok').toLowerCase();
      errs[k] = (errs[k] || 0) + 1;
    }
    const pe = errs['parse_error'] || 0;
    const nf = errs['not_found'] || 0;
    const to = errs['timeout'] || 0;
    const ae = errs['api_error'] || 0;
    const pc = errs['post_condition_failed'] || 0;
    const known = pe + nf + to + ae + pc + (errs['ok'] || 0);
    const other = n - known;
    console.log(`| ${m} | ${c} | ${n} | ${halluc} | ${hitMax} | ${pe} | ${nf} | ${to} | ${ae} | ${pc} | ${other} |`);
  }
}
console.log('');

/* ---- Table 5: overall condition aggregate (across all models) ---- */
console.log('## Overall per-condition aggregate (all models combined)');
console.log('');
console.log('| Cond | n | succ | halluc | tok_in_mean | tok_out_mean | n_acts_mean | turns_mean | llm_ms_mean | cost_total |');
console.log('|---|---|---|---|---|---|---|---|---|---|');
for (const c of CONDITIONS) {
  const ss = rows.filter(r => r.condition === c);
  if (ss.length === 0) continue;
  const n = ss.length;
  const succ = ss.filter(r => r.success).length;
  const halluc = ss.filter(r => r.hallucinated_target).length;
  const mean = (k) => ss.reduce((a, r) => a + (r[k] || 0), 0) / n;
  const sum = (k) => ss.reduce((a, r) => a + (r[k] || 0), 0);
  console.log(`| ${c} | ${n} | ${succ}/${n} | ${halluc}/${n} | ${Math.round(mean('input_tokens'))} | ${Math.round(mean('output_tokens'))} | ${mean('n_actions_emitted').toFixed(1)} | ${mean('n_model_turns').toFixed(1)} | ${Math.round(mean('llm_latency_ms'))} | $${sum('total_cost_usd').toFixed(2)} |`);
}
console.log('');

/* ---- Failure analysis: every non-success run, with its details ---- */
console.log('## Failure analysis (every failed run)');
console.log('');
const fails = rows.filter(r => !r.success);
console.log(`Total failures: ${fails.length} / ${rows.length} runs (${((fails.length / Math.max(1, rows.length)) * 100).toFixed(1)}%)`);
console.log('');
if (fails.length > 0) {
  console.log('| Model | Cond | Task | err_class | halluc | n_acts | turns | tok_out | parsed_message (truncated) | postcondition_detail |');
  console.log('|---|---|---|---|---|---|---|---|---|---|');
  for (const r of fails) {
    const pm = (r.parsed_message || '').replace(/[|\n]/g, ' ').slice(0, 80);
    const pc = (r.postcondition_detail || '').replace(/[|\n]/g, ' ').slice(0, 80);
    console.log(`| ${r.model_id} | ${r.condition} | ${r.task_id} | ${r.error_class} | ${r.hallucinated_target ? 'Y' : 'n'} | ${r.n_actions_emitted} | ${r.n_model_turns} | ${r.output_tokens} | ${pm} | ${pc} |`);
  }
}
console.log('');

/* ---- Failure breakdown by error class ---- */
console.log('## Error class distribution');
console.log('');
const errByCond = {};
for (const r of fails) {
  const k = `${r.condition}|${r.error_class || 'unknown'}`;
  errByCond[k] = (errByCond[k] || 0) + 1;
}
console.log('| Cond | error_class | count |');
console.log('|---|---|---|');
const keys = Object.keys(errByCond).sort();
for (const k of keys) {
  const [c, e] = k.split('|');
  console.log(`| ${c} | ${e} | ${errByCond[k]} |`);
}
console.log('');

/* ---- All-column row dump for the audit-curious ---- */
console.log('## Full per-run dump (every column)');
console.log('');
const allCols = new Set();
for (const r of rows) for (const k of Object.keys(r)) allCols.add(k);
/* Drop heavy/audit columns that bloat the table. */
const DROP_COLS = new Set(['raw_response_first', 'raw_responses_all', 'user_prompt', 'parsed_actions', 'tool_calls', 'dispatch_results', 'system_prompt_hash']);
const cols = [...allCols].filter(c => !DROP_COLS.has(c)).sort();
console.log('| ' + cols.join(' | ') + ' |');
console.log('|' + cols.map(() => '---').join('|') + '|');
for (const r of rows) {
  console.log('| ' + cols.map(c => {
    const v = r[c];
    if (v == null) return '';
    if (typeof v === 'object') return JSON.stringify(v).replace(/[|\n]/g, ' ').slice(0, 60);
    return String(v).replace(/[|\n]/g, ' ').slice(0, 80);
  }).join(' | ') + ' |');
}
console.log('');

console.log('---');
console.log('');
console.log('Generated from ' + files.length + ' result files. ' + (includeWalker ? '(includes walker data)' : '(walker excluded -- pass --with-walker to include).'));
