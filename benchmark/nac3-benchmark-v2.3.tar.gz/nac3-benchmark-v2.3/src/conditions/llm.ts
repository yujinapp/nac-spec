/**
 * llm.ts -- model-agnostic LLM client.
 *
 * Wraps Anthropic (Claude family), Google (Gemini family), and
 * OpenAI-compatible providers (Groq, DeepSeek) behind a single
 * callLlm() so each condition module emits one code path.
 *
 * The active model is selected via env MODEL (defaults to
 * claude-sonnet-4-6). Health check can probe a different model
 * via the modelId override.
 */
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenerativeAI } from '@google/generative-ai';

export const MODEL_ID = process.env.MODEL || 'claude-sonnet-4-6';

/** Family classification for routing. */
function family(id: string): 'anthropic' | 'google' | 'groq' | 'deepseek' | 'openai' {
  if (id.startsWith('claude-')) return 'anthropic';
  if (id.startsWith('gemini-')) return 'google';
  if (id.startsWith('llama-') || id.startsWith('meta-llama/') ||
      id.startsWith('gemma-') || id.startsWith('qwen') ||
      id.startsWith('openai/gpt-oss-') || id.startsWith('mistral-') ||
      id.startsWith('moonshotai/') || id.startsWith('groq/')) return 'groq';
  if (id.startsWith('deepseek-')) return 'deepseek';
  /* Native OpenAI: GPT-3.5/4/4o/4.1/5.x families + reasoning series (o1/o3/o4). */
  if (/^gpt-[345]/.test(id) || /^o[134](-|$)/.test(id) || id.startsWith('chatgpt-')) {
    return 'openai';
  }
  throw new Error('Unknown model family: ' + id);
}

/** Models that mandate `max_completion_tokens` instead of legacy `max_tokens`
   and reject explicit temperature overrides (must use default 1).
   Covers gpt-5.x and the o-series reasoning models. */
function isOpenAINewSchema(id: string): boolean {
  return /^gpt-5/.test(id) || /^o[134](-|$)/.test(id);
}

/** Reasoning models: spend output tokens on internal chain-of-thought before
   emitting the visible response. With a 1024-3072 cap they routinely truncate
   the JSON we need for action dispatch. Fix A (v2.4, 2026-05-19): raise their
   cap to 8192 so the reasoning has room AND there's enough tail for the JSON.
   Non-reasoners keep the caller's cap unchanged. */
function isReasoningModel(id: string): boolean {
  return /^gpt-5/.test(id) || /^o[134](-|$)/.test(id) || /^o5/.test(id);
}

/** Per-model output cap. Used by all three provider paths. Caller can still
   override upward by passing args.max_tokens; reasoners are floored at 8192.
   Non-reasoners default bumped 1024 -> 2048 on 2026-05-19 because Haiku
   in MCP T_MCP4 compound runs was hitting the 1024 ceiling (6/10 in Tier
   1 N=10). 2048 leaves headroom for the JSON tail in long tool chains. */
function resolveOutputCap(modelId: string, caller?: number): number {
  if (isReasoningModel(modelId)) {
    return Math.max(caller ?? 0, 8192);
  }
  return caller ?? 2048;
}

export interface LlmUsage {
  input_tokens: number;
  output_tokens: number;
  cache_read_input_tokens: number;
  cache_creation_input_tokens: number;
  /* v2.4 (2026-05-19): reasoning tokens for reasoner families (gpt-5.x,
     o-series). For non-reasoners stays 0. APIs that don't separate them
     leave this 0 even if reasoning happened internally. */
  reasoning_tokens: number;
}

export type LlmResult =
  | { ok: true;  text: string; usage: LlmUsage; latency_ms: number;
      cap_applied: number; finish_reason?: string }
  | { ok: false; error: string; latency_ms: number };

/** truncated_by_cap: true iff output_tokens reached the cap we set AND
   either finish_reason indicates length OR the body lacks a closing JSON.
   Computed by the harness (it has both pieces). */
export function isTruncatedByCap(res: LlmResult): boolean {
  if (!res.ok) return false;
  if (res.usage.output_tokens < res.cap_applied) return false;
  if (res.finish_reason === 'length' || res.finish_reason === 'max_tokens') return true;
  /* Heuristic fallback: payload should end with '}' or ']' when JSON-only. */
  const t = (res.text || '').trim();
  if (!t.endsWith('}') && !t.endsWith(']')) return true;
  return false;
}

export interface LlmMessage {
  role: 'user' | 'assistant';
  content: string;
}

let anthropicClient: Anthropic | null = null;
function anth(): Anthropic {
  if (!anthropicClient) anthropicClient = new Anthropic();
  return anthropicClient;
}

let googleClient: GoogleGenerativeAI | null = null;
function goog(): GoogleGenerativeAI {
  if (!googleClient) {
    const k = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '';
    if (!k) throw new Error('GEMINI_API_KEY missing');
    googleClient = new GoogleGenerativeAI(k);
  }
  return googleClient;
}

function resolveAnthropicId(id: string): string {
  if (id === 'claude-haiku-4-5') return 'claude-haiku-4-5-20251001';
  if (id === 'claude-sonnet-4-6') return 'claude-sonnet-4-6';
  if (id === 'claude-opus-4-7')   return 'claude-opus-4-7';
  return id;
}

async function callAnthropic(modelId: string, args: {
  system: string;
  messages: LlmMessage[];
  max_tokens?: number;
  temperature?: number;
}): Promise<LlmResult> {
  const t0 = Date.now();
  try {
    /* Claude Opus 4.7 (2026-Q2) does not accept temperature -- the
       API rejects with invalid_request_error. Skip it for opus-4-7+. */
    const skipTemp = /^claude-opus-4-7/.test(modelId);
    const cap = resolveOutputCap(modelId, args.max_tokens);
    const payload: any = {
      model: resolveAnthropicId(modelId),
      max_tokens:  cap,
      system:      args.system,
      messages: args.messages.map(m => ({ role: m.role, content: m.content })),
    };
    if (!skipTemp) payload.temperature = args.temperature ?? 0.2;
    const r = await anth().messages.create(payload);
    const t1 = Date.now();
    const block = r.content.find((b: any) => b.type === 'text') as any;
    const text  = block?.text || '';
    return {
      ok: true,
      text,
      usage: {
        input_tokens:                  r.usage.input_tokens  || 0,
        output_tokens:                 r.usage.output_tokens || 0,
        cache_read_input_tokens:      (r.usage as any).cache_read_input_tokens     || 0,
        cache_creation_input_tokens:  (r.usage as any).cache_creation_input_tokens || 0,
        reasoning_tokens:             0, /* Anthropic does not expose */
      },
      latency_ms: t1 - t0,
      cap_applied: cap,
      finish_reason: (r as any).stop_reason,
    };
  } catch (e: any) {
    return { ok: false, error: e?.message || String(e), latency_ms: Date.now() - t0 };
  }
}

async function callGoogle(modelId: string, args: {
  system: string;
  messages: LlmMessage[];
  max_tokens?: number;
  temperature?: number;
}): Promise<LlmResult> {
  const t0 = Date.now();
  try {
    const cap = resolveOutputCap(modelId, args.max_tokens);
    const model = goog().getGenerativeModel({
      model: modelId,
      systemInstruction: args.system,
      generationConfig: {
        maxOutputTokens: cap,
        temperature:     args.temperature ?? 0.2,
        responseMimeType: 'application/json',
      },
    });
    const contents = args.messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));
    const result = await model.generateContent({ contents });
    const t1 = Date.now();
    const text = result.response?.text?.() || '';
    const um   = (result.response as any)?.usageMetadata || {};
    const finishReason = (result.response as any)?.candidates?.[0]?.finishReason;
    return {
      ok: true,
      text,
      usage: {
        input_tokens:                 um.promptTokenCount     || 0,
        output_tokens:                um.candidatesTokenCount || 0,
        cache_read_input_tokens:      um.cachedContentTokenCount || 0,
        cache_creation_input_tokens:  0,
        reasoning_tokens:             um.thoughtsTokenCount || 0, /* Gemini Pro reasoning */
      },
      latency_ms: t1 - t0,
      cap_applied: cap,
      finish_reason: finishReason,
    };
  } catch (e: any) {
    return { ok: false, error: e?.message || String(e), latency_ms: Date.now() - t0 };
  }
}

/* OpenAI-compatible providers. Plain fetch -- no openai npm package. */
interface OpenAICompatTarget {
  baseURL: string;
  apiKey: string;
  jsonForceable: boolean;
}

function openAITarget(id: string): OpenAICompatTarget {
  if (family(id) === 'groq') {
    return {
      baseURL: 'https://api.groq.com/openai/v1',
      apiKey:  process.env.GROK_API_KEY || process.env.GROQ_API_KEY || '',
      jsonForceable: true,
    };
  }
  if (family(id) === 'deepseek') {
    return {
      baseURL: 'https://api.deepseek.com/v1',
      apiKey:  process.env.DEEPSEEK_API_KEY || '',
      jsonForceable: true,
    };
  }
  if (family(id) === 'openai') {
    return {
      baseURL: 'https://api.openai.com/v1',
      apiKey:  process.env.OPENAI_API_KEY || '',
      jsonForceable: true,
    };
  }
  throw new Error('No OpenAI-compatible target for model: ' + id);
}

async function callOpenAICompat(modelId: string, args: {
  system: string;
  messages: LlmMessage[];
  max_tokens?: number;
  temperature?: number;
}): Promise<LlmResult> {
  const target = openAITarget(modelId);
  if (!target.apiKey) {
    return { ok: false, error: 'missing API key for ' + modelId, latency_ms: 0 };
  }
  const t0 = Date.now();
  try {
    const body: any = {
      model: modelId,
      messages: [
        { role: 'system', content: args.system },
        ...args.messages.map(m => ({ role: m.role, content: m.content })),
      ],
    };
    /* gpt-5.x + o-series reject `max_tokens` (must be
       `max_completion_tokens`) and reject any non-default temperature.
       Older OpenAI + Groq + DeepSeek still use legacy schema.
       Reasoners get the 8192 floor via resolveOutputCap so the JSON tail
       survives the chain-of-thought spend (v2.4 fix A, 2026-05-19). */
    const cap = resolveOutputCap(modelId, args.max_tokens);
    if (family(modelId) === 'openai' && isOpenAINewSchema(modelId)) {
      body.max_completion_tokens = cap;
      /* No temperature -- must be default 1 on these models. */
    } else {
      body.max_tokens  = cap;
      body.temperature = args.temperature ?? 0.2;
    }
    /* Groq + DeepSeek both reject response_format=json_object when the
       prompt does not literally contain the substring "json". The
       benchmark system prompts always do (they say "Output JSON only"
       etc); generic pings do not. Test against the assembled prompt
       and only set json_object when "json" appears. */
    const sample = (args.system + ' ' + args.messages.map(m => m.content).join(' ')).toLowerCase();
    if (target.jsonForceable && sample.includes('json')) {
      body.response_format = { type: 'json_object' };
    }
    const r = await fetch(target.baseURL + '/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + target.apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    const t1 = Date.now();
    const raw = await r.text();
    if (!r.ok) {
      return { ok: false, error: `HTTP ${r.status}: ${raw.slice(0, 240)}`, latency_ms: t1 - t0 };
    }
    let parsed: any = {};
    try { parsed = JSON.parse(raw); }
    catch (_) { return { ok: false, error: 'non-json response: ' + raw.slice(0, 200), latency_ms: t1 - t0 }; }
    const text  = parsed?.choices?.[0]?.message?.content || '';
    const usage = parsed?.usage || {};
    const finishReason = parsed?.choices?.[0]?.finish_reason;
    return {
      ok: true,
      text,
      usage: {
        input_tokens:                 usage.prompt_tokens     || 0,
        output_tokens:                usage.completion_tokens || 0,
        cache_read_input_tokens:      usage.prompt_tokens_details?.cached_tokens || 0,
        cache_creation_input_tokens:  0,
        reasoning_tokens:             usage.completion_tokens_details?.reasoning_tokens || 0,
      },
      latency_ms: t1 - t0,
      cap_applied: cap,
      finish_reason: finishReason,
    };
  } catch (e: any) {
    return { ok: false, error: e?.message || String(e), latency_ms: Date.now() - t0 };
  }
}

async function callForModel(modelId: string, args: {
  system: string;
  messages: LlmMessage[];
  max_tokens?: number;
  temperature?: number;
}): Promise<LlmResult> {
  const fam = family(modelId);
  if (fam === 'anthropic') return callAnthropic(modelId, args);
  if (fam === 'google')    return callGoogle(modelId, args);
  return callOpenAICompat(modelId, args);
}

export async function callLlm(args: {
  system: string;
  messages: LlmMessage[];
  max_tokens?: number;
  temperature?: number;
}): Promise<LlmResult> {
  return callForModel(MODEL_ID, args);
}

/* Pre-pilot health check. Classifies failures so the harness can skip
   the model entirely from the report (per brief 4 sec D). */
export async function modelHealthCheck(modelId: string): Promise<{
  ok: boolean; reason?: string; latency_ms: number;
}> {
  try {
    const r = await callForModel(modelId, {
      system: 'Reply with the single character K and nothing else.',
      messages: [{ role: 'user', content: 'ping' }],
      max_tokens: 8,
      temperature: 0,
    });
    if (r.ok) return { ok: true, latency_ms: r.latency_ms };
    const msg = (r as any).error || '';
    let reason = 'unknown';
    if (/401|unauthorized|api[\s_-]?key|invalid_api_key|incorrect api key/i.test(msg)) reason = 'auth';
    else if (/402|payment|billing|insufficient/i.test(msg)) reason = 'billing';
    else if (/429|rate|quota|throttl/i.test(msg)) reason = 'rate_limit';
    else if (/econnref|enotfound|getaddrinfo|network|timeout/i.test(msg)) reason = 'network';
    else if (/404|not found|model.*not.*exist|decommiss|no longer/i.test(msg)) reason = 'model_unavailable';
    return { ok: false, reason: reason + ':' + msg.slice(0, 80), latency_ms: r.latency_ms };
  } catch (e: any) {
    return { ok: false, reason: 'exception:' + (e?.message || String(e)).slice(0, 80), latency_ms: 0 };
  }
}
