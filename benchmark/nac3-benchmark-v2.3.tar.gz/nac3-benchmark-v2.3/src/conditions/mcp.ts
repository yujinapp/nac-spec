/**
 * Condition C: MCP.
 *
 * The agent receives a tool catalog (derived from the live MCP server)
 * and emits JSON tool invocations. The harness dispatches via the MCP
 * client, feeds results back, and the model iterates until it emits
 * actions=[] (final answer / clarification) or hits max_turns.
 *
 * Architecture note (also documented in REPORT_THREE_WAY.md):
 * the MCP server is a thin client over a shared HTTP backend that
 * also serves the visual fixture. This matches the production
 * architecture of major MCP servers (Asana, GitHub, Linear, etc.)
 * where the MCP layer is a protocol adapter over an existing REST/
 * API backend. The agent in condition C interacts exclusively with
 * the MCP tool surface; the HTTP backend is transparent to it.
 */
import { callLlm, isTruncatedByCap } from './llm.js';
import { Client as McpClient } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import path from 'node:path';

const MAX_TURNS = 10;

export interface McpAction {
  tool: string;
  args: any;
}

export interface ModelOutput {
  message: string;
  actions: McpAction[];
}

export interface ToolCallLog {
  turn: number;
  tool: string;
  args: any;
  started_at_ms: number;
  ended_at_ms: number;
  duration_ms: number;
  ok: boolean;
  result_summary: string;
  result_chars: number;
}

export interface ToolDescriptor {
  name: string;
  description: string;
  inputSchema: any;
}

/* ---- MCP client lifecycle ---- */

let CLIENT: McpClient | null = null;
let TOOL_CATALOG: ToolDescriptor[] = [];
let TOOL_CATALOG_JSON: string = '';

export async function startMcpClient(opts?: { invoiceAppUrl?: string }): Promise<void> {
  if (CLIENT) return;
  const transport = new StdioClientTransport({
    command: process.platform === 'win32' ? 'npx.cmd' : 'npx',
    args: ['tsx', path.resolve('src/mcp_server/index.ts')],
    env: { ...process.env, INVOICE_APP_URL: opts?.invoiceAppUrl || 'http://127.0.0.1:8080' },
  });
  const client = new McpClient({ name: 'bench-harness', version: '0.1.0' });
  await client.connect(transport);
  const r = await client.listTools();
  TOOL_CATALOG = (r.tools || []).map((t: any) => ({
    name: t.name,
    description: t.description || '',
    inputSchema: t.inputSchema || {},
  }));
  TOOL_CATALOG_JSON = formatCatalogForPrompt(TOOL_CATALOG);
  CLIENT = client;
}

export async function stopMcpClient(): Promise<void> {
  if (CLIENT) {
    try { await CLIENT.close(); } catch (_) {}
    CLIENT = null;
  }
}

export function getToolCatalog(): ToolDescriptor[] {
  return TOOL_CATALOG;
}

export function getToolCatalogJson(): string {
  return TOOL_CATALOG_JSON;
}

/* Pretty-format the catalog for the system prompt. Each entry is one
   line of name + short description, followed by indented schema. */
function formatCatalogForPrompt(tools: ToolDescriptor[]): string {
  return tools.map(t => {
    const props = (t.inputSchema && t.inputSchema.properties) || {};
    const required: string[] = (t.inputSchema && t.inputSchema.required) || [];
    const fields = Object.entries(props).map(([k, v]: [string, any]) => {
      const tag = required.includes(k) ? '' : '?';
      const typ = (v && (v.type || (v.enum ? 'enum' : ''))) || 'any';
      const en  = v && Array.isArray(v.enum) ? ` (${v.enum.join('|')})` : '';
      return `${k}${tag}: ${typ}${en}`;
    }).join(', ');
    return `  - ${t.name}(${fields}) :: ${t.description}`;
  }).join('\n');
}

/* ---- Dispatch a single tool call ---- */

export async function dispatchMcpTool(action: McpAction, turnIdx: number): Promise<ToolCallLog> {
  const started_at_ms = Date.now();
  if (!CLIENT) {
    return {
      turn: turnIdx, tool: action.tool, args: action.args,
      started_at_ms, ended_at_ms: started_at_ms,
      duration_ms: 0, ok: false,
      result_summary: 'mcp client not started',
      result_chars: 0,
    };
  }
  if (!TOOL_CATALOG.some(t => t.name === action.tool)) {
    return {
      turn: turnIdx, tool: action.tool, args: action.args,
      started_at_ms, ended_at_ms: Date.now(),
      duration_ms: Date.now() - started_at_ms, ok: false,
      result_summary: `unknown_tool: ${action.tool}`,
      result_chars: 0,
    };
  }
  try {
    const r = await CLIENT.callTool({ name: action.tool, arguments: action.args || {} });
    const blocks = (r.content as any[]) || [];
    const text = blocks.filter(b => b.type === 'text').map(b => b.text).join('\n');
    const ended_at_ms = Date.now();
    return {
      turn: turnIdx, tool: action.tool, args: action.args,
      started_at_ms, ended_at_ms, duration_ms: ended_at_ms - started_at_ms,
      ok: !r.isError,
      result_summary: text,
      result_chars: text.length,
    };
  } catch (e: any) {
    const ended_at_ms = Date.now();
    return {
      turn: turnIdx, tool: action.tool, args: action.args,
      started_at_ms, ended_at_ms, duration_ms: ended_at_ms - started_at_ms, ok: false,
      result_summary: 'exception: ' + (e?.message || String(e)),
      result_chars: 0,
    };
  }
}

/* ---- System + user prompt ---- */

const SYSTEM_PROMPT_MCP = (lang: string, catalogJson: string) => `You operate an invoice management system through structured tool calls. You have NO access to the visual UI. The user describes a task; you fulfill it by composing tool calls in sequence.

Rules:
1. Always start by reading state with list_invoices or get_invoice when the task references something specific.
2. You have access to tool results from previous calls in this conversation.

   When you need data (IDs, customer info, line items, etc), call the relevant tool FIRST. Do not ask the user for data that any tool in your inventory can fetch. Default to calling tools rather than asking.

   If you call a tool and the result is unambiguous, proceed with the task. If the result is ambiguous in a way that no other tool can resolve, ask the user -- but only after you have exhausted relevant tool calls.

   CRITICAL: never claim success in your message unless the corresponding tool call was actually emitted and returned successfully. Reporting "task completed" without emitting tool calls is a contract violation. If your message says you did X, your actions array must include the tool call that performs X.
3. After a write, you may need to read again to confirm the result.
4. Output a single JSON object. NO prose, NO Markdown fences, NO explanation before or after. Your entire response must be the JSON: { "message": "...", "actions": [...] }.

   ABSOLUTE OUTPUT CONTRACT: do NOT emit \`<function_calls>\`, \`<tool_use>\`, \`<function_calls>\`, XML-tagged blocks, or ANY native tool-calling syntax of any model family. Your entire reply is exactly one JSON object with keys "message" and "actions" -- nothing else, no prefix prose, no XML, no Markdown. Tool calls live INSIDE the actions[] array as { "tool": "...", "args": {...} }, never as XML tags. Any content outside the JSON is a contract violation.
5. Actions are tool invocations: { "tool": "...", "args": {...} }.
6. Keep \`message\` brief; it's what the user reads.
7. Reply in language: ${lang}.
8. When you have enough information and no more side-effects are needed, return an empty actions[] with your final message.
9. You can emit multiple tool calls per turn -- they execute in order. Use this for reads that are independent of each other.
10. Sensible defaults: if the task mentions an "open invoice", look it up via get_open_invoice/list_invoices first. If a field is not explicitly given (e.g. payment terms), use the most common default (contado / 30 dias / standard term) and continue -- do not block.

Available tools and their schemas:
${catalogJson}`;

/* ---- Parse model output ---- */
import { parseModelJson } from './parse_json.js';

export function parseMcpOutput(text: string): { ok: true; data: ModelOutput } | { ok: false; reason: string } {
  const r = parseModelJson<any>(text);
  if (!r.ok) return r;
  const message = typeof r.data.message === 'string' ? r.data.message : '';
  const actions = Array.isArray(r.data.actions) ? r.data.actions : [];
  return { ok: true, data: { message, actions } };
}

/* v2.4 fix C (2026-05-19): detect when the model halted to ask the operator
   instead of resolving via tools. Used to quantify the "halt premature"
   pattern (esp. weaker tool-use models like gpt-4o-mini). Multilingual
   patterns since prompts default to es. */
const QUESTION_PATTERNS = [
  /\?\s*$/,                                          /* ends in '?' */
  /\bnecesit(o|amos)\s+(el|la|los|las|saber)\b/i,    /* "necesito el id" */
  /\b(pod(e|i)?(ria|s)|me\s+pasar(i)?as|por\s+favor\s+(dame|indicame))\b/i,
  /\bconfirm(a|as|ar)\b/i,
  /\b(deseas|quer(e|i)s)\s+(continuar|que|confirmar)\b/i,
  /\bcu(a|á)l\s+(es|son)\b/i,
  /\b(which|what|please\s+provide|could\s+you|do\s+you\s+want)\b/i,
];
export function looksLikeQuestionToHuman(msg: string): boolean {
  if (!msg) return false;
  return QUESTION_PATTERNS.some(rx => rx.test(msg));
}

/* ---- Multi-turn driver ---- */

export interface McpTrialUsage {
  total_input_tokens: number;
  total_output_tokens: number;
  total_cache_read_input_tokens: number;
  total_cache_creation_input_tokens: number;
  total_reasoning_tokens: number;
  per_turn_usage: Array<{ turn: number; input_tokens: number; output_tokens: number; cache_read_input_tokens: number; cache_creation_input_tokens: number; reasoning_tokens: number; latency_ms: number }>;
}

export interface McpTrialResult {
  message: string;
  turns: number;
  tool_calls: ToolCallLog[];
  hit_max_turns: boolean;
  usage: McpTrialUsage;
  read_calls: number;
  write_calls: number;
  clarification_emitted: boolean;
  raw_responses: string[];
  /* the final parsed output (the one that exited the loop) */
  final_output: ModelOutput | null;
  parse_errors: string[];
  llm_latency_ms_total: number;
  dispatch_latency_ms_total: number;
  truncated_by_cap: boolean;
  asked_human: boolean;
}

/* Classify a tool name as a read or a write for the metrics. */
const READ_TOOLS = new Set([
  'list_invoices', 'get_invoice', 'get_total', 'list_clients', 'get_wizard_state',
]);

export async function runMcpTrial(args: {
  taskPrompt: string;
  lang: string;
  toolResultMaxChars?: number;
}): Promise<McpTrialResult> {
  if (!CLIENT) throw new Error('MCP client not started -- call startMcpClient first');

  const truncate = args.toolResultMaxChars ?? 6000;
  const messages: Array<{ role: 'user' | 'assistant'; content: string }> = [
    { role: 'user', content: args.taskPrompt },
  ];

  const result: McpTrialResult = {
    message: '',
    turns: 0,
    tool_calls: [],
    hit_max_turns: false,
    usage: {
      total_input_tokens: 0, total_output_tokens: 0,
      total_cache_read_input_tokens: 0, total_cache_creation_input_tokens: 0,
      total_reasoning_tokens: 0,
      per_turn_usage: [],
    },
    read_calls: 0,
    write_calls: 0,
    clarification_emitted: false,
    raw_responses: [],
    final_output: null,
    parse_errors: [],
    llm_latency_ms_total: 0,
    dispatch_latency_ms_total: 0,
    truncated_by_cap: false,
    asked_human: false,
  };

  for (let turn = 1; turn <= MAX_TURNS; turn++) {
    result.turns = turn;
    const llmRes = await callLlm({
      system: SYSTEM_PROMPT_MCP(args.lang, TOOL_CATALOG_JSON),
      messages,
    });
    if (llmRes.ok && isTruncatedByCap(llmRes)) result.truncated_by_cap = true;
    if (!llmRes.ok) {
      result.parse_errors.push(`turn ${turn} api: ${llmRes.error}`);
      result.llm_latency_ms_total += llmRes.latency_ms;
      break;
    }
    result.llm_latency_ms_total += llmRes.latency_ms;
    const usage = llmRes.usage;
    result.usage.total_input_tokens                += usage.input_tokens   || 0;
    result.usage.total_output_tokens               += usage.output_tokens  || 0;
    result.usage.total_cache_read_input_tokens     += usage.cache_read_input_tokens     || 0;
    result.usage.total_cache_creation_input_tokens += usage.cache_creation_input_tokens || 0;
    result.usage.total_reasoning_tokens            += (usage as any).reasoning_tokens   || 0;
    result.usage.per_turn_usage.push({
      turn,
      input_tokens:                 usage.input_tokens  || 0,
      output_tokens:                usage.output_tokens || 0,
      cache_read_input_tokens:      usage.cache_read_input_tokens     || 0,
      cache_creation_input_tokens:  usage.cache_creation_input_tokens || 0,
      reasoning_tokens:             (usage as any).reasoning_tokens   || 0,
      latency_ms: llmRes.latency_ms,
    });

    const raw = (llmRes.text || '').trim();
    result.raw_responses.push(raw);

    const parsed = parseMcpOutput(raw);
    if (!parsed.ok) {
      result.parse_errors.push(`turn ${turn}: ${parsed.reason}`);
      /* On parse error, just append the raw to history as assistant + a
         nudge user message, then try again. Don't bail; let max_turns
         catch infinite loops. */
      messages.push({ role: 'assistant', content: raw });
      messages.push({ role: 'user', content: 'Your response must be a JSON object {message, actions}. Reply again strictly in that format.' });
      continue;
    }

    /* Successful parse. Add the assistant's response to history. */
    messages.push({ role: 'assistant', content: raw });
    result.final_output = parsed.data;

    /* No more actions -> we're done (terminal message or clarification).
       asked_human is computed POST-HOC by the harness using success
       context (see refinedAskedHuman in harness_3way). Here we only
       record the raw question signal. */
    if (parsed.data.actions.length === 0) {
      result.message = parsed.data.message;
      result.clarification_emitted = parsed.data.message.length > 0;
      /* Provisional flag -- harness overrides based on success result. */
      result.asked_human = looksLikeQuestionToHuman(parsed.data.message);
      return result;
    }

    /* Dispatch tool calls and collect logs. */
    const turnResults: ToolCallLog[] = [];
    const tDispatch0 = Date.now();
    for (const a of parsed.data.actions) {
      const log = await dispatchMcpTool(a, turn);
      result.tool_calls.push(log);
      turnResults.push(log);
      if (READ_TOOLS.has(a.tool)) result.read_calls++;
      else if (TOOL_CATALOG.some(t => t.name === a.tool)) result.write_calls++;
    }
    result.dispatch_latency_ms_total += Date.now() - tDispatch0;

    /* Build the tool-result user message for the next turn. */
    const resultLines = turnResults.map((r) => {
      const tail = r.result_chars > truncate
        ? r.result_summary.slice(0, truncate) + `\n... [truncated ${r.result_chars - truncate} chars]`
        : r.result_summary;
      return `Tool ${r.tool} (${r.ok ? 'ok' : 'error'}): ${tail}`;
    });
    messages.push({ role: 'user', content: 'Tool results:\n' + resultLines.join('\n\n') });
  }

  result.hit_max_turns = true;
  result.message = result.final_output?.message || '';
  return result;
}

/* ---- Public utility: page state sync after MCP mutations ---- */

export async function pushBackendStateToPage(page: any, baseUrl = 'http://127.0.0.1:8080'): Promise<void> {
  const state = await fetch(baseUrl + '/api/state').then(r => r.json());
  await page.evaluate((s: any) => {
    const w = window as any;
    if (typeof w.__pushState === 'function') w.__pushState(s);
  }, state);
}
