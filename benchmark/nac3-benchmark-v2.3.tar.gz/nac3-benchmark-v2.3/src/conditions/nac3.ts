/**
 * Condition A: NAC3.
 *
 * The agent receives NAC.describe() + NAC.describe_v2() of the current
 * page snapshot. The system prompt is the contract from
 * vendor/nac-spec/guides/LLM_WIRING.md section 2 rules 1-9.
 * The agent emits structured NAC3 actions. The harness dispatches
 * via the page's NAC runtime (which validates before touching the DOM).
 */
import type { Page } from 'playwright';
import { callLlm, LlmMessage, isTruncatedByCap } from './llm.js';

export interface NacAction {
  kind: string;
  nac_id?: string;
  verb?: string;
  plugin?: string | null;
  tab_key?: string;
  label?: string;
  value?: string | number | boolean;
  locale?: string;
  text?: string;
  table_id?: string;
  row_id?: string;
  column?: string;
  agg_key?: string;
  values?: Record<string, any>;
  [k: string]: any;
}

export interface ModelOutput {
  message: string;
  actions: NacAction[];
}

export interface RunStepResult {
  input_tokens: number;
  output_tokens: number;
  cache_read_input_tokens: number;
  cache_creation_input_tokens: number;
  total_cost_usd: number;
  llm_latency_ms: number;
  dispatch_latency_ms: number;
  n_actions_emitted: number;
  target_emitted_resolved: boolean;
  target_reached_dom: boolean;
  hallucinated_target: boolean;
  error_class: 'timeout' | 'not_found' | 'invalid_action' | 'post_condition_failed' | 'parse_error' | 'ok' | 'api_error';
  error_detail: string;
  raw_request: string;
  raw_response: string;
  parsed_output: ModelOutput | null;
  dispatch_results: Array<{ kind: string; ok: boolean; error?: string }>;
  clarification_emitted: boolean;
}

/**
 * Build the NAC3 snapshot for the page. We expose this from inside
 * the page context via `window.NAC.describe()` and `describe_v2()`,
 * which is exactly what NacChat.snapshotTree() does in production --
 * minus two production prunes documented in
 * vendor/nac-spec/guides/LLM_WIRING.md sec 5 ("Snapshot size"):
 *
 *   1. Single-locale labels: collapse label_i18n{10 locales} -> label
 *      in the active lang. The agent only replies in one language; the
 *      other 9 locales are dead context.
 *   2. Role filter: drop role=section / region / navigation elements
 *      that the agent rarely targets directly.
 *
 * These are NOT benchmark optimisations; they are what the Yujin
 * production deployment of NAC3 already does. The brief calls for the
 * snapshot to look like what a real NAC3 agent receives.
 */
const RELEVANT_ROLES = ['action', 'tab', 'field', 'option', 'confirm-button',
  'sort-control', 'filter-control', 'accordion-toggle', 'data-table'];

export async function snapshotNac3(page: Page, opts?: { lang?: string }): Promise<any> {
  const lang = opts?.lang || 'es';
  /* The function body is built as an IIFE string so Playwright's
     `page.evaluate` evaluates it directly in the browser context
     without tsx/esbuild injecting `__name` helpers (which are not
     defined in the page). */
  const arg = JSON.stringify({ lang, relevantRoles: RELEVANT_ROLES });
  return await page.evaluate(`(function () {
    var arg = ${arg};
    var lang = arg.lang;
    var roles = arg.relevantRoles;
    var w = window;
    if (!w.NAC || typeof w.NAC.describe !== "function") return { error: "NAC runtime not loaded" };
    /* v2.4 brief sec 4 -- capture authoritative runtime version (NAC.version
       global, e.g. "2.2.1") for academic traceability. Snapshot's per-plugin
       nac_version (often "1.0") is plugin-manifest version, not runtime. */
    var __nac_runtime_version__ = w.NAC.version || "unknown";
    var base = w.NAC.describe();
    base.nac_runtime_version = __nac_runtime_version__;
    var v2 = { v2_scope_entries: [], data_tables: [], sitemap: null };
    try { if (typeof w.NAC.describe_v2 === "function") v2 = w.NAC.describe_v2(); } catch (_) {}
    var pickLabel = function (li) {
      if (!li || typeof li !== "object") return undefined;
      return li[lang] || li.es || li.en;
    };
    var compactActions = function (arr) {
      return (arr || []).map(function (a) {
        var o = {};
        for (var ak in a) if (Object.prototype.hasOwnProperty.call(a, ak)) {
          if (ak === "label_i18n") o.label = pickLabel(a[ak]);
          else o[ak] = a[ak];
        }
        return o;
      });
    };
    /* Strip null fields and known-defaults to cut snapshot size. The
       agent doesn't need to see e.g. value:null on every action element. */
    var DEFAULT_DROP = {
      state: 'idle', disabled: false, undoable: false,
    };
    var DROP_KEYS = ['a11y_hint', 'braille_label', 'error', 'field_type',
                     'value', 'plugin' /* plugin context provided by enclosing group */,
                     /* v2.4 / RFC V24-04: V24-04 enriches describe() with
                        element_state_hash + plugin_version + tree_version.
                        For the baseline-gate snapshot we strip these so
                        the prompt size + content stay identical to the
                        pre-V24-04 baseline. Paso 3+ may re-enable some
                        to exercise the optimistic concurrency contract. */
                     'element_state_hash'];
    /* For HIDDEN elements we keep only the planning-minimum: nac_id,
       role, label, visible. The agent can plan around them (knows they
       exist after navigation) without carrying their state/action
       metadata. Visible elements keep full detail. */
    var HIDDEN_KEEP = { nac_id: 1, role: 1, label: 1, visible: 1, action: 1, label_i18n: 1, actions: 1 };
    var compactElement = function (e) {
      if (!e || typeof e !== "object") return e;
      var isHidden = e.visible === false;
      var out = {};
      for (var k in e) if (Object.prototype.hasOwnProperty.call(e, k)) {
        if (e[k] === null || e[k] === undefined) continue;
        if (DROP_KEYS.indexOf(k) >= 0) continue;
        if (Object.prototype.hasOwnProperty.call(DEFAULT_DROP, k) && DEFAULT_DROP[k] === e[k]) continue;
        if (isHidden && !HIDDEN_KEEP[k]) continue;
        if (k === "label_i18n") out.label = pickLabel(e[k]);
        else if (k === "actions" && Array.isArray(e[k])) {
          var compacted = compactActions(e[k]);
          if (compacted.length > 0) out.actions = compacted;
        } else out[k] = e[k];
      }
      return out;
    };
    var compactRowDef = function (r) {
      if (!r || typeof r !== "object") return r;
      var out = {};
      for (var k in r) if (Object.prototype.hasOwnProperty.call(r, k)) {
        if (k === "label_i18n") out.label = pickLabel(r[k]);
        else out[k] = r[k];
      }
      return out;
    };
    var compactTable = function (dt) {
      if (!dt || typeof dt !== "object") return dt;
      var sch = dt.schema || {};
      var cs = {};
      for (var sk in sch) if (Object.prototype.hasOwnProperty.call(sch, sk)) cs[sk] = sch[sk];
      if (Array.isArray(sch.columns)) cs.columns = sch.columns.map(compactRowDef);
      if (sch.row_axis)    { cs.row_axis    = { values: (sch.row_axis.values    || []).map(compactRowDef), label: pickLabel(sch.row_axis.label_i18n)    }; }
      if (sch.column_axis) { cs.column_axis = { values: (sch.column_axis.values || []).map(compactRowDef), label: pickLabel(sch.column_axis.label_i18n) }; }
      var out = {};
      for (var dk in dt) if (Object.prototype.hasOwnProperty.call(dt, dk)) out[dk] = dt[dk];
      out.schema = cs;
      /* v2.4 size prune: when a table is current_visibility="hidden"
         (its owning panel is closed/inactive), omit the row data. The
         agent can plan around the schema; the rows would be unreachable
         until the panel is visible anyway. */
      if (out.current_visibility === 'hidden' && out.current_state && Array.isArray(out.current_state.rows)) {
        out.current_state = {
          row_count: out.current_state.rows.length,
          rows_omitted_reason: 'table_hidden -- open the owning panel to see rows',
        };
      }
      return out;
    };
    var plugins = (base.plugins || []).map(function (p) {
      return {
        plugin: p.plugin,
        state: p.state,
        /* Keep hidden elements so the agent can plan ahead: it knows
           which targets become reachable after navigation actions. */
        elements: (p.elements || [])
          .filter(function (e) { return !e.role || roles.indexOf(e.role) >= 0; })
          .map(compactElement),
      };
    });
    var dts = (v2.data_tables || []).map(compactTable);

    /* v2.4 snapshot annotation: cross-reference button actions with
       data-table supports. If a button's verb matches a primitive on
       a data-table whose scope_owner is the button's plugin, annotate
       the button with companion_primitive so the agent knows the
       atomic alternative exists. */
    var verbToPrim = { add_row: 'dt_add_row', remove_row: 'dt_remove_row',
                       edit_cell: 'dt_edit_cell' };
    for (var pi = 0; pi < plugins.length; pi++) {
      var pp = plugins[pi];
      for (var ei = 0; ei < pp.elements.length; ei++) {
        var el = pp.elements[ei];
        var verb = el.action || (el.actions && el.actions[0] && el.actions[0].verb);
        if (!verb || !verbToPrim[verb]) continue;
        for (var di = 0; di < dts.length; di++) {
          var dt = dts[di];
          var ow = dt.schema && dt.schema.scope_owner;
          var supports = (dt.schema && dt.schema.supports) || [];
          if (supports.indexOf(verb) < 0) continue;
          /* match by scope_owner mentioning the plugin slug OR by table_id starting with it. */
          var matches = (ow && ow.indexOf(pp.plugin) >= 0)
                     || (dt.table_id && dt.table_id.indexOf(pp.plugin) === 0);
          if (matches) {
            el.companion_primitive = verbToPrim[verb] + '(' + dt.table_id + ', {values})';
            el.prefer_primitive = true;
            break;
          }
        }
      }
    }

    return {
      active: base.active || null,
      plugins: plugins,
      data_tables: dts,
      nac_runtime_version: __nac_runtime_version__,
    };
  })()`);
}

const SYSTEM_PROMPT_NAC3 = (lang: string) => `You drive a web UI by emitting structured NAC actions.

Rules:
1. Resolve the user's intent against the NAC tree below. Prefer
   click_by_verb when a verb matches; fall back to click(nac_id)
   only if no verb fits.
2. For tab switching, use tab() with the plugin + tab_key from
   the manifest, NOT click().
3. NEVER invent nac_ids OR verbs. Every action MUST reference a
   name that literally appears in the snapshot.
   - For kind:"click", the nac_id must equal some
     plugins[*].elements[*].nac_id.
   - For kind:"click_by_verb", the verb must equal some
     plugins[*].elements[*].actions[*].verb under that plugin AND
     the matching element must be visible:true OR reachable after a
     navigation action you also emit. Do NOT call click_by_verb on
     a plugin slug with a verb that is not declared on any element
     of that plugin -- inventing parameterised shortcuts (e.g.
     calling click_by_verb on the listing plugin with verb="cancel"
     + args.invoice_id when the listing only carries per-row
     "invoice.<ID>.cancel" buttons) leads to "verb not found"
     dispatch failures.
   - To act on a specific instance whose nac_id encodes the
     instance (e.g. invoice_app.invoice.INV-0001.cancel), use
     kind:"click" with that exact nac_id. The instance id IS the
     handle; do not strip it into a plugin-level verb call.
   If you cannot find a matching name, ask the user a clarifying
   question via {message} with empty actions[].
4. Reply in language: ${lang}.
5. Output a single JSON object. NO prose, NO Markdown fences, NO explanation before or after. Your entire response must be the JSON.
   { "message": "...", "actions": [...] }
6. message is what the user sees + hears. Keep it short (one
   sentence is ideal).
7. If the user said "cambia a <language>" emit a single
   change_locale action with the 2-letter code.
8. For data-tables: use dt_add_row / dt_remove_row / dt_edit_cell /
   dt_commit / dt_discard. Compute aggregates with dt_read_aggregate
   then read in the message.

   IMPORTANT: dt_add_row(table_id, values) is ATOMIC. It creates a new
   row with the values you provide in ONE call -- you do NOT click the
   "add row" button and then dt_edit_cell each field. Prefer dt_add_row
   over clicking the host's add-row button whenever you already have
   the row's content. The button is for end users; the primitive is
   for agents.
9. Bare 2-letter locale codes ('de','es','en') are language codes
   ONLY when followed/preceded by an explicit language word
   ('idioma', 'language', 'sprache'). 'cambia DE pestana' is NOT
   German -- 'de' here is the Spanish preposition.

Multi-step tasks: your response IS the entire plan. You can emit ANY
number of actions in actions[]; they execute in order. For tasks that
require multiple steps (e.g. switch tabs, then fill multiple fields, then
click confirm), include ALL the steps in one response.

Confirmation dialogs: if a destructive action (cancel / delete) opens a
confirm dialog registered in the snapshot (e.g. plugin confirm_cancel),
EITHER:
  (a) include BOTH the trigger click AND the confirm click in the same
      actions[] list (in that order), OR
  (b) use the atomic form via click_by_verb with args.confirm=true to
      skip the dialog (e.g.
      {kind:"click_by_verb", plugin:"invoice_app", verb:"cancel",
       args:{invoice_id:"INV-0001", confirm:true}}).
Emitting only the confirm click without the trigger click leaves the
dialog closed; the runtime rejects with "not visible".

Data tables (v2.4 strict supports): each table in data_tables[] declares
a "supports" array (e.g. ["add_row","remove_row","edit_cell"]). Calling
dt_add_row / dt_remove_row / dt_edit_cell on a table that does NOT list
the operation in supports[] throws an error. Read the supports field
before emitting dt_* actions. A table with supports=[] is read-only.

Data tables (current_visibility): each table also reports current_visibility
("visible" | "hidden") based on whether its owning DOM region is rendered.
If a table is hidden you must first switch the relevant tab/section so it
becomes visible; the runtime will reject dt_* on hidden tables.

Data tables (target the right one): the snapshot may expose several data
tables sharing the same domain -- one outer "list-of-records" table for
browsing + one inner "edit-scope" table for the row currently being
authored. They are NOT interchangeable.

  - Outer/list tables (e.g. invoice_app.invoice_directory) declare
    scope_owner pointing at the top-level plugin, supports=[] or only
    read aggregates, and current_state.rows that mirror what the user
    sees in the listing. These are READ-ONLY directory views; never
    emit dt_add_row / dt_edit_cell / dt_remove_row on them.
  - Edit-scope tables (e.g. invoice_edit_modal.lines) declare
    scope_owner pointing at a modal or panel, carry supports with the
    mutation verbs, and only become current_visibility:"visible" once
    that modal/panel is open. These are the writeable ones.

When you intend to add a line to "the invoice being edited", pick the
table whose scope_owner matches the currently-open modal -- not the
table that holds the listing of every invoice. If both tables claim
the same surface, the supports[] field is the decider: a table with a
non-empty supports[] is the agent-facing one.

Elements visibility (v2.4): each element in plugins[*].elements[] reports
a "visible" boolean.

  - visible:true  -- you can target it right now.
  - visible:false -- the element exists in the manifest but is hidden
                     (different tab, modal closed, panel collapsed).
                     Targeting it as-is raises "is not visible". Insert
                     the right tab()/parent click() BEFORE the action so
                     the element transitions to visible. The runtime
                     awaits the state change before the next action.

Plan your actions[] in execution order: include the navigation step
that exposes a target before the action that uses it.

Tab nac_ids in this fixture: tab nac_ids carry the reserved "tab." prefix
per spec sec 2 (e.g. "tab.cliente", "tab.lineas"). Copy the EXACT id from
the snapshot when emitting kind:"tab" tab_key=... -- do not shorten.

Snapshot labels (single-locale): each element's "label" field carries the
host's label in the user's current language. The 10-locale label_i18n map
is pre-collapsed; do not expect it.

Action JSON shape (every action object MUST use the field name "kind"
as discriminator). Use only these kinds + required fields:

   { "kind": "click",          "nac_id": "<id>" }
   { "kind": "click_by_verb",  "plugin": "<plugin>", "verb": "<verb>", "args"?: { ... } }

   click_by_verb's third arg "args" is a payload for the host's handler
   (v2.3/v2.4 parameterised action). When an action represents a data
   mutation that needs values (e.g. add a line with description+qty+
   price), include them in args and the host applies them atomically.
   Example for adding a row with values atomically via a button verb:
     { "kind": "click_by_verb", "plugin": "invoice_edit_modal",
       "verb": "add_row",
       "args": { "description": "consultoria", "qty": 10, "unit_price": 150 } }
   { "kind": "fill",           "nac_id": "<id>", "value": <string|number|boolean> }
   { "kind": "select",         "nac_id": "<id>", "value": "<option>" }
   { "kind": "tab",            "plugin": "<plugin>", "tab_key": "<tab_key>" }
   { "kind": "tab_by_label",   "plugin": "<plugin>"|null, "label": "<label>" }
   { "kind": "go_to_section",  "nac_id": "<id>" }
   { "kind": "change_locale",  "locale": "<2-letter>" }
   { "kind": "say",            "text": "<text>" }
   { "kind": "dt_add_row",         "table_id": "<table_id>", "values": { ... } }
   { "kind": "dt_remove_row",      "table_id": "<table_id>", "row_id": "<row_id>" }
   { "kind": "dt_edit_cell",       "table_id": "<table_id>", "row_id": "<row_id>", "column": "<col>", "value": <any> }
   { "kind": "dt_commit",          "table_id": "<table_id>" }
   { "kind": "dt_discard",         "table_id": "<table_id>" }
   { "kind": "dt_read_aggregate",  "table_id": "<table_id>", "agg_key": "sum"|"count"|..., "column": "<col>" }`;

function userPromptNac3(snapshot: any, task: string): string {
  /* Compact JSON to save tokens. The agent does not need pretty-printing. */
  return `Task: ${task}

NAC tree snapshot (JSON):
${JSON.stringify(snapshot)}

Respond with the JSON object only.`;
}

/**
 * Parse the model output. Anthropic returns text; we expect JSON.
 * Tolerates prose-before-JSON via the shared extractJsonObject helper.
 */
import { parseModelJson } from './parse_json.js';

export function parseOutput(text: string): { ok: true; data: ModelOutput } | { ok: false; reason: string } {
  const r = parseModelJson<any>(text);
  if (!r.ok) return r;
  const message = typeof r.data.message === 'string' ? r.data.message : '';
  const actions = Array.isArray(r.data.actions) ? r.data.actions : [];
  return { ok: true, data: { message, actions } };
}

export async function dispatchNac3Action(page: Page, action: NacAction): Promise<{ ok: boolean; error?: string }> {
  try {
    const result = await page.evaluate(async (a: NacAction) => {
      const w = window as any;
      if (!w.NAC) return { ok: false, error: 'NAC not loaded' };
      try {
        switch (a.kind) {
          case 'click':
            await w.NAC.click(a.nac_id);
            return { ok: true };
          case 'click_by_verb':
            /* v2.3 preview pattern: third arg is a payload for the verb's
               handler. Forward whatever the agent emitted as args. */
            await w.NAC.click_by_verb(a.plugin || null, a.verb, a.args);
            return { ok: true };
          case 'fill': {
            /* If the target is a <select>, try value first; on mismatch
               (no matching <option value>) fall back to matching by
               visible text. Models sometimes emit the client NAME when
               the option value is an id (or vice versa). */
            const els = document.querySelectorAll('[data-nac-id="' + (a.nac_id || '').replace(/"/g,'\\"') + '"]');
            if (els.length === 1 && els[0].tagName === 'SELECT') {
              const sel = els[0] as HTMLSelectElement;
              const v = String(a.value);
              const lower = v.toLowerCase();
              let matched = false;
              for (let i = 0; i < sel.options.length; i++) {
                if (sel.options[i].value === v) { sel.selectedIndex = i; matched = true; break; }
              }
              if (!matched) {
                for (let i = 0; i < sel.options.length; i++) {
                  if (sel.options[i].text.toLowerCase().indexOf(lower) >= 0) { sel.selectedIndex = i; matched = true; break; }
                }
              }
              if (matched) {
                sel.dispatchEvent(new Event('input',  { bubbles: true }));
                sel.dispatchEvent(new Event('change', { bubbles: true }));
                return { ok: true };
              }
              return { ok: false, error: 'no matching option in select for value ' + v };
            }
            await w.NAC.fill(a.nac_id, a.value);
            return { ok: true };
          }
          case 'select': {
            /* Same tolerance as fill: when the agent passes a label
               instead of an option value (e.g. "Acme" vs "C-001"),
               fall back to text-match. */
            const els = document.querySelectorAll('[data-nac-id="' + (a.nac_id || '').replace(/"/g,'\\"') + '"]');
            if (els.length === 1 && els[0].tagName === 'SELECT') {
              const sel = els[0] as HTMLSelectElement;
              const v = String(a.value);
              const lower = v.toLowerCase();
              let matched = false;
              for (let i = 0; i < sel.options.length; i++) {
                if (sel.options[i].value === v) { sel.selectedIndex = i; matched = true; break; }
              }
              if (!matched) {
                for (let i = 0; i < sel.options.length; i++) {
                  if (sel.options[i].text.toLowerCase().indexOf(lower) >= 0) { sel.selectedIndex = i; matched = true; break; }
                }
              }
              if (matched) {
                sel.dispatchEvent(new Event('input',  { bubbles: true }));
                sel.dispatchEvent(new Event('change', { bubbles: true }));
                return { ok: true };
              }
              return { ok: false, error: 'no matching option in select for value ' + v };
            }
            await w.NAC.select(a.nac_id, a.value);
            return { ok: true };
          }
          case 'tab':
            await w.NAC.tab(a.plugin, a.tab_key);
            return { ok: true };
          case 'tab_by_label':
            await w.NAC.tab_by_label(a.plugin || null, a.label);
            return { ok: true };
          case 'go_to_section':
            await w.NAC.go_to_section(a.nac_id);
            return { ok: true };
          case 'change_locale':
            if (w.NacChat && typeof w.NacChat.setLang === 'function') {
              w.NacChat.setLang(a.locale);
            }
            const sel = document.getElementById('chat-lang') as HTMLSelectElement | null;
            if (sel) { sel.value = a.locale!; sel.dispatchEvent(new Event('change', { bubbles: true })); }
            document.documentElement.setAttribute('lang', a.locale!);
            return { ok: true };
          case 'say':
            return { ok: true };
          case 'dt_add_row':
            if (typeof w.NAC.awaitDataTable === 'function') await w.NAC.awaitDataTable(a.table_id);
            w.NAC.dt_add_row(a.table_id, a.values || {});
            return { ok: true };
          case 'dt_remove_row':
            if (typeof w.NAC.awaitDataTable === 'function') await w.NAC.awaitDataTable(a.table_id);
            w.NAC.dt_remove_row(a.table_id, a.row_id);
            return { ok: true };
          case 'dt_edit_cell':
            if (typeof w.NAC.awaitDataTable === 'function') await w.NAC.awaitDataTable(a.table_id);
            w.NAC.dt_edit_cell(a.table_id, a.row_id, a.column, a.value);
            return { ok: true };
          case 'dt_commit':
            if (typeof w.NAC.awaitDataTable === 'function') await w.NAC.awaitDataTable(a.table_id);
            w.NAC.dt_commit(a.table_id);
            return { ok: true };
          case 'dt_discard':
            if (typeof w.NAC.awaitDataTable === 'function') await w.NAC.awaitDataTable(a.table_id);
            w.NAC.dt_discard(a.table_id);
            return { ok: true };
          case 'dt_read_aggregate':
            if (typeof w.NAC.awaitDataTable === 'function') await w.NAC.awaitDataTable(a.table_id);
            w.NAC.dt_read_aggregate(a.table_id, a.agg_key, a.column);
            return { ok: true };
          default:
            return { ok: false, error: `unknown kind: ${a.kind}` };
        }
      } catch (e: any) {
        return { ok: false, error: String(e?.message || e) };
      }
    }, action);
    return result;
  } catch (e: any) {
    return { ok: false, error: `playwright eval: ${e.message}` };
  }
}

/**
 * Validate an action against a snapshot, returning whether the target
 * (nac_id / verb / tab_key) exists somewhere in the snapshot.
 */
export function validateAgainstSnapshot(action: NacAction, snapshot: any): boolean {
  const plugins = snapshot?.plugins || [];
  /* NAC.describe() uses `nac_id` on elements, not `id`. Accept both. */
  function elIdOf(e: any): string | undefined { return e?.nac_id || e?.id; }
  /* describe() also flattens the manifest verb into element.action. */
  function elVerbOf(e: any): string | undefined {
    if (e?.action) return e.action;
    const list = e?.actions;
    if (Array.isArray(list) && list[0] && list[0].verb) return list[0].verb;
    return undefined;
  }
  function findIdInPlugins(id?: string): boolean {
    if (!id) return false;
    for (const p of plugins) {
      const els = p.elements || [];
      if (els.some((e: any) => elIdOf(e) === id)) return true;
    }
    return false;
  }
  function findVerbInPlugins(verb?: string, plugin?: string | null): boolean {
    if (!verb) return false;
    for (const p of plugins) {
      if (plugin && p.plugin !== plugin) continue;
      const els = p.elements || [];
      if (els.some((e: any) => elVerbOf(e) === verb)) return true;
    }
    return false;
  }
  function findTabInPlugins(plugin: string | undefined, tab_key?: string): boolean {
    if (!plugin || !tab_key) return false;
    /* v2.4 fix D2 (2026-05-19): plugin manifests expose tabs as elements
       with nac_id of the form `tab.{tab_key}` (e.g. `tab.cliente`).
       Older code only accepted the bare tab_key, which made every NAC3
       tab action fail validation in invoice_edit_modal -> allResolved=false
       -> hallucination_category falsely flagged as reached_succeeded.
       Accept both forms so honest tab navigation isn't penalized while
       still rejecting tabs that don't exist in the manifest at all. */
    for (const p of plugins) {
      if (p.plugin !== plugin) continue;
      const els = p.elements || [];
      if (els.some((e: any) => {
        const id = elIdOf(e);
        return id === tab_key || id === `tab.${tab_key}`;
      })) return true;
    }
    return false;
  }
  function findTableInPlugins(table_id?: string): boolean {
    if (!table_id) return false;
    const dtList = snapshot?.data_tables || [];
    if (dtList.some((dt: any) => dt.table_id === table_id || dt.id === table_id)) return true;
    for (const p of plugins) {
      const els = p.elements || [];
      if (els.some((e: any) => elIdOf(e) === table_id)) return true;
    }
    return false;
  }
  switch (action.kind) {
    case 'click':
    case 'fill':
    case 'select':
    case 'go_to_section':
      return findIdInPlugins(action.nac_id);
    case 'click_by_verb':
      return findVerbInPlugins(action.verb, action.plugin);
    case 'tab':
      return findTabInPlugins(action.plugin || undefined, action.tab_key);
    case 'tab_by_label':
      return !!action.label; // label match is fuzzy; defer to runtime
    case 'change_locale':
    case 'say':
      return true;
    default:
      if (action.kind && action.kind.startsWith('dt_')) {
        /* Be permissive at the validator level: the NAC runtime
           itself will refuse missing tables / disallowed ops (v2.4
           supports[] enforcement). Counting a missing table_id as a
           hallucination here would trigger spurious retries in the
           common case where the snapshot's data_tables[] entries are
           pruned for size. The dispatcher's actual call returns
           ok=false with the real error if the table doesn't exist. */
        return !!action.table_id;
      }
      return false;
  }
}

export async function callModelNac3(args: {
  snapshot: any;
  task: string;
  lang: string;
}): Promise<{
  ok: true; usage: any; latency_ms: number; raw_text: string;
  cap_applied: number; finish_reason?: string; truncated_by_cap: boolean;
} | {
  ok: false; error: string; latency_ms: number;
}> {
  const system = SYSTEM_PROMPT_NAC3(args.lang);
  const user   = userPromptNac3(args.snapshot, args.task);
  const r = await callLlm({ system, messages: [{ role: 'user', content: user }] });
  if (!r.ok) return { ok: false, error: r.error, latency_ms: r.latency_ms };
  return {
    ok: true, usage: r.usage, latency_ms: r.latency_ms, raw_text: r.text,
    cap_applied: r.cap_applied, finish_reason: r.finish_reason,
    truncated_by_cap: isTruncatedByCap(r),
  };
}
