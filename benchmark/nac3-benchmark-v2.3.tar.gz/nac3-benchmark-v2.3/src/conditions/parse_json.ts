/**
 * Robust JSON object extraction from a model response.
 *
 * Why this matters: Claude sometimes emits prose preamble before the
 * JSON object ("Voy a hacer X. ```json\n{...}\n```"). A strict
 * "must start with {" parser counted those as parse_error and burned
 * retries. This helper extracts the first balanced top-level JSON
 * object from the text. If the text starts with a Markdown fence, the
 * fenced content is tried first.
 *
 * Returns:
 *   { ok: true,  data }      -- parse succeeded
 *   { ok: false, reason }    -- no JSON object could be parsed
 */
export interface ParseResult<T> {
  ok: true; data: T;
}
export interface ParseError {
  ok: false; reason: string;
}

export function extractJsonObject(text: string): string | null {
  /* 1. Try fenced ```json ... ``` block anywhere in the text. */
  const fence = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
  if (fence) {
    const candidate = fence[1].trim();
    if (candidate.startsWith('{')) return candidate;
  }
  /* 2. Find first balanced { ... } at top level. */
  const start = text.indexOf('{');
  if (start < 0) return null;
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (escape) { escape = false; continue; }
    if (inString) {
      if (c === '\\') escape = true;
      else if (c === '"') inString = false;
      continue;
    }
    if (c === '"') inString = true;
    else if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

export function parseModelJson<T = any>(text: string): ParseResult<T> | ParseError {
  const candidate = extractJsonObject(text);
  if (!candidate) return { ok: false, reason: 'no JSON object found in response' };
  try {
    const data = JSON.parse(candidate);
    if (typeof data !== 'object' || data === null) {
      return { ok: false, reason: 'parsed value is not an object' };
    }
    return { ok: true, data: data as T };
  } catch (e: any) {
    return { ok: false, reason: `JSON parse: ${e.message}` };
  }
}
