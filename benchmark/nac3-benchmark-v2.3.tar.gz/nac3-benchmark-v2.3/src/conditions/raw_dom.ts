/**
 * Condition B: raw DOM.
 *
 * The agent receives a serialized HTML snapshot + an accessibility
 * snapshot (page.accessibility.snapshot()). It emits Playwright-style
 * actions over CSS selectors. The harness dispatches with
 * page.locator(selector).<action>().
 *
 * Anti-strawman: this is what real headless agents have today. No
 * vision/screenshot. ARIA + HTML id + class is fair game.
 */
import type { Page, Locator } from 'playwright';
import { callLlm, isTruncatedByCap } from './llm.js';

export interface RawAction {
  kind: string;
  selector?: string;
  value?: string | number | boolean;
  text?: string;
  locale?: string;
  [k: string]: any;
}

export interface ModelOutput {
  message: string;
  actions: RawAction[];
}

const SYSTEM_PROMPT_RAW = (lang: string) => `You drive a web UI by emitting Playwright-compatible actions over CSS selectors.

Rules:
1. You receive (a) the page HTML, lightly cleaned, and (b) an accessibility tree snapshot. Use them to pick precise CSS selectors. Use accessible names (aria-label, button text, role) before structural selectors.
2. NEVER invent selectors. Every selector must match exactly one element in the page. If you cannot identify a unique target, ask the user a clarifying question via {message} with empty actions[].
3. Reply in language: ${lang}.
4. Output a single JSON object. NO prose, NO Markdown fences, NO explanation before or after. Your entire response must be the JSON.
   { "message": "...", "actions": [...] }
5. message is what the user sees + hears. Keep it short (one sentence is ideal).
6. Action kinds and required fields:
   - { "kind": "click", "selector": "#id" }
   - { "kind": "fill",  "selector": "#id", "value": "..." }
   - { "kind": "select", "selector": "#id", "value": "..." }
   - { "kind": "press", "selector": "#id", "key": "Enter" }
   - { "kind": "set_locale", "locale": "en" }    // changes #chat-lang select + dispatches change
   - { "kind": "say", "text": "..." }            // no DOM action
7. Tab switching: emit a click on the tab button. Tabs are <button role="tab" data-tab="..."> in this app.
8. To remove a row in the lines table, click the row's "Remove row Lx" button (aria-label="Remove row L<id>").
9. To add a row, click "+ Add line" then fill the new row's "Product for row Lx", "Qty for row Lx" inputs by aria-label and dispatch a change event (your "fill" already does that).
10. The unit_price input is disabled in the DOM; if you need to seed a price on a new row, fill the input anyway -- the harness will dispatch the change event.
11. To discard pending table edits without closing the modal, click the "Discard pending" button (aria-label="Discard pending table changes"). The plain Cancel button DISCARDS AND CLOSES the modal.
12. Locale change: emit set_locale with the 2-letter code. Bare 2-letter codes ('de','es','en') are language codes ONLY when followed/preceded by an explicit language word ('idioma','language','sprache'); 'cambia DE pestana' is NOT German.
13. Multi-step tasks: your response IS the entire plan. Include ALL the clicks/fills in one response in the right order. For tasks that require switching tabs and then filling fields, emit the tab click followed by the field fills in the same actions[] array.
14. Confirmation dialogs: if a destructive action (cancel / delete) opens a confirmation dialog (id="confirm-cancel-modal" with btn-confirm-cancel-yes / btn-confirm-cancel-no in this app), emit the confirm click in the same response. Otherwise the operation is incomplete.`;

/** Lightly truncated HTML, stripped of script tags + comments. */
async function serializeHtml(page: Page): Promise<string> {
  return await page.evaluate(() => {
    const clone = document.documentElement.cloneNode(true) as HTMLElement;
    clone.querySelectorAll('script').forEach((s) => s.remove());
    clone.querySelectorAll('style').forEach((s) => s.remove());
    // strip comment nodes
    const walker = document.createTreeWalker(clone, NodeFilter.SHOW_COMMENT);
    const comments: Comment[] = [];
    let c: Node | null;
    while ((c = walker.nextNode())) comments.push(c as Comment);
    comments.forEach((cc) => cc.parentNode && cc.parentNode.removeChild(cc));
    return '<!doctype html>\n' + clone.outerHTML;
  });
}

export async function snapshotRawDom(page: Page): Promise<{ html: string; accessibility: any }> {
  const html = await serializeHtml(page);
  const accessibility = await page.accessibility.snapshot({ interestingOnly: true });
  return { html, accessibility };
}

function userPromptRaw(html: string, a11y: any, task: string): string {
  return `Task: ${task}

Page HTML (cleaned, scripts removed):
${html}

Accessibility tree (interestingOnly=true):
${JSON.stringify(a11y, null, 2)}

Respond with the JSON object only.`;
}

import { parseModelJson } from './parse_json.js';

export function parseOutput(text: string): { ok: true; data: ModelOutput } | { ok: false; reason: string } {
  const r = parseModelJson<any>(text);
  if (!r.ok) return r;
  const message = typeof r.data.message === 'string' ? r.data.message : '';
  const actions = Array.isArray(r.data.actions) ? r.data.actions : [];
  return { ok: true, data: { message, actions } };
}

export async function dispatchRawAction(page: Page, action: RawAction): Promise<{ ok: boolean; error?: string }> {
  try {
    switch (action.kind) {
      case 'click': {
        if (!action.selector) return { ok: false, error: 'missing selector' };
        const loc = page.locator(action.selector);
        const count = await loc.count();
        if (count !== 1) return { ok: false, error: `selector matched ${count} elements` };
        await loc.click({ timeout: 2000 });
        return { ok: true };
      }
      case 'fill': {
        if (!action.selector) return { ok: false, error: 'missing selector' };
        const loc = page.locator(action.selector);
        const count = await loc.count();
        if (count !== 1) return { ok: false, error: `selector matched ${count} elements` };
        // For disabled inputs and number inputs we set value via evaluate
        // and dispatch a change event. Playwright's .fill() refuses disabled.
        await loc.evaluate((el: any, val: any) => {
          if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
            el.value = String(val);
            el.dispatchEvent(new Event('input',  { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          } else {
            el.textContent = String(val);
          }
        }, action.value);
        return { ok: true };
      }
      case 'select': {
        if (!action.selector) return { ok: false, error: 'missing selector' };
        const loc = page.locator(action.selector);
        const count = await loc.count();
        if (count !== 1) return { ok: false, error: `selector matched ${count} elements` };
        await loc.selectOption(String(action.value), { timeout: 2000 });
        return { ok: true };
      }
      case 'press': {
        if (!action.selector || !action.key) return { ok: false, error: 'missing selector or key' };
        const loc = page.locator(action.selector);
        const count = await loc.count();
        if (count !== 1) return { ok: false, error: `selector matched ${count} elements` };
        await loc.press(String(action.key), { timeout: 2000 });
        return { ok: true };
      }
      case 'set_locale': {
        if (!action.locale) return { ok: false, error: 'missing locale' };
        await page.evaluate((lang: string) => {
          const sel = document.getElementById('chat-lang') as HTMLSelectElement | null;
          if (sel) { sel.value = lang; sel.dispatchEvent(new Event('change', { bubbles: true })); }
          document.documentElement.setAttribute('lang', lang);
          document.body.setAttribute('data-page-lang', lang);
        }, action.locale);
        return { ok: true };
      }
      case 'say':
        return { ok: true };
      default:
        return { ok: false, error: `unknown kind: ${action.kind}` };
    }
  } catch (e: any) {
    return { ok: false, error: e?.message || String(e) };
  }
}

/**
 * Check whether a selector resolves uniquely in the current DOM.
 * Used for the target_emitted_resolved metric.
 */
export async function selectorResolvesUnique(page: Page, selector?: string): Promise<boolean> {
  if (!selector) return false;
  try {
    const n = await page.locator(selector).count();
    return n === 1;
  } catch (_) {
    return false;
  }
}

export async function callModelRaw(args: {
  html: string;
  accessibility: any;
  task: string;
  lang: string;
}): Promise<{
  ok: true; usage: any; latency_ms: number; raw_text: string;
  cap_applied: number; finish_reason?: string; truncated_by_cap: boolean;
} | {
  ok: false; error: string; latency_ms: number;
}> {
  const system = SYSTEM_PROMPT_RAW(args.lang);
  const user   = userPromptRaw(args.html, args.accessibility, args.task);
  const r = await callLlm({ system, messages: [{ role: 'user', content: user }] });
  if (!r.ok) return { ok: false, error: r.error, latency_ms: r.latency_ms };
  return {
    ok: true, usage: r.usage, latency_ms: r.latency_ms, raw_text: r.text,
    cap_applied: r.cap_applied, finish_reason: r.finish_reason,
    truncated_by_cap: isTruncatedByCap(r),
  };
}
