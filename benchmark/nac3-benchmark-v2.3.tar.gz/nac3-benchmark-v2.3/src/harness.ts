/**
 * NAC3 vs raw DOM benchmark harness.
 *
 * Usage:
 *   tsx src/harness.ts --pilot                          # 1 task x 2 cond x 3 iter
 *   tsx src/harness.ts --pilot --adversarial            # 3 tasks (one per group)
 *   tsx src/harness.ts --full                           # 8 tasks x 2 cond x 15 iter
 *   tsx src/harness.ts --full --adversarial             # 13 tasks x 2 cond x 15 iter
 *
 * Env:
 *   ANTHROPIC_API_KEY=...
 *   NAC3_URL=http://127.0.0.1:8011   (default)
 *   RAW_URL=http://127.0.0.1:8012    (default)
 *
 * Output:
 *   results/raw/<timestamp>__<set>.jsonl     one line per run
 *   results/traces/<run_id>.zip              Playwright trace
 */
import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, Browser, BrowserContext, Page } from 'playwright';
import { SONNET_4_6, costUsd } from './pricing.js';
import {
  snapshotNac3, callModelNac3, dispatchNac3Action, validateAgainstSnapshot,
  parseOutput as parseNac3, NacAction,
} from './conditions/nac3.js';
import {
  snapshotRawDom, callModelRaw, dispatchRawAction, selectorResolvesUnique,
  parseOutput as parseRaw, RawAction,
} from './conditions/raw_dom.js';
import { BASE_TASKS, TaskDef } from './tasks.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const ARGS = new Set(process.argv.slice(2));
const PILOT = ARGS.has('--pilot');
const ADVERSARIAL = ARGS.has('--adversarial');

const NAC3_URL = process.env.NAC3_URL || 'http://127.0.0.1:8011';
const RAW_URL  = process.env.RAW_URL  || 'http://127.0.0.1:8012';

const ITER_FULL  = 15;
const ITER_PILOT = 3;

const ITER = PILOT ? ITER_PILOT : ITER_FULL;

interface RunRecord {
  run_id: string;
  task_id: string;
  task_prompt: string;
  condition: 'nac3' | 'raw';
  iteration: number;
  started_at: string;
  ended_at: string;
  /* ----- LLM ----- */
  input_tokens: number;
  output_tokens: number;
  cache_read_input_tokens: number;
  cache_creation_input_tokens: number;
  total_cost_usd: number;
  llm_latency_ms: number;
  /* ----- dispatch ----- */
  dispatch_latency_ms: number;
  end_to_end_ms: number;
  n_actions_emitted: number;
  /* ----- outcome ----- */
  success: boolean;
  retries_used: number;
  target_emitted_resolved: boolean;
  target_reached_dom: boolean;
  hallucinated_target: boolean;
  error_class: string;
  error_detail: string;
  clarification_emitted: boolean;
  /* ----- payloads (audit) ----- */
  raw_response: string;
  parsed_message: string;
  parsed_actions: any[];
  dispatch_results: any[];
  postcondition_detail: string;
}

function ts(): string {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function makeRunId(taskId: string, condition: string, iter: number): string {
  return `${ts()}__${taskId}__${condition}__i${iter}`;
}

async function withFreshPage<T>(
  browser: Browser, url: string,
  fn: (page: Page, ctx: BrowserContext) => Promise<T>
): Promise<T> {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  try {
    await page.goto(url, { waitUntil: 'networkidle', timeout: 10_000 });
    await page.waitForTimeout(300);
    return await fn(page, ctx);
  } finally {
    await ctx.close();
  }
}

/**
 * Run one (task, condition, iter) trial. Implements the retries
 * policy per the brief: up to 2 retries on validation failure.
 */
async function runOneTrial(
  browser: Browser,
  task: TaskDef,
  condition: 'nac3' | 'raw',
  iter: number
): Promise<RunRecord> {
  const url = condition === 'nac3' ? NAC3_URL : RAW_URL;
  const startedAt = new Date().toISOString();
  const runId = makeRunId(task.id, condition, iter);
  const tWall0 = Date.now();

  const baseRecord: RunRecord = {
    run_id: runId,
    task_id: task.id,
    task_prompt: task.prompt,
    condition,
    iteration: iter,
    started_at: startedAt,
    ended_at: '',
    input_tokens: 0,
    output_tokens: 0,
    cache_read_input_tokens: 0,
    cache_creation_input_tokens: 0,
    total_cost_usd: 0,
    llm_latency_ms: 0,
    dispatch_latency_ms: 0,
    end_to_end_ms: 0,
    n_actions_emitted: 0,
    success: false,
    retries_used: 0,
    target_emitted_resolved: false,
    target_reached_dom: false,
    hallucinated_target: false,
    error_class: 'ok',
    error_detail: '',
    clarification_emitted: false,
    raw_response: '',
    parsed_message: '',
    parsed_actions: [],
    dispatch_results: [],
    postcondition_detail: '',
  };

  try {
    await withFreshPage(browser, url, async (page) => {
      await task.setup(page);

      // Up to 1 initial attempt + 2 retries = 3 calls max.
      const maxAttempts = 3;
      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        baseRecord.retries_used = attempt;

        if (condition === 'nac3') {
          const snapshot = await snapshotNac3(page);
          const lang = (snapshot as any)?.lang || 'es';
          const result = await callModelNac3({ snapshot, task: task.prompt, lang: 'es' });
          if (!result.ok) {
            baseRecord.error_class = 'api_error';
            baseRecord.error_detail = result.error;
            baseRecord.llm_latency_ms += result.latency_ms;
            continue;
          }
          baseRecord.llm_latency_ms += result.latency_ms;
          baseRecord.input_tokens   += result.usage.input_tokens || 0;
          baseRecord.output_tokens  += result.usage.output_tokens || 0;
          baseRecord.cache_read_input_tokens     += (result.usage as any).cache_read_input_tokens || 0;
          baseRecord.cache_creation_input_tokens += (result.usage as any).cache_creation_input_tokens || 0;
          baseRecord.raw_response = result.raw_text;

          const parsed = parseNac3(result.raw_text);
          if (!parsed.ok) {
            baseRecord.error_class = 'parse_error';
            baseRecord.error_detail = parsed.reason;
            continue;
          }
          baseRecord.parsed_message = parsed.data.message;
          baseRecord.parsed_actions = parsed.data.actions;
          baseRecord.n_actions_emitted = parsed.data.actions.length;
          baseRecord.clarification_emitted = parsed.data.actions.length === 0 && parsed.data.message.length > 0;

          if (parsed.data.actions.length === 0) {
            // Model asked for clarification. Stop retries -- this IS its answer.
            break;
          }

          // Validate each action against snapshot.
          let allResolved = true;
          let anyReachedDom = false;
          const tDispatch0 = Date.now();
          for (const a of parsed.data.actions) {
            const ok = validateAgainstSnapshot(a, snapshot);
            if (!ok) { allResolved = false; continue; }
            const r = await dispatchNac3Action(page, a);
            baseRecord.dispatch_results.push({ kind: a.kind, ok: r.ok, error: r.error });
            if (r.ok) anyReachedDom = true;
            if (!r.ok && r.error && /not_found/i.test(r.error)) allResolved = false;
          }
          baseRecord.dispatch_latency_ms += Date.now() - tDispatch0;
          baseRecord.target_emitted_resolved = allResolved;
          baseRecord.target_reached_dom = anyReachedDom;
          baseRecord.hallucinated_target = !allResolved;

          if (!allResolved && attempt < maxAttempts - 1) continue;
          break;
        } else {
          // raw_dom
          const { html, accessibility } = await snapshotRawDom(page);
          const result = await callModelRaw({ html, accessibility, task: task.prompt, lang: 'es' });
          if (!result.ok) {
            baseRecord.error_class = 'api_error';
            baseRecord.error_detail = result.error;
            baseRecord.llm_latency_ms += result.latency_ms;
            continue;
          }
          baseRecord.llm_latency_ms += result.latency_ms;
          baseRecord.input_tokens   += result.usage.input_tokens || 0;
          baseRecord.output_tokens  += result.usage.output_tokens || 0;
          baseRecord.cache_read_input_tokens     += (result.usage as any).cache_read_input_tokens || 0;
          baseRecord.cache_creation_input_tokens += (result.usage as any).cache_creation_input_tokens || 0;
          baseRecord.raw_response = result.raw_text;

          const parsed = parseRaw(result.raw_text);
          if (!parsed.ok) {
            baseRecord.error_class = 'parse_error';
            baseRecord.error_detail = parsed.reason;
            continue;
          }
          baseRecord.parsed_message = parsed.data.message;
          baseRecord.parsed_actions = parsed.data.actions;
          baseRecord.n_actions_emitted = parsed.data.actions.length;
          baseRecord.clarification_emitted = parsed.data.actions.length === 0 && parsed.data.message.length > 0;

          if (parsed.data.actions.length === 0) break;

          let allResolved = true;
          let anyReachedDom = false;
          const tDispatch0 = Date.now();
          for (const a of parsed.data.actions) {
            const sel = a.selector;
            if (a.kind !== 'set_locale' && a.kind !== 'say') {
              const unique = await selectorResolvesUnique(page, sel);
              if (!unique) { allResolved = false; baseRecord.dispatch_results.push({ kind: a.kind, ok: false, error: `selector not unique: ${sel}` }); continue; }
            }
            const r = await dispatchRawAction(page, a);
            baseRecord.dispatch_results.push({ kind: a.kind, ok: r.ok, error: r.error });
            if (r.ok) anyReachedDom = true;
            if (!r.ok) allResolved = false;
          }
          baseRecord.dispatch_latency_ms += Date.now() - tDispatch0;
          baseRecord.target_emitted_resolved = allResolved;
          baseRecord.target_reached_dom = anyReachedDom;
          baseRecord.hallucinated_target = !allResolved;

          if (!allResolved && attempt < maxAttempts - 1) continue;
          break;
        }
      }

      // Now check the post-condition (only DOM observable).
      await page.waitForTimeout(150);
      const pc = await task.postcondition(page);
      baseRecord.success = pc.ok;
      baseRecord.postcondition_detail = pc.detail || '';
      if (!pc.ok) {
        if (baseRecord.error_class === 'ok') baseRecord.error_class = 'post_condition_failed';
      }

      // Extra check for T4: message must contain the total.
      if (task.id === 'T4_read_total') {
        const msg = baseRecord.parsed_message || '';
        if (!/1115/.test(msg)) {
          baseRecord.success = false;
          baseRecord.error_class = 'post_condition_failed';
          baseRecord.error_detail = `message lacks 1115: "${msg}"`;
        }
      }
    });
  } catch (e: any) {
    baseRecord.error_class = baseRecord.error_class === 'ok' ? 'invalid_action' : baseRecord.error_class;
    baseRecord.error_detail += ` | harness exception: ${e.message}`;
  }

  baseRecord.total_cost_usd = costUsd(SONNET_4_6, {
    input_tokens: baseRecord.input_tokens,
    output_tokens: baseRecord.output_tokens,
    cache_read_input_tokens: baseRecord.cache_read_input_tokens,
    cache_creation_input_tokens: baseRecord.cache_creation_input_tokens,
  });
  baseRecord.end_to_end_ms = Date.now() - tWall0;
  baseRecord.ended_at = new Date().toISOString();
  return baseRecord;
}

async function ensureDir(p: string) {
  await fs.promises.mkdir(p, { recursive: true });
}

async function main() {
  if (ADVERSARIAL) {
    console.error('Adversarial set not yet wired. Run base set first.');
    process.exit(2);
  }

  const tasks = PILOT ? [BASE_TASKS[0]] : BASE_TASKS;
  const conditions: Array<'nac3' | 'raw'> = ['nac3', 'raw'];
  const out = path.join(ROOT, 'results', 'raw');
  await ensureDir(out);
  const outFile = path.join(out, `${ts()}__base_${PILOT ? 'pilot' : 'full'}.jsonl`);
  const sink = fs.createWriteStream(outFile, { flags: 'a' });

  console.log(`Bench start: tasks=${tasks.map(t => t.id).join(',')} conditions=${conditions.join(',')} iter=${ITER}`);
  console.log(`Output: ${outFile}`);

  const browser = await chromium.launch({ headless: true });
  try {
    let runs = 0;
    const total = tasks.length * conditions.length * ITER;
    const allRuns: RunRecord[] = [];
    for (const task of tasks) {
      for (const condition of conditions) {
        for (let iter = 0; iter < ITER; iter++) {
          runs++;
          process.stdout.write(`[${runs}/${total}] ${task.id} ${condition} #${iter} ... `);
          const rec = await runOneTrial(browser, task, condition, iter);
          allRuns.push(rec);
          sink.write(JSON.stringify(rec) + '\n');
          const tag = rec.success ? 'OK' : 'FAIL';
          process.stdout.write(`${tag}  cost=$${rec.total_cost_usd.toFixed(4)}  llm=${rec.llm_latency_ms}ms  e2e=${rec.end_to_end_ms}ms  err=${rec.error_class}\n`);
        }
      }
    }

    sink.end();

    // Print a summary table for the pilot.
    console.log('\n=== Summary by (task, condition) ===');
    const groups = new Map<string, RunRecord[]>();
    for (const r of allRuns) {
      const k = `${r.task_id}|${r.condition}`;
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k)!.push(r);
    }
    for (const [k, rs] of groups) {
      const succ = rs.filter(r => r.success).length;
      const cost = rs.reduce((s, r) => s + r.total_cost_usd, 0);
      const lat  = rs.reduce((s, r) => s + r.llm_latency_ms, 0) / rs.length;
      const tok  = rs.reduce((s, r) => s + r.input_tokens + r.output_tokens, 0) / rs.length;
      const hall = rs.filter(r => r.hallucinated_target).length;
      console.log(`  ${k}  success=${succ}/${rs.length}  cost=$${cost.toFixed(4)}  llm_mean=${lat.toFixed(0)}ms  toks_mean=${tok.toFixed(0)}  hallucinated=${hall}`);
    }
    console.log(`\nDone. Records: ${outFile}`);
  } finally {
    await browser.close();
  }
}

main().catch(e => {
  console.error('fatal', e);
  process.exit(1);
});
