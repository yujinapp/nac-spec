/**
 * 3-way pilot harness: NAC3 vs Raw DOM vs MCP on the invoice-app fixture.
 *
 * Usage:
 *   tsx src/harness_3way.ts          # pilot 3 tasks x 3 conditions x 3 iter = 27 runs
 *
 * Env:
 *   ANTHROPIC_API_KEY=...
 *   INVOICE_APP_URL=http://127.0.0.1:8080  (default; must be running)
 */
import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, Browser, BrowserContext, Page } from 'playwright';
import { pricingFor, costUsd } from './pricing.js';
import { MODEL_ID } from './conditions/llm.js';
import {
  snapshotNac3, callModelNac3, dispatchNac3Action, validateAgainstSnapshot,
  parseOutput as parseNac3,
} from './conditions/nac3.js';
import {
  snapshotRawDom, callModelRaw, dispatchRawAction, selectorResolvesUnique,
  parseOutput as parseRaw,
} from './conditions/raw_dom.js';
import {
  startMcpClient, stopMcpClient, runMcpTrial, getToolCatalog, getToolCatalogJson,
} from './conditions/mcp.js';
import { PILOT_TASKS, ThreeWayTask } from './tasks_invoice.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

const INVOICE_BASE = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';
const PILOT_ITER = Number(process.env.PILOT_ITER || 1);
/* v2.4 addendum sec 6.1: when launching per-iteration cross-model, set
   PILOT_ITER_OFFSET so the iteration label and run_id reflect the absolute
   global iteration, not the local position (always 0 in that flow). */
const PILOT_ITER_OFFSET = Number(process.env.PILOT_ITER_OFFSET || 0);

/* v2.4 brief sec 4 -- academic traceability (computed once at boot). */
const BENCH_VERSION = (() => {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    return pkg.version || 'unknown';
  } catch { return 'unknown'; }
})();
/* runtime_version + manifest_checksum populated once on first nac3 snapshot.
   Constant per process so subsequent runs reuse the cached values. */
let _RUNTIME_VERSION: string = 'unknown';
let _MANIFEST_CHECKSUM: string = 'unknown';
let _TRACE_CAPTURED = false;
function maybeCaptureTrace(snapshot: any): void {
  if (_TRACE_CAPTURED || !snapshot) return;
  /* runtime version may live as snapshot.nac_version or window.NAC.version
     -- snapshotNac3 surfaces nac_version on the base snapshot. */
  _RUNTIME_VERSION = (snapshot.nac_runtime_version || snapshot.runtime_version ||
                      snapshot.nac_version || 'unknown') + '';
  /* Checksum over plugins[] serialized canonically. Stable per fixture
     version + manifest decoration; changes if either side mutates. */
  try {
    const canon = JSON.stringify(snapshot.plugins || [], Object.keys((snapshot.plugins || [{}])[0] || {}).sort());
    _MANIFEST_CHECKSUM = crypto.createHash('sha256').update(canon).digest('hex').slice(0, 12);
  } catch { _MANIFEST_CHECKSUM = 'error'; }
  _TRACE_CAPTURED = true;
}
function applyTrace(rec: BaseRunRecord): void {
  rec.runtime_version = _RUNTIME_VERSION;
  rec.bench_version = BENCH_VERSION;
  rec.manifest_checksum = _MANIFEST_CHECKSUM;
}

type Condition = 'nac3' | 'raw' | 'mcp' | 'nac3-walker-silent' | 'nac3-walker-assisted';
const ALL_VALID_CONDITIONS: Condition[] = ['nac3', 'raw', 'mcp', 'nac3-walker-silent', 'nac3-walker-assisted'];
const ALL_CONDITIONS: Condition[] = (() => {
  const env = (process.env.PILOT_CONDITIONS || '').trim();
  if (!env) return ['nac3', 'raw', 'mcp'];
  const want = env.split(',').map(s => s.trim()).filter(Boolean);
  const valid: Condition[] = [];
  for (const c of want) {
    if ((ALL_VALID_CONDITIONS as string[]).includes(c)) valid.push(c as Condition);
  }
  return valid.length ? valid : ['nac3', 'raw', 'mcp'];
})();

/** Map condition -> path served by the invoice-app fixture server. */
function urlForCondition(cond: Condition): string {
  switch (cond) {
    case 'nac3':                return `${INVOICE_BASE}/nac3`;
    case 'raw':                 return `${INVOICE_BASE}/raw`;
    case 'mcp':                 return `${INVOICE_BASE}/mcp`;
    case 'nac3-walker-silent':  return `${INVOICE_BASE}/forge-silent`;
    case 'nac3-walker-assisted': return `${INVOICE_BASE}/forge-assisted`;
  }
}

interface BaseRunRecord {
  run_id: string;
  task_id: string;
  task_prompt: string;
  task_complexity: string;
  condition: Condition;
  model_id: string;
  iteration: number;
  started_at: string;
  ended_at: string;

  /* shared metrics */
  input_tokens: number;
  output_tokens: number;
  cache_read_input_tokens: number;
  cache_creation_input_tokens: number;
  total_cost_usd: number;
  llm_latency_ms: number;
  dispatch_latency_ms: number;
  end_to_end_ms: number;
  n_actions_emitted: number;

  /* extended metrics (per brief part D) */
  n_tool_calls: number;
  n_model_turns: number;
  serialization_overhead_tokens: number;
  read_calls: number;
  write_calls: number;
  clarification_emitted: boolean;
  hit_max_turns: boolean;

  /* v2.4 (2026-05-19) post-fix metrics */
  truncated_by_cap: boolean;     /* output_tokens hit cap AND finish_reason=length/payload not closed */
  asked_human: boolean;          /* actions=[] AND message matches pregunta pattern */
  hallucination_category: 'none' | 'filtered' | 'reached_failed' | 'reached_succeeded';

  /* v2.4 addendum sec 7 metrics */
  reasoning_tokens: number;      /* sum across turns; 0 for non-reasoners */
  time_to_first_action_ms: number; /* dispatch -> first parseable action emitted */
  dispatch_to_dispatch_ms_p50: number; /* median inter-action gap; 0 if <2 actions */
  actions_per_turn_mean: number;   /* n_actions_emitted / max(n_model_turns, 1) */
  tool_call_round_trips: number;   /* mcp only: same as n_tool_calls; 0 elsewhere */

  /* v2.4 brief sec 4 traceability (academic provenance) */
  runtime_version: string;       /* NAC.version from the fixture page */
  bench_version: string;         /* bench/package.json version */
  manifest_checksum: string;     /* sha256 over serialized snapshot.plugins, first 12 hex chars */

  /* outcome */
  success: boolean;
  retries_used: number;
  target_emitted_resolved: boolean;
  target_reached_dom: boolean;
  hallucinated_target: boolean;
  error_class: string;
  error_detail: string;

  /* audit payloads */
  system_prompt_hash: string;
  user_prompt: string;
  raw_response_first: string;
  raw_responses_all: string[];
  parsed_message: string;
  parsed_actions: any[];
  dispatch_results: any[];
  tool_calls: any[];
  postcondition_detail: string;
}

function ts(): string {
  return new Date().toISOString().replace(/[:.]/g, '-');
}
function hashString(s: string): string {
  /* Quick FNV-1a 32 hash to identify the system prompt without storing
     the full text every run. The full text is in results/pilot_3way/
     system_prompts.md. */
  let h = 0x811c9dc5 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return 'fnv1a-' + h.toString(16).padStart(8, '0');
}

async function ensureDir(p: string) { await fs.promises.mkdir(p, { recursive: true }); }

/* v2.4 fix D (2026-05-19): split halluc into 4 buckets so reports can
   distinguish silent damage (success=true with phantom selectors) from
   noisy failure (success=false because phantom selector errored) from
   "validator caught it pre-dispatch" (NAC3 isActionSafe). */
function classifyHallucination(rec: BaseRunRecord): 'none' | 'filtered' | 'reached_failed' | 'reached_succeeded' {
  if (!rec.hallucinated_target) return 'none';
  if (!rec.target_reached_dom) return 'filtered';
  return rec.success ? 'reached_succeeded' : 'reached_failed';
}

function median(nums: number[]): number {
  if (nums.length === 0) return 0;
  const s = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 === 0 ? (s[mid - 1] + s[mid]) / 2 : s[mid];
}

function finalizeDerivedMetrics(rec: BaseRunRecord, dispatchTimestamps: number[]): void {
  rec.actions_per_turn_mean = rec.n_actions_emitted / Math.max(rec.n_model_turns, 1);
  if (dispatchTimestamps.length >= 2) {
    const gaps: number[] = [];
    for (let i = 1; i < dispatchTimestamps.length; i++) {
      gaps.push(dispatchTimestamps[i] - dispatchTimestamps[i - 1]);
    }
    rec.dispatch_to_dispatch_ms_p50 = Math.round(median(gaps));
  }
}

/* ---- per-condition trial runners ---- */

async function runNac3Trial(browser: Browser, task: ThreeWayTask, iter: number,
                            condOverride: Condition = 'nac3'): Promise<BaseRunRecord> {
  const startedAt = new Date().toISOString();
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const tWall0 = Date.now();
  const rec = baseRecord(condOverride, task, iter, startedAt);
  const dispatchTimestamps: number[] = [];
  try {
    await page.goto(urlForCondition(condOverride), { waitUntil: 'networkidle' });
    await task.setup(ctx, page);

    const snapshot = await snapshotNac3(page);
    maybeCaptureTrace(snapshot);
    const userPrompt = JSON.stringify({ task: task.prompt }); /* not the full prompt; the call below embeds */
    rec.user_prompt = task.prompt;

    /* Single-turn call. Up to 2 retries on parse/validation fail. */
    const maxAttempts = 3;
    const tFirstAction0 = Date.now();
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      rec.retries_used = attempt;
      const r = await callModelNac3({ snapshot, task: task.prompt, lang: 'es' });
      rec.llm_latency_ms += r.latency_ms;
      if (!r.ok) { rec.error_class = 'api_error'; rec.error_detail = r.error; continue; }
      if (r.truncated_by_cap) rec.truncated_by_cap = true;
      rec.input_tokens   += r.usage.input_tokens || 0;
      rec.output_tokens  += r.usage.output_tokens || 0;
      rec.reasoning_tokens += (r.usage as any).reasoning_tokens || 0;
      rec.cache_read_input_tokens     += (r.usage as any).cache_read_input_tokens || 0;
      rec.cache_creation_input_tokens += (r.usage as any).cache_creation_input_tokens || 0;
      rec.raw_response_first = r.raw_text;
      rec.raw_responses_all.push(r.raw_text);

      const parsed = parseNac3(r.raw_text);
      if (!parsed.ok) { rec.error_class = 'parse_error'; rec.error_detail = parsed.reason; continue; }
      rec.parsed_message = parsed.data.message;
      rec.parsed_actions = parsed.data.actions;
      rec.n_actions_emitted = parsed.data.actions.length;
      rec.clarification_emitted = parsed.data.actions.length === 0 && parsed.data.message.length > 0;
      rec.n_model_turns = 1;
      if (parsed.data.actions.length === 0) break;

      let allResolved = true; let anyReachedDom = false;
      const tDispatch0 = Date.now();
      if (rec.time_to_first_action_ms === 0 && parsed.data.actions.length > 0) {
        rec.time_to_first_action_ms = tDispatch0 - tFirstAction0;
      }
      for (const a of parsed.data.actions) {
        const ok = validateAgainstSnapshot(a, snapshot);
        if (!ok) { allResolved = false; continue; }
        dispatchTimestamps.push(Date.now());
        const d = await dispatchNac3Action(page, a);
        rec.dispatch_results.push({ kind: a.kind, ok: d.ok, error: d.error });
        if (d.ok) anyReachedDom = true;
        if (!d.ok && d.error && /not_found/i.test(d.error)) allResolved = false;
        /* After each dispatch wait for in-flight /api/* fetches to land
           so the NEXT action sees the updated DOM (modal open, tab
           switched, new row rendered, etc). */
        try {
          await page.waitForFunction(() => (window as any).__pendingMutations === 0, { timeout: 2000 });
        } catch (_) { /* ignore */ }
      }
      rec.dispatch_latency_ms += Date.now() - tDispatch0;
      rec.target_emitted_resolved = allResolved;
      rec.target_reached_dom = anyReachedDom;
      rec.hallucinated_target = !allResolved;
      if (!allResolved && attempt < maxAttempts - 1) continue;
      break;
    }

    /* Wait for the bridge's pending fetch mutations to drain so the
       backend reflects everything the agent emitted before we check. */
    try {
      await page.waitForFunction(() => (window as any).__pendingMutations === 0, { timeout: 5000 });
    } catch (_) { /* time-boxed; ignore */ }
    await page.waitForTimeout(150);
    const pc = await task.postcondition(page);
    rec.success = pc.ok;
    rec.postcondition_detail = pc.detail || '';
    if (!pc.ok && rec.error_class === 'ok') rec.error_class = 'post_condition_failed';
  } catch (e: any) {
    rec.error_class = rec.error_class === 'ok' ? 'invalid_action' : rec.error_class;
    rec.error_detail += ` | harness: ${e.message}`;
  } finally {
    await ctx.close();
  }
  rec.total_cost_usd = costUsd(pricingFor(MODEL_ID), rec);
  rec.end_to_end_ms = Date.now() - tWall0;
  rec.ended_at = new Date().toISOString();
  rec.hallucination_category = classifyHallucination(rec);
  finalizeDerivedMetrics(rec, dispatchTimestamps);
  applyTrace(rec);
  return rec;
}

async function runRawTrial(browser: Browser, task: ThreeWayTask, iter: number): Promise<BaseRunRecord> {
  const startedAt = new Date().toISOString();
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const tWall0 = Date.now();
  const rec = baseRecord('raw', task, iter, startedAt);
  const dispatchTimestamps: number[] = [];
  try {
    await page.goto(`${INVOICE_BASE}/raw`, { waitUntil: 'networkidle' });
    await task.setup(ctx, page);
    rec.user_prompt = task.prompt;

    const maxAttempts = 3;
    const tFirstAction0 = Date.now();
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      rec.retries_used = attempt;
      const { html, accessibility } = await snapshotRawDom(page);
      const r = await callModelRaw({ html, accessibility, task: task.prompt, lang: 'es' });
      rec.llm_latency_ms += r.latency_ms;
      if (!r.ok) { rec.error_class = 'api_error'; rec.error_detail = r.error; continue; }
      if (r.truncated_by_cap) rec.truncated_by_cap = true;
      rec.input_tokens   += r.usage.input_tokens || 0;
      rec.output_tokens  += r.usage.output_tokens || 0;
      rec.reasoning_tokens += (r.usage as any).reasoning_tokens || 0;
      rec.cache_read_input_tokens     += (r.usage as any).cache_read_input_tokens || 0;
      rec.cache_creation_input_tokens += (r.usage as any).cache_creation_input_tokens || 0;
      rec.raw_response_first = r.raw_text;
      rec.raw_responses_all.push(r.raw_text);

      const parsed = parseRaw(r.raw_text);
      if (!parsed.ok) { rec.error_class = 'parse_error'; rec.error_detail = parsed.reason; continue; }
      rec.parsed_message = parsed.data.message;
      rec.parsed_actions = parsed.data.actions;
      rec.n_actions_emitted = parsed.data.actions.length;
      rec.clarification_emitted = parsed.data.actions.length === 0 && parsed.data.message.length > 0;
      rec.n_model_turns = 1;
      if (parsed.data.actions.length === 0) break;

      let allResolved = true; let anyReachedDom = false;
      const tDispatch0 = Date.now();
      if (rec.time_to_first_action_ms === 0 && parsed.data.actions.length > 0) {
        rec.time_to_first_action_ms = tDispatch0 - tFirstAction0;
      }
      for (const a of parsed.data.actions) {
        if (a.kind !== 'set_locale' && a.kind !== 'say') {
          const unique = await selectorResolvesUnique(page, a.selector);
          if (!unique) {
            rec.dispatch_results.push({ kind: a.kind, ok: false, error: `selector not unique: ${a.selector}` });
            allResolved = false; continue;
          }
        }
        dispatchTimestamps.push(Date.now());
        const d = await dispatchRawAction(page, a);
        rec.dispatch_results.push({ kind: a.kind, ok: d.ok, error: d.error });
        if (d.ok) anyReachedDom = true;
        if (!d.ok) allResolved = false;
        /* Same wait as nac3: let app.js's fetch land before next action. */
        try {
          await page.waitForFunction(() => (window as any).__pendingMutations === 0, { timeout: 2000 });
        } catch (_) { /* ignore */ }
      }
      rec.dispatch_latency_ms += Date.now() - tDispatch0;
      rec.target_emitted_resolved = allResolved;
      rec.target_reached_dom = anyReachedDom;
      rec.hallucinated_target = !allResolved;
      if (!allResolved && attempt < maxAttempts - 1) continue;
      break;
    }

    /* Raw DOM dispatches go through fetch in app.js; wait for them. */
    try {
      await page.waitForFunction(() => (window as any).__pendingMutations === 0, { timeout: 5000 });
    } catch (_) { /* ignore */ }
    await page.waitForTimeout(150);
    const pc = await task.postcondition(page);
    rec.success = pc.ok;
    rec.postcondition_detail = pc.detail || '';
    if (!pc.ok && rec.error_class === 'ok') rec.error_class = 'post_condition_failed';
  } catch (e: any) {
    rec.error_class = rec.error_class === 'ok' ? 'invalid_action' : rec.error_class;
    rec.error_detail += ` | harness: ${e.message}`;
  } finally {
    await ctx.close();
  }
  rec.total_cost_usd = costUsd(pricingFor(MODEL_ID), rec);
  rec.end_to_end_ms = Date.now() - tWall0;
  rec.ended_at = new Date().toISOString();
  rec.hallucination_category = classifyHallucination(rec);
  finalizeDerivedMetrics(rec, dispatchTimestamps);
  applyTrace(rec);
  return rec;
}

async function runMcpTrial2(browser: Browser, task: ThreeWayTask, iter: number): Promise<BaseRunRecord> {
  const startedAt = new Date().toISOString();
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const tWall0 = Date.now();
  const rec = baseRecord('mcp', task, iter, startedAt);
  try {
    /* Load the /mcp page for post-condition rendering; agent never sees it. */
    await page.goto(`${INVOICE_BASE}/mcp`, { waitUntil: 'networkidle' });
    await task.setup(ctx, page);
    rec.user_prompt = task.prompt;

    const trial = await runMcpTrial({ taskPrompt: task.prompt, lang: 'es' });
    rec.truncated_by_cap   = trial.truncated_by_cap;
    rec.asked_human        = trial.asked_human;
    rec.llm_latency_ms      = trial.llm_latency_ms_total;
    rec.dispatch_latency_ms = trial.dispatch_latency_ms_total;
    rec.input_tokens                  = trial.usage.total_input_tokens;
    rec.output_tokens                 = trial.usage.total_output_tokens;
    rec.cache_read_input_tokens       = trial.usage.total_cache_read_input_tokens;
    rec.cache_creation_input_tokens   = trial.usage.total_cache_creation_input_tokens;
    rec.reasoning_tokens              = (trial.usage as any).total_reasoning_tokens || 0;
    rec.n_tool_calls   = trial.tool_calls.length;
    rec.tool_call_round_trips = trial.tool_calls.length;
    rec.n_model_turns  = trial.turns;
    rec.read_calls     = trial.read_calls;
    rec.write_calls    = trial.write_calls;
    /* MCP time_to_first_action: started_at_ms of the first tool call,
       relative to the trial start (tWall0). */
    if (trial.tool_calls.length > 0) {
      rec.time_to_first_action_ms = trial.tool_calls[0].started_at_ms - tWall0;
    }
    const mcpDispatchTs = trial.tool_calls.map(t => t.started_at_ms);
    finalizeDerivedMetrics(rec, mcpDispatchTs);
    rec.clarification_emitted = trial.clarification_emitted;
    rec.hit_max_turns  = trial.hit_max_turns;
    rec.parsed_message = trial.message;
    rec.parsed_actions = trial.final_output?.actions || [];
    rec.n_actions_emitted = trial.tool_calls.length; /* count of tool calls dispatched */
    rec.raw_response_first = trial.raw_responses[0] || '';
    rec.raw_responses_all = trial.raw_responses;
    rec.tool_calls = trial.tool_calls;
    /* Compute serialization_overhead_tokens roughly as the sum of tool
       result chars / 4 (a coarse-but-fine token estimate). */
    const totalResultChars = trial.tool_calls.reduce((s, t) => s + (t.result_chars || 0), 0);
    rec.serialization_overhead_tokens = Math.round(totalResultChars / 4);

    /* Sync the page DOM from backend so post-condition sees current state. */
    const state = await fetch(INVOICE_BASE + '/api/state').then(r => r.json());
    await page.evaluate((s: any) => {
      const w = window as any;
      if (typeof w.__pushState === 'function') w.__pushState(s);
    }, state);
    await page.waitForTimeout(120);

    /* target_emitted_resolved for MCP: every tool the model called must
       exist in the catalog. The dispatcher already enforces this. */
    const unknownTools = trial.tool_calls.filter(tc => tc.result_summary.startsWith('unknown_tool:'));
    rec.target_emitted_resolved = unknownTools.length === 0;
    rec.target_reached_dom      = trial.tool_calls.some(tc => tc.ok);
    rec.hallucinated_target     = unknownTools.length > 0;
    if (unknownTools.length > 0) {
      rec.error_class = 'invalid_action';
      rec.error_detail = `${unknownTools.length} unknown tool call(s)`;
    }

    const pc = await task.postcondition(page);
    rec.success = pc.ok;
    rec.postcondition_detail = pc.detail || '';
    if (!pc.ok && rec.error_class === 'ok') rec.error_class = 'post_condition_failed';
  } catch (e: any) {
    rec.error_class = rec.error_class === 'ok' ? 'invalid_action' : rec.error_class;
    rec.error_detail += ` | harness: ${e.message}`;
  } finally {
    await ctx.close();
  }
  rec.total_cost_usd = costUsd(pricingFor(MODEL_ID), rec);
  rec.end_to_end_ms = Date.now() - tWall0;
  rec.ended_at = new Date().toISOString();
  rec.hallucination_category = classifyHallucination(rec);
  /* v2.4 fix E refinement (2026-05-19): the provisional asked_human from
     the MCP trial fires on any "actions=[] in final turn + question
     pattern", which catches post-success polite questions
     ("Listo. ¿Querés que muestre el detalle?"). Override to false unless
     the run actually halted (no useful actions OR final failure). */
  if (rec.asked_human && (rec.n_actions_emitted > 0 && rec.success)) {
    rec.asked_human = false;
  }
  applyTrace(rec);
  return rec;
}

/* ---- base record ---- */

function baseRecord(condition: Condition, task: ThreeWayTask, iter: number, startedAt: string): BaseRunRecord {
  return {
    run_id: `${ts()}__${MODEL_ID}__${task.id}__${condition}__i${iter}`,
    task_id: task.id,
    task_prompt: task.prompt,
    task_complexity: task.complexity,
    condition, model_id: MODEL_ID, iteration: iter,
    started_at: startedAt, ended_at: '',
    input_tokens: 0, output_tokens: 0,
    cache_read_input_tokens: 0, cache_creation_input_tokens: 0,
    total_cost_usd: 0, llm_latency_ms: 0, dispatch_latency_ms: 0, end_to_end_ms: 0,
    n_actions_emitted: 0,
    n_tool_calls: 0, n_model_turns: 0, serialization_overhead_tokens: 0,
    read_calls: 0, write_calls: 0,
    clarification_emitted: false, hit_max_turns: false,
    truncated_by_cap: false, asked_human: false, hallucination_category: 'none',
    reasoning_tokens: 0, time_to_first_action_ms: 0,
    dispatch_to_dispatch_ms_p50: 0, actions_per_turn_mean: 0,
    tool_call_round_trips: 0,
    runtime_version: 'unknown', bench_version: BENCH_VERSION, manifest_checksum: 'unknown',
    success: false, retries_used: 0,
    target_emitted_resolved: false, target_reached_dom: false, hallucinated_target: false,
    error_class: 'ok', error_detail: '',
    system_prompt_hash: '', user_prompt: '',
    raw_response_first: '', raw_responses_all: [],
    parsed_message: '', parsed_actions: [],
    dispatch_results: [], tool_calls: [],
    postcondition_detail: '',
  };
}

/* ---- write system prompts file for auditability ---- */

async function writeSystemPromptsFile(outDir: string): Promise<void> {
  const nac3 = require_systemPromptText('nac3');
  const raw  = require_systemPromptText('raw');
  const mcp  = require_systemPromptText('mcp');
  const md = `# system_prompts.md\n\n` +
    `Captured at: ${new Date().toISOString()}\n\n` +
    `## Condition A: NAC3\n\nfnv1a-${hashString(nac3).slice(6)}\n\n\`\`\`\n${nac3}\n\`\`\`\n\n` +
    `## Condition B: Raw DOM\n\nfnv1a-${hashString(raw).slice(6)}\n\n\`\`\`\n${raw}\n\`\`\`\n\n` +
    `## Condition C: MCP\n\nfnv1a-${hashString(mcp).slice(6)}\n\n\`\`\`\n${mcp}\n\`\`\`\n`;
  await fs.promises.writeFile(path.join(outDir, 'system_prompts.md'), md);
}

/* The conditions modules don't export the system prompt strings directly,
   so we re-derive them here using the same templates. This keeps the
   audit file self-contained. */
function require_systemPromptText(c: Condition): string {
  if (c === 'nac3') {
    /* Mirror src/conditions/nac3.ts SYSTEM_PROMPT_NAC3('es'). */
    return SYS_NAC3;
  }
  if (c === 'raw') {
    return SYS_RAW;
  }
  return SYS_MCP_PREFIX + '\n\nAvailable tools and their schemas:\n' + getToolCatalogJson();
}

const SYS_NAC3 = `You drive a web UI by emitting structured NAC actions.

Rules:
1. Resolve the user's intent against the NAC tree below. Prefer
   click_by_verb when a verb matches; fall back to click(nac_id)
   only if no verb fits.
2. For tab switching, use tab() with the plugin + tab_key from
   the manifest, NOT click().
3. NEVER invent nac_ids. Every action MUST reference a name
   present in the tree. If you cannot find a matching name, ask
   the user a clarifying question via {message} with empty actions[].
4. Reply in language: es.
5. Output JSON only:
   { "message": "...", "actions": [...] }
6. message is what the user sees + hears. Keep it short (one
   sentence is ideal).
7. If the user said "cambia a <language>" emit a single
   change_locale action with the 2-letter code.
8. For data-tables: use dt_add_row / dt_remove_row / dt_edit_cell /
   dt_commit / dt_discard. Compute aggregates with dt_read_aggregate
   then read in the message.
9. Bare 2-letter locale codes ('de','es','en') are language codes
   ONLY when followed/preceded by an explicit language word
   ('idioma', 'language', 'sprache'). 'cambia DE pestana' is NOT
   German -- 'de' here is the Spanish preposition.

Action JSON shape ... (see src/conditions/nac3.ts SYSTEM_PROMPT_NAC3)`;

const SYS_RAW = `You drive a web UI by emitting Playwright-compatible actions over CSS selectors.

Rules: (see src/conditions/raw_dom.ts SYSTEM_PROMPT_RAW)`;

const SYS_MCP_PREFIX = `You operate an invoice management system through structured tool calls. (see src/conditions/mcp.ts SYSTEM_PROMPT_MCP)`;

/* ---- main ---- */

async function main() {
  /* PILOT_OUT_DIR lets the multi-model orchestrator override the
     default. When unset the default keeps the legacy 2026-04 path. */
  const outDir = process.env.PILOT_OUT_DIR
    ? path.resolve(process.env.PILOT_OUT_DIR)
    : path.join(ROOT, 'results', 'pilot_3way', 'raw');
  await ensureDir(outDir);
  await writeSystemPromptsFile(path.dirname(outDir));

  /* MODEL_ID can contain '/' (e.g. meta-llama/llama-4-scout-...) which
     would create a subdir or fail on Windows. Sanitize for the file
     name only -- run records still carry the unmodified id. */
  const modelSlug = MODEL_ID.replace(/[\\/]/g, '_');
  const outFile = path.join(outDir, `${ts()}__${modelSlug}__pilot.jsonl`);
  const sink = fs.createWriteStream(outFile, { flags: 'a' });

  const taskFilter = (process.env.PILOT_TASK_IDS || '').trim();
  const wantedTaskIds = taskFilter
    ? new Set(taskFilter.split(',').map(s => s.trim()).filter(Boolean))
    : null;
  const TASKS = wantedTaskIds
    ? PILOT_TASKS.filter(t => wantedTaskIds.has(t.id))
    : PILOT_TASKS;

  console.log(`Pilot start: model=${MODEL_ID}  tasks=${TASKS.map(t => t.id).join(',')}`);
  console.log(`Conditions: ${ALL_CONDITIONS.join(',')}  iter=${PILOT_ITER}`);
  console.log(`Output: ${outFile}`);

  const needMcp = ALL_CONDITIONS.includes('mcp');
  if (needMcp) await startMcpClient({ invoiceAppUrl: INVOICE_BASE });
  const browser = await chromium.launch({ headless: true });
  const allRuns: BaseRunRecord[] = [];
  try {
    let runs = 0;
    const total = TASKS.length * ALL_CONDITIONS.length * PILOT_ITER;
    for (const task of TASKS) {
      for (const cond of ALL_CONDITIONS) {
        for (let localIter = 0; localIter < PILOT_ITER; localIter++) {
          const iter = localIter + PILOT_ITER_OFFSET;
          runs++;
          process.stdout.write(`[${runs}/${total}] ${task.id} ${cond} #${iter} ... `);
          let rec: BaseRunRecord;
          if (cond === 'nac3' || cond === 'nac3-walker-silent' || cond === 'nac3-walker-assisted') {
            rec = await runNac3Trial(browser, task, iter, cond);
          } else if (cond === 'raw') {
            rec = await runRawTrial(browser, task, iter);
          } else {
            rec = await runMcpTrial2(browser, task, iter);
          }
          allRuns.push(rec);
          sink.write(JSON.stringify(rec) + '\n');
          const tag = rec.success ? 'OK  ' : 'FAIL';
          const extra = cond === 'mcp'
            ? `  turns=${rec.n_model_turns}  tools=${rec.n_tool_calls}  max?=${rec.hit_max_turns}`
            : '';
          process.stdout.write(`${tag}  cost=$${rec.total_cost_usd.toFixed(4)}  llm=${rec.llm_latency_ms}ms  e2e=${rec.end_to_end_ms}ms  err=${rec.error_class}${extra}\n`);
        }
      }
    }
    sink.end();

    /* Summary by (task, condition) -- the 6 columns the user asked for. */
    console.log('\n=== Summary (per task x condition) ===');
    console.log('  task'.padEnd(38) + ' | cond | succ |    halluc | tok_in_mean | tok_out_mean | n_act_mean |    cost');
    console.log('  ' + '-'.repeat(38 + 90));
    const groups = new Map<string, BaseRunRecord[]>();
    for (const r of allRuns) {
      const k = `${r.task_id}|${r.condition}`;
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k)!.push(r);
    }
    /* Stable ordering: task first, then condition. */
    const keys = Array.from(groups.keys()).sort();
    for (const k of keys) {
      const rs = groups.get(k)!;
      const [taskId, cond] = k.split('|');
      const succ   = rs.filter(r => r.success).length;
      const halluc = rs.filter(r => r.hallucinated_target).length;
      const inTok  = Math.round(rs.reduce((s, r) => s + r.input_tokens,  0) / rs.length);
      const outTok = Math.round(rs.reduce((s, r) => s + r.output_tokens, 0) / rs.length);
      const nAct   = (rs.reduce((s, r) => s + r.n_actions_emitted, 0) / rs.length).toFixed(1);
      const cost   = rs.reduce((s, r) => s + r.total_cost_usd, 0);
      console.log(
        '  ' + taskId.padEnd(36) +
        ' | ' + cond.padEnd(4) +
        ' | ' + `${succ}/${rs.length}`.padStart(4) +
        ' | ' + `${halluc}/${rs.length}`.padStart(9) +
        ' | ' + String(inTok).padStart(11) +
        ' | ' + String(outTok).padStart(12) +
        ' | ' + String(nAct).padStart(10) +
        ' | $' + cost.toFixed(4).padStart(6)
      );
    }

    /* Global by condition. */
    console.log('\n=== Summary (per condition, all tasks) ===');
    console.log('  cond | succ  |    halluc | tok_in_mean | tok_out_mean | n_act_mean |    cost');
    console.log('  ' + '-'.repeat(76));
    for (const cond of ALL_CONDITIONS) {
      const rs = allRuns.filter(r => r.condition === cond);
      if (rs.length === 0) continue;
      const succ   = rs.filter(r => r.success).length;
      const halluc = rs.filter(r => r.hallucinated_target).length;
      const inTok  = Math.round(rs.reduce((s, r) => s + r.input_tokens,  0) / rs.length);
      const outTok = Math.round(rs.reduce((s, r) => s + r.output_tokens, 0) / rs.length);
      const nAct   = (rs.reduce((s, r) => s + r.n_actions_emitted, 0) / rs.length).toFixed(1);
      const cost   = rs.reduce((s, r) => s + r.total_cost_usd, 0);
      console.log(
        '  ' + cond.padEnd(4) +
        ' | ' + `${succ}/${rs.length}`.padStart(5) +
        ' | ' + `${halluc}/${rs.length}`.padStart(9) +
        ' | ' + String(inTok).padStart(11) +
        ' | ' + String(outTok).padStart(12) +
        ' | ' + String(nAct).padStart(10) +
        ' | $' + cost.toFixed(4).padStart(6)
      );
    }

    console.log(`\nDone: ${outFile}`);
  } finally {
    await browser.close();
    await stopMcpClient();
  }
}

main().catch(e => { console.error('fatal', e); process.exit(1); });
