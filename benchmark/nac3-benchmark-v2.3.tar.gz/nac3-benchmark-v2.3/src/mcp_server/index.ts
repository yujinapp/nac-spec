/**
 * MCP server (stdio transport) for the invoice-app fixture.
 *
 * Architecture (transparent to the agent, documented in REPORT_THREE_WAY.md):
 * this server is a thin adapter over the shared HTTP backend on :8080.
 * Every tool maps to one (or two) /api/* calls. This matches the
 * production pattern of major MCP servers -- the MCP layer is a
 * protocol adapter over an existing REST API.
 *
 * Run as a subprocess of the harness:
 *
 *   const transport = new StdioClientTransport({
 *     command: 'tsx',
 *     args: ['src/mcp_server/index.ts'],
 *   });
 *   const client = new Client({ name: 'bench', version: '0.1' });
 *   await client.connect(transport);
 *   const { tools } = await client.listTools();
 *   const result = await client.callTool({ name: 'list_invoices', arguments: {} });
 *
 * Run standalone for debugging:
 *
 *   echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | tsx src/mcp_server/index.ts
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

const BASE = process.env.INVOICE_APP_URL || 'http://127.0.0.1:8080';

/* -- HTTP helpers ------------------------------------------------------- */

async function get(path: string, query?: Record<string, string | undefined>): Promise<any> {
  const qs = query
    ? '?' + Object.entries(query).filter(([, v]) => v != null && v !== '')
        .map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(String(v))).join('&')
    : '';
  const r = await fetch(BASE + path + qs);
  return await r.json();
}
async function postJson(path: string, body: any): Promise<any> {
  const r = await fetch(BASE + path, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  return await r.json();
}
async function patchJson(path: string, body: any): Promise<any> {
  const r = await fetch(BASE + path, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  return await r.json();
}
async function del(path: string): Promise<any> {
  const r = await fetch(BASE + path, { method: 'DELETE' });
  return await r.json();
}

function ok<T extends object>(body: T): { content: [{ type: 'text'; text: string }] } {
  return { content: [{ type: 'text', text: JSON.stringify(body) }] };
}

/* -- Server ------------------------------------------------------------- */

const server = new McpServer(
  { name: 'invoice-app-mcp', version: '0.1.0' },
  { capabilities: { tools: {} } }
);

/* ---- read tools ---- */

server.registerTool('list_invoices', {
  description: 'List invoices. Optionally filter by status (pendiente, aprobada, cancelada).',
  inputSchema: { filter: z.object({ status: z.enum(['pendiente', 'aprobada', 'cancelada']).optional() }).optional() },
}, async (args) => {
  const status = args.filter?.status;
  const r = await get('/api/invoices', status ? { status } : undefined);
  return ok({ invoices: r.invoices || [] });
});

server.registerTool('get_invoice', {
  description: 'Get the full invoice header + lines + conditions + total for a given invoice id.',
  inputSchema: { invoice_id: z.string() },
}, async ({ invoice_id }) => {
  const r = await get('/api/invoices/' + encodeURIComponent(invoice_id));
  if (!r.ok) return ok({ error: r.error || 'not_found' });
  return ok({ invoice: r.invoice });
});

server.registerTool('get_total', {
  description: 'Get the running total for a given invoice (sum of line_total with discounts applied).',
  inputSchema: { invoice_id: z.string() },
}, async ({ invoice_id }) => {
  const r = await get('/api/invoices/' + encodeURIComponent(invoice_id));
  if (!r.ok) return ok({ error: r.error || 'not_found' });
  return ok({ total: r.invoice.total, currency: 'USD' });
});

server.registerTool('list_clients', {
  description: 'List clients. Optional substring query against name or CUIT.',
  inputSchema: { query: z.string().optional() },
}, async ({ query }) => {
  const r = await get('/api/clients', query ? { q: query } : undefined);
  return ok({ clients: r.clients || [] });
});

server.registerTool('get_wizard_state', {
  description: 'Get the wizard step + which invoice is currently open in the modal.',
  inputSchema: { invoice_id: z.string().optional() },
}, async () => {
  const s = await get('/api/state');
  return ok({
    current_step: s.wizard_step || 1,
    open_invoice_id: s.open_invoice_id || null,
  });
});

/* ---- write tools ---- */

server.registerTool('create_invoice', {
  description: 'Create a new invoice in pendiente status for the given client. Opens the modal on step 1.',
  inputSchema: { client_id: z.string() },
}, async ({ client_id }) => {
  const r = await postJson('/api/invoices', { client_id });
  if (!r.ok) return ok({ error: r.error || 'unknown_error' });
  return ok({ ok: true, invoice_id: r.invoice_id });
});

server.registerTool('update_invoice_header', {
  description: 'Update header fields (client_name, cuit, address, email, phone) for an invoice.',
  inputSchema: {
    invoice_id: z.string(),
    fields: z.object({
      client_name: z.string().optional(),
      cuit:        z.string().optional(),
      address:     z.string().optional(),
      email:       z.string().optional(),
      phone:       z.string().optional(),
    }),
  },
}, async ({ invoice_id, fields }) => {
  const r = await patchJson('/api/invoices/' + encodeURIComponent(invoice_id) + '/header', fields);
  return ok(r);
});

server.registerTool('add_invoice_line', {
  description: 'Append a new line to an invoice. Returns the new line_id.',
  inputSchema: {
    invoice_id:   z.string(),
    description:  z.string(),
    qty:          z.number(),
    price:        z.number(),
    discount_pct: z.number().optional(),
  },
}, async ({ invoice_id, description, qty, price, discount_pct }) => {
  const r = await postJson('/api/invoices/' + encodeURIComponent(invoice_id) + '/lines',
    { description, qty, unit_price: price, discount_pct: discount_pct ?? 0 });
  return ok(r);
});

server.registerTool('update_invoice_line', {
  description: 'Patch fields on an existing line (description, qty, unit_price, discount_pct).',
  inputSchema: {
    invoice_id: z.string(),
    line_id:    z.string(),
    fields: z.object({
      description:  z.string().optional(),
      qty:          z.number().optional(),
      unit_price:   z.number().optional(),
      discount_pct: z.number().optional(),
    }),
  },
}, async ({ invoice_id, line_id, fields }) => {
  const r = await patchJson(
    '/api/invoices/' + encodeURIComponent(invoice_id) + '/lines/' + encodeURIComponent(line_id),
    fields
  );
  return ok(r);
});

server.registerTool('remove_invoice_line', {
  description: 'Remove a line from an invoice.',
  inputSchema: { invoice_id: z.string(), line_id: z.string() },
}, async ({ invoice_id, line_id }) => {
  const r = await del('/api/invoices/' + encodeURIComponent(invoice_id) + '/lines/' + encodeURIComponent(line_id));
  return ok(r);
});

server.registerTool('set_payment_terms', {
  description: 'Set the payment method + term days on an invoice (step 3 conditions).',
  inputSchema: {
    invoice_id: z.string(),
    method:     z.enum(['contado', 'transferencia', 'cheque', 'credito']),
    term_days:  z.number(),
  },
}, async ({ invoice_id, method, term_days }) => {
  const r = await patchJson('/api/invoices/' + encodeURIComponent(invoice_id) + '/conditions',
    { payment_method: method, payment_term_days: term_days });
  return ok(r);
});

server.registerTool('set_observations', {
  description: 'Set the free-form observations text on an invoice (step 3 conditions).',
  inputSchema: { invoice_id: z.string(), text: z.string() },
}, async ({ invoice_id, text }) => {
  const r = await patchJson('/api/invoices/' + encodeURIComponent(invoice_id) + '/conditions',
    { observations: text, accepted: true });
  return ok(r);
});

server.registerTool('submit_invoice', {
  description: 'Mark an invoice as pendiente (final submit). Returns new status.',
  inputSchema: { invoice_id: z.string() },
}, async ({ invoice_id }) => {
  const r = await postJson('/api/invoices/' + encodeURIComponent(invoice_id) + '/submit', {});
  return ok(r);
});

server.registerTool('cancel_invoice', {
  description: 'Cancel an invoice (status -> cancelada). Optional reason is logged.',
  inputSchema: { invoice_id: z.string(), reason: z.string().optional() },
}, async ({ invoice_id, reason }) => {
  const r = await postJson('/api/invoices/' + encodeURIComponent(invoice_id) + '/cancel', { reason });
  return ok(r);
});

server.registerTool('save_draft', {
  description: 'Save the invoice as a draft. No-op on this backend (the state is always persisted); returns ok=true for protocol completeness.',
  inputSchema: { invoice_id: z.string() },
}, async () => {
  return ok({ ok: true });
});

server.registerTool('discard_changes', {
  description: 'Discard any uncommitted changes for an invoice. On this backend nothing is held in a draft buffer, so this is a no-op that returns ok=true.',
  inputSchema: { invoice_id: z.string() },
}, async () => {
  return ok({ ok: true });
});

/* ---- field-editor tools (T-V23-EDITOR) ----------------------------------
   Two flavours intentionally exposed so the LLM-MCP behaviour can be
   measured under both granularities:

   (a) Granular: open_field_editor + editor_select_all + editor_replace
       + editor_correct_grammar + editor_save + editor_cancel. Mirrors
       the 6 atomic verbs that a field-editing UI exposes (the same set
       NAC3's nac_editor plugin registers). Used by agents that want to
       drive the editor step-by-step.

   (b) Atomic: correct_field_grammar. Single tool that opens, runs the
       grammar fix, saves. The granular tools above each take ~1 round
       trip; the atomic one takes 1 total. This isolates "tool choice"
       behaviour: when both granular and atomic forms are available,
       which does the model pick? Logged via the existing
       mcp_tool_choice.csv aggregator. */

server.registerTool('open_field_editor', {
  description: 'Open a server-side editor session on a field of an invoice line (default field=description). Returns the current value. Must be called before editor_select_all / editor_replace / editor_correct_grammar / editor_save / editor_cancel.',
  inputSchema: {
    invoice_id: z.string(),
    line_id:    z.string(),
    field:      z.string().optional(),
  },
}, async ({ invoice_id, line_id, field }) => {
  const r = await postJson('/api/editor/open', { invoice_id, line_id, field });
  return ok(r);
});

server.registerTool('editor_select_all', {
  description: 'Select the entire current value of the open editor session.',
  inputSchema: {},
}, async () => {
  const r = await postJson('/api/editor/select-all', {});
  return ok(r);
});

server.registerTool('editor_replace', {
  description: 'Replace the current value of the open editor session with new_text.',
  inputSchema: { new_text: z.string() },
}, async ({ new_text }) => {
  const r = await postJson('/api/editor/replace', { new_text });
  return ok(r);
});

server.registerTool('editor_correct_grammar', {
  description: 'Run the deterministic grammar fix on the editor session current_value. Backed by the same GRAMMAR_FIXES stub as the NAC3 and raw paths -- reproducible across runs.',
  inputSchema: {},
}, async () => {
  const r = await postJson('/api/editor/correct-grammar', {});
  return ok(r);
});

server.registerTool('editor_save', {
  description: 'Commit the editor session current_value back to the line field. Closes the session.',
  inputSchema: {},
}, async () => {
  const r = await postJson('/api/editor/save', {});
  return ok(r);
});

server.registerTool('editor_cancel', {
  description: 'Discard the editor session without committing.',
  inputSchema: {},
}, async () => {
  const r = await postJson('/api/editor/cancel', {});
  return ok(r);
});

server.registerTool('correct_field_grammar', {
  description: 'Atomic: run the deterministic grammar fix on a specific invoice line description and persist it. Equivalent to open_field_editor + editor_correct_grammar + editor_save in one call. Use when only the grammar-fix outcome matters.',
  inputSchema: { invoice_id: z.string(), line_id: z.string() },
}, async ({ invoice_id, line_id }) => {
  const r = await postJson('/api/grammar-fix', { invoice_id, line_id });
  return ok(r);
});

/* -- Connect to stdio -------------------------------------------------- */

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}
main().catch((e) => {
  process.stderr.write('mcp_server fatal: ' + (e?.message || String(e)) + '\n');
  process.exit(1);
});
