/**
 * Public pricing for the 3 models used in this benchmark.
 *
 * Updated 2026-05-18 from each vendor's public price list:
 *   - Claude Sonnet 4.6:  $3 / $15 per M (in / out)
 *   - Claude Haiku 4.5:   $1 / $5  per M (in / out)
 *   - Gemini 2.0 Flash:   $0.10 / $0.40 per M (in / out)
 *   - Gemini 1.5 Pro:     $1.25 / $5  per M (in / out)
 */
export interface ModelPricing {
  model: string;
  input_per_million_usd: number;
  output_per_million_usd: number;
  cache_read_per_million_usd: number;
  cache_write_per_million_usd: number;
  /* v2.4 (2026-05-19): pricing tier flag for honest reporting. The
     two Groq Llamas live on the free tier today (USD 0) but with a
     hard TPM cap that drops them mid-pilot. Aggregators should set
     excluded_from_aggregate=true so the model still shows up in the
     report ("we tried, the provider rate-limited us") without
     contaminating per-condition averages. */
  tier?: 'paid' | 'free_tier_rate_limited';
  excluded_from_aggregate?: boolean;
}

export const PRICING: Record<string, ModelPricing> = {
  'claude-sonnet-4-6': {
    model: 'claude-sonnet-4-6',
    input_per_million_usd:        3.00,
    output_per_million_usd:       15.00,
    cache_read_per_million_usd:   0.30,
    cache_write_per_million_usd:  3.75,
  },
  /* Claude Opus 4.7 -- 2026-05 public list price. */
  'claude-opus-4-7': {
    model: 'claude-opus-4-7',
    input_per_million_usd:        15.00,
    output_per_million_usd:       75.00,
    cache_read_per_million_usd:   1.50,
    cache_write_per_million_usd:  18.75,
  },
  /* OpenAI gpt-5.5 (2026-04 release). Updated 2026-05-19 per addendum
     sec 5.2: $5 / $25 per M tokens. */
  'gpt-5.5': {
    model: 'gpt-5.5',
    input_per_million_usd:        5.00,
    output_per_million_usd:       25.00,
    cache_read_per_million_usd:   0.50,
    cache_write_per_million_usd:  5.00,
  },
  /* OpenAI gpt-4o-mini -- $0.15 / $0.60 per M tokens. */
  'gpt-4o-mini': {
    model: 'gpt-4o-mini',
    input_per_million_usd:        0.15,
    output_per_million_usd:       0.60,
    cache_read_per_million_usd:   0.075,
    cache_write_per_million_usd:  0.15,
  },
  /* OpenAI gpt-4o -- $2.50 / $10.00 per M tokens. */
  'gpt-4o': {
    model: 'gpt-4o',
    input_per_million_usd:        2.50,
    output_per_million_usd:       10.00,
    cache_read_per_million_usd:   1.25,
    cache_write_per_million_usd:  2.50,
  },
  /* OpenAI o4-mini -- reasoning model. Updated 2026-05-19 per addendum
     sec 5.2: $3 / $12 per M tokens. The o-series accepts
     max_completion_tokens and rejects explicit temperature (handled in
     llm.ts). */
  'o4-mini': {
    model: 'o4-mini',
    input_per_million_usd:        3.00,
    output_per_million_usd:       12.00,
    cache_read_per_million_usd:   0.75,
    cache_write_per_million_usd:  3.00,
  },
  /* Claude Haiku 4.5 -- updated 2026-05-19 per addendum sec 5.2:
     $0.80 / $4 per M tokens. */
  'claude-haiku-4-5': {
    model: 'claude-haiku-4-5',
    input_per_million_usd:        0.80,
    output_per_million_usd:       4.00,
    cache_read_per_million_usd:   0.08,
    cache_write_per_million_usd:  1.00,
  },
  'gemini-2.5-flash': {
    model: 'gemini-2.5-flash',
    input_per_million_usd:        0.30,
    output_per_million_usd:       2.50,
    cache_read_per_million_usd:   0.075,
    cache_write_per_million_usd:  0.30,
  },
  'gemini-3-flash-preview': {
    model: 'gemini-3-flash-preview',
    input_per_million_usd:        0.30,
    output_per_million_usd:       2.50,
    cache_read_per_million_usd:   0.075,
    cache_write_per_million_usd:  0.30,
  },
  /* Gemini 3.1 Flash Lite -- updated 2026-05-19 per addendum sec 5.2:
     $0.075 / $0.30 per M tokens. */
  'gemini-3.1-flash-lite': {
    model: 'gemini-3.1-flash-lite',
    input_per_million_usd:        0.075,
    output_per_million_usd:       0.30,
    cache_read_per_million_usd:   0.0188,
    cache_write_per_million_usd:  0.075,
  },
  'gemini-3.1-pro-preview': {
    model: 'gemini-3.1-pro-preview',
    input_per_million_usd:        1.25,
    output_per_million_usd:       10.00,
    cache_read_per_million_usd:   0.3125,
    cache_write_per_million_usd:  1.25,
  },
  'gemini-2.5-pro': {
    model: 'gemini-2.5-pro',
    input_per_million_usd:        1.25,
    output_per_million_usd:       10.00,
    cache_read_per_million_usd:   0.3125,
    cache_write_per_million_usd:  1.25,
  },
  'gemini-flash-latest': {
    model: 'gemini-flash-latest',
    input_per_million_usd:        0.30,
    output_per_million_usd:       2.50,
    cache_read_per_million_usd:   0.075,
    cache_write_per_million_usd:  0.30,
  },
  /* DeepSeek (own API). Pricing per DeepSeek docs 2026 (V3.2 era). */
  'deepseek-chat': {
    model: 'deepseek-chat',
    input_per_million_usd:        0.27,
    output_per_million_usd:       1.10,
    cache_read_per_million_usd:   0.07,
    cache_write_per_million_usd:  0.27,
  },
  /* Groq free tier -- $0 at this benchmark time. Rate-limited (TPM
     12000 / 30000 respectively); the commercial tier exists with
     separate pricing. Both models stay in the registry so the report
     can honestly note "tried, didn't make it through provider
     limits", but they are excluded from the aggregate to avoid
     contaminating per-condition averages. */
  'llama-3.3-70b-versatile': {
    model: 'llama-3.3-70b-versatile',
    input_per_million_usd:        0.00,
    output_per_million_usd:       0.00,
    cache_read_per_million_usd:   0.00,
    cache_write_per_million_usd:  0.00,
    tier:                         'free_tier_rate_limited',
    excluded_from_aggregate:      true,
  },
  'meta-llama/llama-4-scout-17b-16e-instruct': {
    model: 'meta-llama/llama-4-scout-17b-16e-instruct',
    input_per_million_usd:        0.00,
    output_per_million_usd:       0.00,
    cache_read_per_million_usd:   0.00,
    cache_write_per_million_usd:  0.00,
    tier:                         'free_tier_rate_limited',
    excluded_from_aggregate:      true,
  },
};

/* v2.4 (2026-05-19): which models contribute to per-condition
   averages in the orchestrator's summary tables. Returns true for
   paid/reliable models, false for free-tier rate-limited models that
   we still surface in the report but DO NOT mix into aggregates. */
export function includeInAggregate(modelId: string): boolean {
  const p = PRICING[modelId];
  if (!p) return true; // unknown model: include by default
  return !p.excluded_from_aggregate;
}

/* Kept for back-compat with the older 2-condition harness. */
export const SONNET_4_6 = PRICING['claude-sonnet-4-6'];

export function pricingFor(modelId: string): ModelPricing {
  const p = PRICING[modelId];
  if (!p) throw new Error('No pricing for model: ' + modelId);
  return p;
}

export function costUsd(
  pricing: ModelPricing,
  usage: { input_tokens: number; output_tokens: number;
           cache_read_input_tokens?: number; cache_creation_input_tokens?: number }
): number {
  const uncachedInput = usage.input_tokens;
  const cacheRead     = usage.cache_read_input_tokens || 0;
  const cacheWrite    = usage.cache_creation_input_tokens || 0;
  const output        = usage.output_tokens;
  return (
    (uncachedInput * pricing.input_per_million_usd       / 1_000_000) +
    (cacheRead     * pricing.cache_read_per_million_usd  / 1_000_000) +
    (cacheWrite    * pricing.cache_write_per_million_usd / 1_000_000) +
    (output        * pricing.output_per_million_usd      / 1_000_000)
  );
}
