/**
 * Base task set (T1-T8) per the brief.
 *
 * Each task has:
 *   - id          machine-readable slug
 *   - prompt      natural-language instruction (Spanish)
 *   - setup       async fn run before the task; restores baseline DOM
 *   - postcondition  async fn that returns { ok, detail } — DOM-only,
 *                    no NAC ack -- so both conditions are judged the same
 *
 * Setup invariant: every task starts with the modal OPEN (where relevant)
 * and the data-table in its initial 8-row state. Tasks T1-T7 operate
 * inside the modal; T8 changes locale and is modal-independent.
 *
 * Post-condition design: only observable DOM state. Specifically NOT
 * NAC's success-event ack -- per brief sec "Anti-sesgo (3)".
 */
import type { Page } from 'playwright';

export interface TaskDef {
  id: string;
  prompt: string;
  setup: (page: Page) => Promise<void>;
  postcondition: (page: Page) => Promise<{ ok: boolean; detail?: string }>;
}

/* ------------------------------------------------------------------ */
/* Shared setup: open the invoice modal so the data-table is mounted. */
/* ------------------------------------------------------------------ */

export async function resetPage(page: Page): Promise<void> {
  // Re-load to baseline. Cheaper than a JS reset and guarantees idempotency
  // across the two conditions. Each condition's harness URL is identical
  // up to the host:port.
  await page.reload({ waitUntil: 'networkidle' });
  // give the demo time to register data tables (NAC3) or finish boot (raw).
  await page.waitForTimeout(300);
}

export async function openInvoiceModal(page: Page): Promise<void> {
  // The "Edit invoice #INV-001" button has stable id 'open-modal' in BOTH
  // pages (set in vendor demo and in our raw page).
  await page.click('#open-modal');
  await page.waitForSelector('#modal[data-state="open"]', { timeout: 2000 });
}

/* ------------------------------------------------------------------ */
/* DOM-observable helpers                                              */
/* ------------------------------------------------------------------ */

async function rowsCount(page: Page): Promise<number> {
  return await page.$$eval('#lines-table tbody tr', els => els.length);
}

async function rowProducts(page: Page): Promise<string[]> {
  return await page.$$eval('#lines-table tbody tr input[data-col="product"]',
    els => els.map((e: any) => String(e.value || '').trim()));
}

async function rowQty(page: Page, productName: string): Promise<number | null> {
  return await page.$$eval(
    '#lines-table tbody tr',
    (rows, name) => {
      for (const r of rows) {
        const prodInput = r.querySelector('input[data-col="product"]') as HTMLInputElement | null;
        const qtyInput  = r.querySelector('input[data-col="qty"]')     as HTMLInputElement | null;
        if (prodInput && qtyInput && prodInput.value.trim().toLowerCase() === String(name).toLowerCase()) {
          return Number(qtyInput.value);
        }
      }
      return null;
    },
    productName
  );
}

async function rowExistsWithName(page: Page, productName: string): Promise<boolean> {
  const products = await rowProducts(page);
  return products.some(p => p.toLowerCase() === productName.toLowerCase());
}

async function modalState(page: Page): Promise<string> {
  return (await page.getAttribute('#modal', 'data-state')) || 'closed';
}

async function activeTab(page: Page): Promise<string> {
  return await page.evaluate(() => {
    const el = document.querySelector('.tab-btn[aria-current="page"]')
            || document.querySelector('.tab-btn[aria-selected="true"]');
    return el ? (el.getAttribute('data-tab') || '') : '';
  });
}

async function linesSum(page: Page): Promise<number> {
  const t = await page.textContent('#lines-sum');
  const n = Number(String(t || '').trim());
  return Number.isFinite(n) ? n : NaN;
}

async function pageLang(page: Page): Promise<string> {
  return await page.evaluate(() => {
    return document.documentElement.getAttribute('lang')
        || document.body.getAttribute('data-page-lang')
        || (document.getElementById('chat-lang') as HTMLSelectElement | null)?.value
        || '';
  });
}

/* ------------------------------------------------------------------ */
/* Tasks                                                               */
/* ------------------------------------------------------------------ */

export const BASE_TASKS: TaskDef[] = [
  /* T1: add a monitor row qty 1 price 250.
     The demo already has "Monitor" qty 1 250 as L3 -- if we asked the
     agent to add the same product, the table validator (sec 4.2 of
     spec) marks it as duplicate. So we ask for a DIFFERENT product:
     "Agrega un proyector cantidad 1 a 250 pesos." */
  {
    id: 'T1_add_row',
    prompt: 'Agregame una linea con producto Proyector, cantidad 1, precio 250.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
    },
    postcondition: async (page) => {
      // success = exactly 9 rows AND new row's product is "Proyector"
      const n = await rowsCount(page);
      if (n !== 9) return { ok: false, detail: `expected 9 rows, got ${n}` };
      const products = await rowProducts(page);
      const hasProyector = products.some(p => /proyector/i.test(p));
      if (!hasProyector) return { ok: false, detail: `no row with product Proyector (rows: ${products.join(', ')})` };
      const qty = await rowQty(page, 'Proyector');
      if (qty !== 1) return { ok: false, detail: `Proyector qty=${qty}, expected 1` };
      return { ok: true };
    },
  },

  /* T2: borra el teclado */
  {
    id: 'T2_remove_teclado',
    prompt: 'Borra el teclado de la tabla.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
    },
    postcondition: async (page) => {
      const n = await rowsCount(page);
      if (n !== 7) return { ok: false, detail: `expected 7 rows after removal, got ${n}` };
      const has = await rowExistsWithName(page, 'Teclado');
      if (has) return { ok: false, detail: `Teclado still present` };
      return { ok: true };
    },
  },

  /* T3: tab to Permissions */
  {
    id: 'T3_tab_permissions',
    prompt: 'Cambia a la pestana Permisos.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
    },
    postcondition: async (page) => {
      const tab = await activeTab(page);
      if (tab !== 'permissions') return { ok: false, detail: `active tab is "${tab}"` };
      // also check panel visibility
      const panelVisible = await page.evaluate(() => {
        const p = document.querySelector('.tab-panel[data-tab-panel="permissions"]');
        return p ? p.getAttribute('data-active') === '1' : false;
      });
      if (!panelVisible) return { ok: false, detail: 'permissions panel not active' };
      return { ok: true };
    },
  },

  /* T4: read the total. Side effect: none (read-only). Agent should
     emit a `say` action OR dt_read_aggregate then say. We measure
     success by: the modal still open AND the agent's message contains
     the current total value (1115). */
  {
    id: 'T4_read_total',
    prompt: 'Cuanto da el total de la factura? Leemelo.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
    },
    postcondition: async (page) => {
      // The expected sum is 50+140+250+320+180+75+40+60 = 1115
      const sum = await linesSum(page);
      if (sum !== 1115) return { ok: false, detail: `lines-sum is ${sum}, expected 1115` };
      // The harness will check that the agent's message string contains "1115"
      // -- post-condition extension: see harness postMessageContains.
      return { ok: true, detail: 'sum=1115; harness must verify message contains it' };
    },
  },

  /* T5: edit mouse qty to 3 */
  {
    id: 'T5_edit_mouse_qty',
    prompt: 'Cambia la cantidad del mouse a 3.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
    },
    postcondition: async (page) => {
      const qty = await rowQty(page, 'Mouse');
      if (qty !== 3) return { ok: false, detail: `Mouse qty=${qty}, expected 3` };
      return { ok: true };
    },
  },

  /* T6: save the invoice. Saving commits the table -- the modal then
     closes automatically (see demo nac:dt:committed listener line 426). */
  {
    id: 'T6_save_invoice',
    prompt: 'Guarda la factura.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
      // make a small pending change so commit has something to commit
      // -- on NAC3 the dt_commit always succeeds even if no pending
      // changes, but having a change in the dirty state makes the
      // before/after distinguishable for assertions.
      await page.evaluate(() => {
        const inp = document.querySelector(
          '#lines-table tbody tr:first-child input[data-col="qty"]'
        ) as HTMLInputElement | null;
        if (inp) {
          inp.value = '4';
          inp.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
      await page.waitForTimeout(80);
    },
    postcondition: async (page) => {
      const m = await modalState(page);
      if (m === 'open') return { ok: false, detail: 'modal still open -- save did not commit + close' };
      return { ok: true };
    },
  },

  /* T7: cancel pending changes in the TABLE (not the modal cancel).
     The distinguishing post-condition: rows revert to initial AND
     modal STAYS OPEN. */
  {
    id: 'T7_discard_pending',
    prompt: 'Cancela los cambios pendientes en la tabla.',
    setup: async (page) => {
      await resetPage(page);
      await openInvoiceModal(page);
      // dirty the table: change Mouse qty to 99 so a discard is observable.
      await page.evaluate(() => {
        const tr = Array.from(document.querySelectorAll('#lines-table tbody tr')).find(
          (r) => {
            const p = r.querySelector('input[data-col="product"]') as HTMLInputElement | null;
            return p && p.value.toLowerCase() === 'mouse';
          }
        );
        if (tr) {
          const qty = tr.querySelector('input[data-col="qty"]') as HTMLInputElement | null;
          if (qty) {
            qty.value = '99';
            qty.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }
      });
      await page.waitForTimeout(80);
    },
    postcondition: async (page) => {
      const qty = await rowQty(page, 'Mouse');
      if (qty !== 2) return { ok: false, detail: `Mouse qty=${qty}, expected 2 (reverted)` };
      const m = await modalState(page);
      if (m !== 'open') return { ok: false, detail: 'modal closed -- agent picked the cancel button distractor' };
      return { ok: true };
    },
  },

  /* T8: change language to English. Modal-independent. */
  {
    id: 'T8_change_locale_en',
    prompt: 'Cambia el idioma a ingles.',
    setup: async (page) => {
      await resetPage(page);
    },
    postcondition: async (page) => {
      const lang = await pageLang(page);
      if (!/^en/i.test(lang)) return { ok: false, detail: `lang="${lang}", expected "en"` };
      return { ok: true };
    },
  },
];

/** Look up a task by id. */
export function getBaseTaskById(id: string): TaskDef {
  const t = BASE_TASKS.find(x => x.id === id);
  if (!t) throw new Error(`Unknown base task: ${id}`);
  return t;
}
