/**
 * Task definitions for the invoice-app 3-way pilot.
 *
 * For the pilot we only need:
 *   - T1_add_monitor    (atomic write inside an open modal)
 *   - T_MCP1_cancel_oldest_pending  (exploratory: read list + write 1)
 *   - T_MCP4_create_invoice_full    (compound write: 1 read + 6-8 writes)
 *   - T_V23_EDITOR_fix_monitor      (v2.3 field editor primitive)
 *
 * Post-conditions are DOM-only and identical across conditions. The
 * harness syncs the page-mcp DOM from the backend before checking
 * (because MCP mutates state without going through the page's UI).
 */
import type { Page, BrowserContext } from 'playwright';

const BASE = 'http://127.0.0.1:8080';

export interface ThreeWayTask {
  id: string;
  prompt: string;
  /** Set up server state + page state. Called before the agent runs. */
  setup: (ctx: BrowserContext, page: Page) => Promise<void>;
  /** DOM-only post-condition. */
  postcondition: (page: Page) => Promise<{ ok: boolean; detail?: string }>;
  /** Optional message-content check. If returns false, success is forced false. */
  messageCheck?: (message: string) => boolean;
  /** Estimated complexity for the report; one of 'atomic' | 'exploratory' | 'compound'. */
  complexity: 'atomic' | 'exploratory' | 'compound';
}

/* ---- helpers ---- */

async function resetBackend(): Promise<void> {
  await fetch(BASE + '/api/reset', { method: 'POST' });
}

async function openInvoice(invoiceId: string, step = 2): Promise<void> {
  await fetch(BASE + '/api/open-invoice', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ invoice_id: invoiceId, step }),
  });
}

async function syncPageFromBackend(page: Page): Promise<void> {
  const state = await fetch(BASE + '/api/state').then(r => r.json());
  await page.evaluate((s: any) => {
    const w = window as any;
    if (typeof w.__pushState === 'function') w.__pushState(s);
  }, state);
  await page.waitForTimeout(120);
}

async function getInvoiceFromBackend(id: string): Promise<any | null> {
  const r = await fetch(BASE + '/api/invoices/' + encodeURIComponent(id)).then(r => r.json());
  return r.ok ? r.invoice : null;
}

async function listInvoicesFromBackend(): Promise<any[]> {
  const r = await fetch(BASE + '/api/invoices').then(r => r.json());
  return r.invoices || [];
}

/* T-V23-EDITOR snapshot stash: setup captures the seed lines of INV-0001
   right after /api/reset, and the postcondition diffs the current lines
   against that snapshot to enforce "exactly one line changed". A module-
   level Map keeps the harness single-threaded contract honest -- one
   pilot run at a time. */
const __TV23_SEED: Map<string, { id: string; description: string }[]> = new Map();

/* ---- the 3 pilot tasks ---- */

export const PILOT_TASKS: ThreeWayTask[] = [
  /* ----------------------------------------------------------------- */
  /* T1: atomic line addition inside an open modal.                     */
  /* ----------------------------------------------------------------- */
  {
    id: 'T1_add_monitor',
    prompt: 'Agrega un monitor a la factura abierta con cantidad 1 y precio 250.',
    complexity: 'atomic',
    setup: async (_ctx, page) => {
      await resetBackend();
      await openInvoice('INV-0001', 2);
      await page.reload({ waitUntil: 'networkidle' });
      await page.waitForTimeout(200);
    },
    postcondition: async (page) => {
      /* For MCP runs the page DOM may be stale; force sync from backend. */
      await syncPageFromBackend(page);
      const inv = await getInvoiceFromBackend('INV-0001');
      if (!inv) return { ok: false, detail: 'INV-0001 missing from backend' };
      if (inv.lines.length !== 49) {
        return { ok: false, detail: `expected 49 lines after adding 1, got ${inv.lines.length}` };
      }
      /* The new line should be the most recent one (highest line index). */
      const last = inv.lines[inv.lines.length - 1];
      if (!/monitor/i.test(last.description)) {
        return { ok: false, detail: `last line description "${last.description}" does not match /monitor/i` };
      }
      if (Number(last.qty) !== 1) {
        return { ok: false, detail: `last line qty=${last.qty}, expected 1` };
      }
      if (Number(last.unit_price) !== 250) {
        return { ok: false, detail: `last line unit_price=${last.unit_price}, expected 250` };
      }
      return { ok: true };
    },
  },

  /* ----------------------------------------------------------------- */
  /* T-MCP1: exploratory -- list pending, find oldest, cancel it.       */
  /* ----------------------------------------------------------------- */
  {
    id: 'T_MCP1_cancel_oldest_pending',
    prompt: 'Que facturas hay pendientes? Cancela la del cliente mas antiguo (la factura con la fecha mas vieja entre las pendientes).',
    complexity: 'exploratory',
    setup: async (_ctx, page) => {
      await resetBackend();
      await page.reload({ waitUntil: 'networkidle' });
      await page.waitForTimeout(200);
    },
    postcondition: async (page) => {
      await syncPageFromBackend(page);
      const invoices = await listInvoicesFromBackend();
      /* The oldest pendiente in seed is INV-0001. Post-condition: INV-0001
         is cancelada AND the other 4 originals are still pendiente. */
      const inv01 = invoices.find(i => i.id === 'INV-0001');
      if (!inv01) return { ok: false, detail: 'INV-0001 missing' };
      if (inv01.status !== 'cancelada') {
        return { ok: false, detail: `INV-0001 status=${inv01.status}, expected cancelada` };
      }
      for (const id of ['INV-0002', 'INV-0003', 'INV-0004', 'INV-0005']) {
        const x = invoices.find(i => i.id === id);
        if (!x || x.status !== 'pendiente') {
          return { ok: false, detail: `${id} status=${x?.status}, expected pendiente (collateral damage)` };
        }
      }
      return { ok: true };
    },
  },

  /* ----------------------------------------------------------------- */
  /* T-MCP4: compound -- create + 3-step wizard fill + submit.          */
  /* ----------------------------------------------------------------- */
  {
    id: 'T_MCP4_create_invoice_full',
    prompt:
      'Creame una factura nueva para el cliente Acme con: direccion "Av. Corrientes 1234", email "contacto@acme.com". Agregale una linea de "consultoria" con cantidad 10 horas a 150 cada una. Condiciones: forma de pago contado, plazo 0 dias, observaciones "proyecto urgente". Dejala lista para confirmar.',
    complexity: 'compound',
    setup: async (_ctx, page) => {
      await resetBackend();
      await page.reload({ waitUntil: 'networkidle' });
      await page.waitForTimeout(200);
    },
    postcondition: async (page) => {
      await syncPageFromBackend(page);
      const invoices = await listInvoicesFromBackend();
      /* Find the newest invoice (highest id). */
      const newest = invoices
        .filter(i => /^INV-\d+$/.test(i.id))
        .sort((a, b) => Number(a.id.slice(4)) - Number(b.id.slice(4)))
        .pop();
      if (!newest) return { ok: false, detail: 'no invoices found' };
      if (newest.id === 'INV-0001' || newest.id.endsWith('0015')) {
        return { ok: false, detail: `no new invoice was created (newest=${newest.id})` };
      }
      const inv = await getInvoiceFromBackend(newest.id);
      if (!inv) return { ok: false, detail: `created invoice ${newest.id} fetch failed` };
      if (!/acme/i.test(inv.header.client_name)) {
        return { ok: false, detail: `client_name="${inv.header.client_name}" does not match /acme/i` };
      }
      if (inv.header.address !== 'Av. Corrientes 1234') {
        return { ok: false, detail: `address="${inv.header.address}", expected "Av. Corrientes 1234"` };
      }
      if (inv.header.email !== 'contacto@acme.com') {
        return { ok: false, detail: `email="${inv.header.email}", expected "contacto@acme.com"` };
      }
      const consult = inv.lines.find((l: any) => /consultor/i.test(l.description));
      if (!consult) return { ok: false, detail: 'no line matches /consultor/i' };
      if (Number(consult.qty) !== 10) return { ok: false, detail: `consultoria qty=${consult.qty}, expected 10` };
      if (Number(consult.unit_price) !== 150) return { ok: false, detail: `consultoria price=${consult.unit_price}, expected 150` };
      if (inv.conditions.payment_method !== 'contado') {
        return { ok: false, detail: `payment_method=${inv.conditions.payment_method}, expected contado` };
      }
      if (Number(inv.conditions.payment_term_days) !== 0) {
        return { ok: false, detail: `payment_term_days=${inv.conditions.payment_term_days}, expected 0` };
      }
      if (!/urgente/i.test(inv.conditions.observations || '')) {
        return { ok: false, detail: `observations="${inv.conditions.observations}" does not match /urgente/i` };
      }
      if (inv.status !== 'pendiente') {
        return { ok: false, detail: `status=${inv.status}, expected pendiente` };
      }
      return { ok: true };
    },
  },

  /* ----------------------------------------------------------------- */
  /* T-V23-EDITOR: drive the v2.3 field editor primitive to fix a typo. */
  /* INV-0001 line L1 ships as 'monitr LCD 24 plgada'; the agent must  */
  /* open the editor on that line and apply the grammar-fix, leaving  */
  /* the value at 'monitor LCD 24 pulgadas'. Postcondition enforces   */
  /* exactly-one-changed: only L1 differs from the seed.              */
  /* ----------------------------------------------------------------- */
  {
    id: 'T_V23_EDITOR_fix_monitor',
    prompt:
      'La factura abierta tiene una linea de monitor con tipeo erroneo ' +
      '("monitr LCD 24 plgada"). Aplica la auto-correccion gramatical de ' +
      'esa linea: primero abri el editor de la descripcion de esa linea, ' +
      'luego invoca la accion de correccion gramatical automatica, y ' +
      'finalmente guarda los cambios. NO reescribas el texto a mano -- ' +
      'el sistema tiene que invocar su propio corrector. No modifiques ' +
      'ninguna otra linea.',
    complexity: 'atomic',
    setup: async (_ctx, page) => {
      await resetBackend();
      await openInvoice('INV-0001', 2);
      const inv = await getInvoiceFromBackend('INV-0001');
      __TV23_SEED.set('INV-0001',
        (inv?.lines || []).map((l: any) => ({ id: String(l.id), description: String(l.description) })));
      await page.reload({ waitUntil: 'networkidle' });
      await page.waitForTimeout(200);
    },
    postcondition: async (page) => {
      /* v2.4 fix B (2026-05-19): the ai_correct_syntax handler is async
         (click -> textarea render -> save -> backend propagation). Poll the
         backend up to 300ms looking for the seed delta before declaring
         "no change". This tolerates realistic handler timing without
         giving the model a free pass on cases where it never dispatched. */
      const seed = __TV23_SEED.get('INV-0001') || [];
      if (seed.length === 0) {
        return { ok: false, detail: 'seed snapshot was not captured in setup' };
      }
      const seedMap = new Map(seed.map(l => [l.id, l.description]));
      let inv: any = null;
      const deadline = Date.now() + 300;
      while (true) {
        await syncPageFromBackend(page);
        inv = await getInvoiceFromBackend('INV-0001');
        if (inv && inv.lines.length === seed.length) {
          const anyChanged = (inv.lines as any[]).some(l => {
            const before = seedMap.get(String(l.id));
            return before != null && String(l.description) !== before;
          });
          if (anyChanged) break;
        }
        if (Date.now() >= deadline) break;
        await page.waitForTimeout(60);
      }
      if (!inv) return { ok: false, detail: 'INV-0001 missing from backend' };
      if (inv.lines.length !== seed.length) {
        return { ok: false, detail: `line count changed (seed=${seed.length}, now=${inv.lines.length})` };
      }
      const diffs: { id: string; before: string; after: string }[] = [];
      for (const l of inv.lines as any[]) {
        const before = seedMap.get(String(l.id));
        if (before == null) {
          return { ok: false, detail: `unexpected new line id=${l.id}` };
        }
        if (String(l.description) !== before) {
          diffs.push({ id: String(l.id), before, after: String(l.description) });
        }
      }
      if (diffs.length === 0) {
        return { ok: false, detail: 'no line description changed (grammar fix was not applied)' };
      }
      if (diffs.length > 1) {
        return {
          ok: false,
          detail: 'exactly-one-changed violated: ' +
            diffs.map(d => `${d.id}:"${d.before}"->"${d.after}"`).join(' | '),
        };
      }
      const d = diffs[0];
      if (d.id !== 'L1') {
        return { ok: false, detail: `wrong line edited: ${d.id} (expected L1, the typo'd monitor)` };
      }
      if (d.after !== 'monitor LCD 24 pulgadas') {
        return {
          ok: false,
          detail: `L1 description is "${d.after}", expected "monitor LCD 24 pulgadas" ` +
            '(the GRAMMAR_FIXES output)',
        };
      }
      return { ok: true };
    },
  },
];
